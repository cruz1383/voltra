APACHE 4800 / TWO VOLTRAS — FULL INSERT V2

REVISED FULL-HEIGHT FIT TRIAL.

V2 adds FOUR upright carabiner slots and R15 curves on the two exposed handle
ends of the Voltra openings. Body/screen-end corners remain R0.5. The R20
case perimeter, covered-body fit, chargers, stoppers and joint dimensions
are retained. R15 curves add plastic only beyond the covered bodies; actual
metal handle fit must be checked with the included small R15 test.
 This revised 100 mm tall model is not a
physically proven production fit. The thin perimeter and device band fit were
confirmed by the user; full-height joints, case taper, lid clearance and
accessory packing still need testing.

WHAT TO PRINT

Four main parts: PRINT_Insert_BL.stl, PRINT_Insert_BR.stl,
PRINT_Insert_TL.stl and PRINT_Insert_TR.stl. Print ONE part per plate.
STLs are already positioned flat-bottom down, labels up, at Z=0.
Keep 100% scale. Do not print the STEP assembly as a single object.

OPTIONAL_Joint_Test_Male.stl and OPTIONAL_Joint_Test_Female.stl are small
full-height test tracks, not additional insert parts. Print these first using
the same material, layer height and wall settings as the intended sections.
Use a brim for their tall narrow bodies. Slide the female track down over the
male pads. It should reach the same bottom level by hand without tools or
spreading the socket. If it binds, do not force it and do not scale the main
sections: report the fit so only joint clearance can be corrected.


NEW SMALL FIT TESTS

OPTIONAL_Handle_End_R15.stl is a3mm-thick U around the exact new handle-end
opening. Print flat,100percent scale, no supports. Check both handle ends:
the curved corners should clear the metal handle and the straight sides
should retain the existing cover fit. Do not force the sample.

OPTIONAL_Upright_Carabiner_Pair.stl contains the exact two78 x11.5 x35mm
slots with5mm divider, on a3mm floor. Print flat,100percent scale. Check
two carabiners standing on edge. They should lift out separately, with
about5mm exposed above the rim. Check the widest gate/hinge area as well
as the body. A single spare carabiner can be used to test each slot.

The new upright hardware reaches about104.81mm above the insert bottom,
so it protrudes4.81mm above the insert. Check lid foam closure physically.

CAD comparison confirms only BL and TR changed from Full Insert V1.
TL and BR remain geometrically the same. Joint test parts are unchanged.
If you have already printed an unchanged section, it can be reused.

MATERIAL / SLICER STARTING POINT

PETG, 0.4 mm nozzle, 0.20 mm layer height, 4 wall loops, 12% gyroid infill,
6 top and 5 bottom layers. Use the temperature, cooling and flow settings
appropriate for your PETG rather than the earlier PLA profile.

IMPORTANT: CAD contains filled volumes below pocket floors. Sparse slicer
infill supports those floors and reduces weight; do NOT choose 100% infill.
Inspect Bambu Studio's material and time estimates before starting a section.
The model is a continuous shell-and-infill print, not a separately shelled
CAD lattice. No supports are intended: the upper male key has a gradual
lead-in ramp, while pocket floors are supported by infill underneath.
Inspect the sliced joint ramps and pocket floors before printing.
Use an approximately 5 mm brim if needed for PETG adhesion. Position clear
of the X1 Carbon's excluded/calibration areas; use the full printable plate
configuration appropriate to your printer. Main sections fit the 256 mm bed.

ASSEMBLY

Names match the supplied top-view layout with red Voltra above green:

    TL | TR
    -------
    BL | BR

Remove both upper pick-and-pluck layers. Retain the solid bottom foam cushion
and the lid foam. Clean seam/key edges of stray strings without changing the
fit surfaces. Start with BL. Lower BR onto its key tracks, then TL. Lower TR
last over both sets of tracks. The tracks are open at the top, so assembly
uses vertical motion rather than forcing the parts sideways. The joints
register the sections in X/Y; they are not positive locks against lifting.
The case and cushion support the installed assembly.

Do not glue the sections during initial testing. Test that all four sit flat
and that the case closes gently with both protected Voltras installed.
The devices should rest on the original bottom foam, without being lifted
by a plastic floor. Keep screens and cable outlets facing up as in the layout.

DESIGN DIMENSIONS (mm)

Outer footprint: 452.025 x 320.2625, R20, height 100.
Four section seam gaps: 0.30. Key socket offset: 0.20 per side.
Lower male pads: Z0–20; upper lead-in: Z71–77; upper pads: Z77–100.
Socket tracks run through the full height. These are new full-height joints;
only their in-plane profile was tested in the thin perimeter gauge. The
full-height joint test has not yet been reported as physically tested.

Voltra openings: 333.00 x 108.22, open through the base. Width uses 0.25 mm
clearance per side around the measured 107.72 mm protective cover.
Covered body length 291.04; approximate complete length with handle 329.
Outer-side finger scallops provide lifting access. Each handle end now has
two R15 opening corners; these curves begin about25mm beyond the protective
cover body. The cover/screen end remains R0.5. The old rectangular complete-
device envelope is no longer a suitable handle test: real U-shaped handles
are curved. Only the measured body and an explicitly approximate U envelope
are checked in CAD. Test both handles with the small coupon before printing
the changed full sections.

Shim-pin relief: 5.2 wide x 2.0 deep, full height, centered 100.79 from the
handle end of each RED/GREEN PROTECTIVE COVER BODY (not the metal handle).
Matching reliefs are provided on BOTH long walls so either installed pin
orientation is accommodated. The extra local notch does not widen the
rest of the tested 108.22 opening.

Stopper cradle envelopes: 62.97 x 43.27, depth 45; floor at Z55.
This supports a sideways overall60.97 x41.27 envelope. Molded shape and
physical fit are not exact reproductions. Check the attached cable/loop
position when seating it; do not force a cable bend to match a pocket.

Carabiner slots: FOUR upright slots, two per end. Each opening78 x11.5,
R2 corners, depth35; floor at Z65. A5mm divider separates each pair.
Measured carabiners75.78 x39.81 x8.91 stand on their8.91mm narrow edge,
so the39.81mm dimension is vertical. About4.81mm projects above the100mm
insert rim for grasping. The real gate/hinge fit is untested. These are
clearance slots, not standard-certified or exact traced hardware shapes.

Charger/cable compartments: 87 x65 x70 clear depth, R4; floor at Z30.
Both chargers are identical. Measured body59.96 x60.12 x28.86; overall
including pins75.91. Store the charger flat; the cable sits above it.
Measured cable bundle85.47 x40.92 x11.15 fits the CAD envelope. A bulkier
85.5 x57 x35 bundle also fits above the charger, with3 mm packing allowance
and3.14 mm top clearance. A flexible cable can be rearranged, but no
particular replacement cable length or connector shape is guaranteed.

Two shallow cable grooves connect the side openings to the stopper cradles:
6 wide x6 deep in the upper surface. The curved routes come from the reviewed
layout; cable diameter and minimum bend radius were not measured. The grooves
are optional resting locations, not clamps. Do not pull a cable into them
under tension. Their routing and actual seating need physical checking.

VALIDATION / LIMITS

See CAD_validation.json and mesh_validation.json for completed checks. These
cover valid single-piece solids, bed bounds, assembled overlap, sampled
vertical assembly motion, ideal rectangular device clearance, and watertight
positively oriented STL meshes. They cannot establish print shrinkage,
case taper, magnet/fixture details of the devices, impact protection, real
joint friction, or how lid foam compresses against the installed equipment.

The main part envelope includes all tabs. A5 mm brim fits within256 x256 mm
by dimensions; actual slicer placement must avoid the printer's excluded area.
No new Bambu project or machine G-code is included. Use your own PETG profile
and inspect the slice. Deburr any contact edges before placing equipment.

STEP files, source code, assembly previews and reviewed layout references
are included for inspection and future changes. This is a physical fit trial.
