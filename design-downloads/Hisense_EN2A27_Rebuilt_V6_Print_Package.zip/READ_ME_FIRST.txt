HISENSE EN2A27 — CLEAN CAD REBUILD V6 / FIRST FIT PRINT

V6: NARROWER INWARD RAIL TEETH + THIN OPEN REAR LEDGE
The inward teeth are narrowed along the rail from V5 base5.0 to2.5 mm.
The flat nose is0.8 mm with0.15 mm rounded corners, retaining a blunt tip.
Confirmed combined rail/tooth section2.16 mm and shoulder offset16.07 mm
are retained. Tooth station X=-10.93 from modeled rail shoulder X=-27.
Body remains76.02 x39.02 mm with2.20 mm nominal shell.

The previous closed rectangular catch/frame has been removed. The rear
feature is now a0.60 mm thin ledge with a rear root and angled end supports.
Its front and underside are open, with0.80 mm nominal center clearance
beneath the cap. The ledge envelope remains3.8 x10.4 mm and rises1.4 mm
above the local inner shell. The new tooth length and ledge dimensions
are photo-guided estimates, not additional caliper measurements.
Body, front insert tabs and main rail positions are unchanged.
Earlier V1-V5 feature revisions remain historical references.

This replaces the earlier patched scan candidate. The new model is clean
CAD using supplied caliper measurements and photographs, with scan-guided
surface curvature. It is not merely a conversion or smoothed scan.

CALIPER MEASUREMENTS
Body length excluding tabs:76.02 mm.
Body width:39.02 mm.
Nominal shell thickness:2.20 mm.
Overall length including reconstructed tabs:79.02 mm.
The side rails, two insert tabs, and rounded-end catch are reconstructed
from scan/photo evidence; their dimensions were NOT independently measured.
See validation.json for those estimated feature dimensions. Scan markers,
embossed text, and scan roughness are omitted. The outside is smooth.

FIT STATUS
This is a first fit print, not a confirmed working replacement. Main body
size follows calipers. Tab engagement, side-rail clearance, battery clearance,
and catch/release function require a physical fit check. The thin rear ledge
approximates visible geometry; the original release flexure is not verified.
Do not force a binding cover. It is not appropriate to call the attachment
features an exact reproduction solely from these perspective photographs.

PRINTING
Import STL in millimeters,100% scale. Do not auto-scale it.
The STL is oriented broad face horizontal, inner features upward, bottom
at Z0. The curved exterior does not sit flat over its entire area:inspect
and enable supports beneath raised curved portions and tab overhangs as
needed. This is NOT a verified support-free design or pre-sliced project.
PETG is a reasonable starting material for functional clips. Use your known
PETG printer profile; a0.16 mm layer and3-4 walls are reasonable starting
settings for a0.4 mm nozzle. Check thin tab slot toolpaths. PLA can be used
for a dimensional trial but is more brittle at small engagement features.
Printer-specific toolpaths, bridging and support removal are untested.

CHECKS
Valid single CAD solid. STL:one watertight connected body, consistent winding,
positive volume, no detected self-intersecting faces. Nine main-shell
thickness probes confirm2.20 mm. These are geometric checks, not physical fit.

FILES
Hisense_EN2A27_Rebuilt_V6.stl:print geometry.
Hisense_EN2A27_Rebuilt_V6.step:editable CAD reference.
Hisense_EN2A27_Rebuilt_V6_CAD.png:four CAD views.
validation.json:dimensions, estimated features, mesh/thickness checks.

Check the under-ledge overhang in the slicer: support placed on the model
may be needed if bridging/cantilever paths are inadequate. No claim of
support-free printing is made for this cover. Remove supports gently.

DETAIL VIEWS
Hisense_EN2A27_V6_Rail_Closeup.png:narrow inward tooth.
Hisense_EN2A27_V6_Rear_Ledge_Closeup.png:open ledge and angled supports.
