VOLTRA TPU CAP V3 — TIGHTER FIT / REQUESTED LENGTH TRIAL
Millimetres. New trials based on user feedback, not physically tested.

FEEDBACK
User tested V2 tip span3.84 and found it slightly looser than kit original. User requested a trial at10.00 overall length. V3 retains the same12 tangent-arc hexalobular proportions and circular10.22 x2.43 head, increasing only stem section and selected stem length.

FILES — THREE SEPARATE FIT TRIALS
PRINT_TPU_Cap_V3_3p89_Total10p00.stl
  Primary requested long trial:3.89 opposing tips (+0.05 diameter from tested3.84),7.57 stem,10.00 overall.
PRINT_TPU_Cap_V3_3p94_Total10p00.stl
  Tighter long alternative:3.94 opposing tips (+0.10 diameter from tested3.84),7.57 stem,10.00 overall.
PRINT_TPU_Cap_V3_3p89_Total8p73_SHORT_CONTROL.stl
  Width-fit control:3.89 opposing tips,previous6.30 stem,8.73 overall. Helps distinguish tighter width from bottoming against screw-recess floor.
All have matching STEP files. Stem length is measured from head underside. Names3p89/3p94 specify opposing tip spans, not radii. Per-side increases over3.84 are0.025/0.050. The section is scaled uniformly; valley spans and arc radii scale with it. All12 arcs and their tangency are retained. These remain scaled T20-reference cosmetic TPU plugs, not certified driver geometry or an exact copy of the kit's cap.

LENGTH RECONCILIATION
Earlier available depth was6.51–6.81 from cover outer face to recess bottom. With head underside seated on that face, the new7.57 stem exceeds it by0.76–1.06. IF that earlier measurement still applies, the long versions cannot seat fully without deformation and are not a verified fit. An apparent increase in holding pressure could be bottoming rather than desired stem-side retention.
The10.00 overall variants are explicit user-requested length trials. Confirm actual available depth before expecting them to sit flush. Start with the short3.89 control to assess radial fit independently. The long versions require additional actual depth; extra nominal axial clearance beyond7.57 is preferable to exact bottom contact. If head remains proud, do not count that as a successful press fit.
No claim is made that the user's available depth has changed. When asked about depth, user revised the requested overall length to10.00. Additional available depth has not been confirmed. Previous depth margin for the short control remains0.21–0.51 nominal.

PRINT
Circular head face on bed; stem up. Appropriate calibrated profile for Creality CR-TPU black; keep material and printer compensation consistent with the tested V2 parts. No supports expected. The corrected lobe shape is unchanged apart from uniform size. All files are already atZ0. Print separate labeled trials so sizes cannot be confused. Dry filament according to its label and use established settings that preserved the V2 lobe detail. Desired retention is by thumb pressure; actual fit/compliance depends on the unknown TPU Shore hardness, screw and printer error.

VALIDATION
Valid single-solid CAD parts.12 circular arcs per cross-section and analytic tangency verified. Dimensions:head10.22 x2.43;long overall10.00/stem7.57;short overall8.73/stem6.30. Meshes watertight, consistently wound, positive volume, on bed and intended total height checked. Source and validation reports included.
No physical print, full seating, retention or long-stem clearance has been verified for V3.
