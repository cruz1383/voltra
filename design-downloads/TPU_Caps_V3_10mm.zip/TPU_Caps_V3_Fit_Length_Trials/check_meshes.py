from pathlib import Path
from collections import Counter
import struct,json,numpy as np
results={}
for p in Path('/workspace/designs/output/TPU_Caps_V3_Fit_Length_Trials').rglob('*.stl'):
 data=p.read_bytes();n=struct.unpack_from('<I',data,80)[0];assert len(data)==84+50*n
 ts=[]
 for i in range(n):ts.append(struct.unpack_from('<9f',data,84+50*i+12))
 a=np.array(ts).reshape(-1,3,3); ids={};edges=Counter();orient=Counter()
 for t in a:
  inds=[]
  for v in t:
   key=tuple(np.round(v,5));inds.append(ids.setdefault(key,len(ids)))
  assert len(set(inds))==3
  for u,v in zip(inds,inds[1:]+inds[:1]):
   edges[tuple(sorted((u,v)))]+=1;orient[tuple(sorted((u,v)))]+=1 if u<v else -1
 assert all(v==2 for v in edges.values()),p
 assert all(v==0 for v in orient.values()),p
 volume=np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6
 assert volume>0 and abs(a[:,:,2].min())<1e-5
 expected_height=8.73 if 'SHORT_CONTROL' in p.name else 10.00
 assert abs(a[:,:,2].max()-expected_height)<1e-5
 results[p.name]={'triangles':n,'watertight_edges':True,'consistent_winding':True,'positive_volume_mm3':float(volume),'on_bed':True}
Path('/workspace/designs/output/TPU_Caps_V3_Fit_Length_Trials/mesh_validation.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
