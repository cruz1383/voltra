from pathlib import Path
import cadquery as cq,numpy as np,json
from cad_render import OUT,render,Image,ImageDraw,text
shape=cq.importers.importStep(str(OUT/'Shifted_Voltra_Restored_Charger_Wall_Assembly_CONCEPT.step')).val()
parts=shape.Solids();volumes=sorted([p.Volume() for p in parts]);print('Assembly volumes',volumes,flush=True)
rigid=[p for p in parts if p.Volume()>100000];tpu=[p for p in parts if p.Volume()<=100000]
assert len(rigid)==4 and len(parts)==20,(len(rigid),len(parts))
checks=[]
for a in rigid:
 for b in tpu:
  ab=a.BoundingBox();bb=b.BoundingBox()
  if ab.xmax<bb.xmin or bb.xmax<ab.xmin or ab.ymax<bb.ymin or bb.ymax<ab.ymin:continue
  v=a.intersect(b).Volume();assert v<1e-4,v
  checks.append(v)
arrays={}
for i,p in enumerate(parts):
 v,f=p.tessellate(.06,.1);arrays[('rigid_' if p.Volume()>100000 else 'TPU_')+str(i)]=np.array([a.toTuple() for a in v])[np.array(f)]
np.savez_compressed(OUT/'full_assembly.npz',**arrays)
im=Image.new('RGB',(1900,1500),'#f9f9f9');pic,_=render('full_assembly.npz',[-.5,-1,1.8],1900,1220);im.paste(pic,(0,140));d=ImageDraw.Draw(im)
text(d,'Full assembly — shifted Voltras + restored outer walls',950,25,39)
text(d,'Voltras shift 2.25 mm toward screen ends | Charger openings 87 × 73 mm | Side dovetails fixed | Actual CAD concept',950,90,26)
text(d,'Side dovetail seam margin: 10.2 mm (fixed) | Screen end-pad rear wall: 15.95 mm',950,1380,26)
text(d,'Concept only: physical fit, assembly force, transport contact and wall strength require testing.',950,1440,23)
im.save(OUT/'Straight_Pad_Full_Assembly_CAD.png')
(OUT/'assembly_check.json').write_text(json.dumps({'parts':len(parts),'rigid_parts':len(rigid),'rigid_TPU_overlap_checks':len(checks),'maximum_overlap_mm3':max(checks,default=0)},indent=2))
