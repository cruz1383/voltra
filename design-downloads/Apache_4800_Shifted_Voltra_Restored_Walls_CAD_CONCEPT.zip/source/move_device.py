"""Move device cavities and pin/end-pad seats; keep side tracks fixed."""
import cadquery as cq
from pathlib import Path
SRC=Path('/workspace/designs/tpu-full-v3p1/review')
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def prism(points,x,length):
 v=[cq.Vector(x,y,z) for y,z in points]
 return cq.Solid.extrudeLinear(cq.Wire.makePolygon(v+[v[0]]),[],cq.Vector(length,0,0))
def transform(p,side):return p if side>0 else p.rotate((0,0,0),(0,0,1),180)
def move(rigid):
 for side in [1,-1]:
  shift=(-side*2.25,0,0)
  wp=cq.Workplane('XY').box(333,108.22,1,centered=(True,True,False)).translate((-37.5125,81,0)).edges('|Z and >X').fillet(15).edges('|Z and <X').fillet(2).val()
  w=next(f for f in wp.Faces() if f.normalAt().z<-.99).outerWire()
  old=transform(cq.Workplane('XY').add(w).toPending().offset2D(1.5).extrude(100.4).val().translate((0,0,-.2)),side)
  new=old.translate(shift)
  pts=[(-25,0),(25,0),(25,1.15),(27,3.65),(-27,3.65),(-25,1.15)]
  channel=cq.Workplane('XY').polyline(pts).close().offset2D(.15).extrude(90.2).val().translate((0,0,10))
  roof=prism([(-.5,10),(9.5,10),(9.5,89),(1.5,97),(-.5,97)],-30,60)
  endseat=transform(channel.intersect(roof).rotate((0,0,0),(0,0,1),90).translate((-204.0125,81,0)),side)
  oldpins=[]
  for py in [26.89,135.11]:
   d=-1 if py<81 else 1;px=-11.7625
   straight=box(px-4,py-.1 if d>0 else py-3,-.1,8,3.1,100.2)
   flare=(cq.Workplane('XY').workplane(offset=94).center(px,py+d*1.45).rect(8,3.1).workplane(offset=6).center(0,d*.5).rect(10,4.1).loft(combine=True).val())
   oldpins.append(transform(straight.fuse(flare),side))
  restoration=transform(cq.Workplane('XY').add(w).toPending().offset2D(1.51).extrude(100.4).val().translate((0,0,-.2)),side)
  restores=[restoration.cut(new).intersect(box(-140 if side<0 else 105,-150 if side<0 else 15,0,35,140,100)),endseat.cut(old)]+[p.cut(old) for p in oldpins]
  for name in (['TL','TR'] if side>0 else ['BL','BR']):
   p=rigid[name];b=p.BoundingBox();xmin=max(.15,b.xmin) if name.endswith('R') else b.xmin
   xmax=min(-.15,b.xmax) if name.endswith('L') else b.xmax
   clip=box(xmin,b.ymin,0,xmax-xmin,b.ylen,100)
   for restore in restores:
    patch=restore.intersect(clip)
    if patch.Volume()>1e-6:p=p.fuse(patch,tol=1e-4)
   p=p.cut(new,tol=1e-4).cut(endseat.translate(shift),tol=1e-4)
   for pin in oldpins:p=p.cut(pin.translate(shift),tol=1e-4)
   print('Shifted rigid',name,'valid',p.isValid(),'solids',len(p.Solids()),flush=True)
   if not (p.isValid() and len(p.Solids())==1):p.exportBrep(str(Path(__file__).parent/(name+'_failed.brep')))
   assert p.isValid() and len(p.Solids())==1,name
   rigid[name]=p
  print('Moved cavity, pins, end seat; fixed side tracks:',side,flush=True)
 return rigid
