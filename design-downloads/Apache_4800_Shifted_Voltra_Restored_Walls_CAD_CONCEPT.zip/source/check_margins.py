from pathlib import Path
import cadquery as cq,json
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review'
assembly=cq.importers.importStep(str(OUT/'Shifted_Voltra_Restored_Charger_Wall_Assembly_CONCEPT.step')).val()
rigid=[s for s in assembly.Solids() if s.Volume()>100000]
for sgn in [1,-1]:
 def inside(x,y,z):return any(p.isInside(cq.Vector(sgn*x,sgn*y,z),1e-6) for p in rigid)
 for x in [.16,5,10.30,10.34]:assert inside(x,138.76,50),(sgn,x)
 assert not inside(10.36,138.76,50),sgn
 # Screen end rear-seat edge and material outside it, at pad mid-height.
 assert inside(-210.2,81,50)
 assert not inside(-210,81,50)
 # Material behind moved handle recess and restored outer lip.
 assert inside(130,81,55)
 assert inside(225,68.5,99.5)
# Verify that the old handle-end void was completely closed, including curves.
wp=cq.Workplane('XY').box(333,108.22,1,centered=(True,True,False)).translate((-37.5125,81,0)).edges('|Z and >X').fillet(15).edges('|Z and <X').fillet(2).val()
w=next(f for f in wp.Faces() if f.normalAt().z<-.99).outerWire()
old=cq.Workplane('XY').add(w).toPending().offset2D(1.5).extrude(100).val()
for side in [1,-1]:
 oldtool=old if side>0 else old.rotate((0,0,0),(0,0,1),180)
 newtool=oldtool.translate((-side*2.25,0,0))
 remaining=oldtool.cut(newtool)
 # The deliberately recessed TPU seat occupies part of the restored stock.
 seat_envelope=cq.Solid.makeBox(1.8,74.7,32.5,cq.Vector(127.4375,43.65,41.5))
 if side<0:seat_envelope=seat_envelope.rotate((0,0,0),(0,0,1),180)
 remaining=remaining.cut(seat_envelope)
 from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
 for p in rigid:
  op=BRepAlgoAPI_Cut(remaining.wrapped,p.wrapped);op.Build();assert op.IsDone()
  if op.Shape().IsNull():remaining=None;break
  remaining=cq.Shape.cast(op.Shape())
  if remaining.Volume()<1e-4:break
 assert remaining is None or remaining.Volume()<1e-4
 for p in rigid:assert newtool.intersect(p).Volume()<1e-4
report={'shifted_cavity_and_complete_old_curve_closure_verified':True,'side_pad_tracks_fixed_to_V3p1':True,'near_seam_side_track_margin_mm':10.2,
 'screen_end_pad_rear_to_outer_wall_nominal_mm':15.95,
 'handle_recess_backing_nominal_mm':3.1125,'charger_outer_lip_wall_nominal_mm':2.3625,
 'note':'Nominal dimensions plus exported STEP point checks; not physical strength verification.'}
(OUT/'margin_check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
