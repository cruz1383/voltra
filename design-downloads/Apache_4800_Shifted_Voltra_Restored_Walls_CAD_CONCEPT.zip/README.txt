Apache 4800 straight recessed handle pads + enlarged charger cavities
CAD CONCEPT ONLY — not a printable release. Existing V3.1 downloads unchanged.
Supersedes the expanded-cavity concept with thinner outer charger walls.

Changes applied to both mirrored handle ends:
- Straight TPU contact face 71 mm long x 32.2 mm tall, rounded corners.
  Rear dovetail width 74 mm; thickness 1.65 mm. No wrap around cavity curves,
  exposed tabs, or bridge over insert rim. Rear edges and top/bottom stops
  capture the pad geometrically; practical installation force remains untested.
- Face sits 0.8 mm proud of surrounding rigid wall, 0.85 mm buried. Seat has
  0.15 mm rear clearance and 0.3 mm vertical clearance under a 45-degree roof.
- Measured handle top 28.70 mm below rim, Z thickness 28.11 mm: handle
  Z43.19–71.30, pad contact Z41.50–73.70, with rim Z100 mm.
- Both BL/TR charger openings remain enlarged at 87 x 73 mm toward slots.
  Charger center X restored from 178.25 to original 177.5 (mirrored in BL),
  restoring nominal outer lip wall from 1.6125 to 2.3625 mm.
- Each complete Voltra cavity moves 2.25 mm toward its screen end: upper
  toward negative X, lower toward positive X. Pin reliefs and screen end-pad
  seats move with the device. The side-pad dovetail seats and pads stay fixed
  at the reinforced V3.1 locations relative to the four section seams.
- Straight recessed handle pad and seat move 2.25 mm with the handle.
- Nominal handle recess backing is now 3.1125 mm; other handle divider body
  4.1125 mm; lip backing 3.1125 mm. Divider to carabiner slot remains 5.35 mm.
- Screen end-pad seat has nominal 15.95 mm rear clearance to case outer wall.
  Near-seam side dovetail rear edge margin stays 10.2 mm. These dimensions
  are geometric checks and are not proof of printed wall strength.
- All four rigid sections change for translated cavities/pin/end reliefs;
  side pads and stopper liners remain at baseline locations.

Validation:
Valid single solids; no seated pad/cup overlap; upward, downward and front
translation collision confirms geometric stops. Measured charger and recorded
cable envelopes fit. Larger 85.5 mm cable box has 1.5 mm total length clearance.
46-degree geometry overhang audit passes for revised rigid sections, charger
liner upright, and handle pad with contact face on bed. Not slicer verified.
See assembly_check.json for independent exported STEP assembly overlap checks.

Pending physical checks: pad installation/retention, handle movement and
contact coverage in transport, actual cable packing, thin wall strength,
and printed fit. Handle itself was not reconstructed from photographs.

Includes full assembly STEP, individual handle pad and charger liner STEP,
three CAD views, validation reports, source scripts. No STL included.
Source scripts reference local V3.1 baseline BREP cache to regenerate assembly.
