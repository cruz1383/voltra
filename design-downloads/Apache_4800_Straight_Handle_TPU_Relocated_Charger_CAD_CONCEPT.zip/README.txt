Apache 4800 straight recessed handle pads + relocated charger cavities
CAD CONCEPT ONLY — not a printable release. Existing V3.1 downloads unchanged.
Supersedes the earlier curved handle-band concept for this proposed change.

Changes applied to both mirrored handle ends:
- Straight TPU contact face 71 mm long x 32.2 mm tall, rounded corners.
  Rear dovetail width 74 mm; thickness 1.65 mm. No wrap around cavity curves,
  exposed tabs, or bridge over insert rim. Rear edges and top/bottom stops
  capture the pad geometrically; practical installation force remains untested.
- Face sits 0.8 mm proud of surrounding rigid wall, 0.85 mm buried. Seat has
  0.15 mm rear clearance and 0.3 mm vertical clearance under a 45-degree roof.
- Measured handle top 28.70 mm below rim, Z thickness 28.11 mm: handle
  Z43.19–71.30, pad contact Z41.50–73.70, with rim Z100 mm.
- Charger cavity remains 87 x 65 mm. Center shifts 3 mm toward carabiner
  slots plus 0.75 mm away from handle. Unlike the prior concept, cavity size
  is preserved. A shift toward slots alone would not thicken the handle wall.
- Nominal rigid backing behind recess 1.6125 mm; outside band 2.6125 mm;
  lip wall at handle and outer case 1.6125 mm. Carabiner divider 13.35 mm
  measured from nearest slot edge to charger seat lip. These dimensions are
  geometry checks, not proof of strength of the printed walls.
- BL/TR rigid sections and both charger liners revised; two new handle pads.
  TL/BR, other contact pads, stopper liners, joints and valve remain baseline.

Validation:
Valid single solids; no seated pad/cup overlap; upward, downward and front
translation collision confirms geometric stops. Measured charger and recorded
cable envelopes fit. Larger 85.5 mm cable box has 1.5 mm total length clearance.
46-degree geometry overhang audit passes for revised rigid sections, charger
liner upright, and handle pad with contact face on bed. Not slicer verified.
See assembly_check.json for independent exported STEP assembly overlap checks.

Pending physical checks: pad installation/retention, handle movement and
contact coverage in transport, actual cable packing, thin wall strength,
and printed fit. Handle itself was not reconstructed from photographs.

Includes full assembly STEP, individual handle pad and charger liner STEP,
three CAD views, validation reports, source scripts. No STL included.
Source scripts reference local V3.1 baseline BREP cache to regenerate assembly.
