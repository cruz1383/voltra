V3 NEW FIT TESTS

Print at100percent scale with the same PETG settings as the intended main sections.

OPTIONAL_Screen_End_R2:thin3mm U around the exact new screen-end opening, opposite the metal handle. Check both covered units without forcing. The subtle R2 rounding clears the measured rectangular cover in CAD.

OPTIONAL_Joint_Test_Male and Female:new wider sliding joints,100mm tall, with broad feet. Use a brim. Lower the female track over the male pads until both feet reach the same surface; it should slide by hand without spreading or forcing. These are the V3 joints:6mm neck,10mm head,7mm reach,1mm root curves. They replace the earlier small profile.

The V3 main model also adds four middle connections. Use all four V3 main sections together; do not mix with V2. No screws, dowels or inserts are used. R15 handle corners and upright carabiner holders retain the previously successful fit.
