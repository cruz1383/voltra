APACHE4800 — TPU FIT / SNAP TESTER KIT, V1

These are SMALLER TEST HOLDERS, not replacement main insert sections.
Use the same rigid filament, TPU and slicer settings intended for the full
assembly. All files are millimeters at100% scale, already print-oriented.
Preserve orientations: rigid holders bottom-down, TPU cups upright, pads
flat on their contact face. No support structures are designed into them.

STAGE1 — SHORT DOVETAIL FIT (4 PIECES)
Print TEST_TPU_Dovetail_Pad_30mm.stl once, and the three short rigid tracks:
  CURRENT_plus_015: current full-package profile offset+0.15mm.
  LINE_TO_LINE_000: zero CAD profile offset, nominal line-to-line.
  INTERFERENCE_minus_010: intentionally0.10mm interfering trial.
The negative trial is designed to compress TPU. Try current+0.15 first,
then0.00 or-0.10 only if needed. Use hand force; do not hammer or force
a jammed sample. Slide the pad down to its stop, rub/pull its face upward
to assess lift resistance, and check whether it remains deliberately
removable. The desired fit slides by hand and resists lifting during device
removal. This requires physical testing; CAD cannot establish the force.

Track labels are FILE NAMES, not embossed markings. Keep printed tracks
identified externally so the three trials cannot be mixed up. If all are
too loose or tight, report that rather than scaling the files.

STAGE2 — OPTIONAL FULL-HEIGHT CURRENT FIT (2 PIECES)
OPTIONAL_TEST_RIGID_Full_Height_Dovetail_CURRENT_plus_015.stl and
OPTIONAL_TEST_TPU_Full_Height_Dovetail_Pad.stl reproduce the actual90mm
engagement and+0.15mm current seat. They check cumulative friction and lift
resistance; a short sample alone does not establish full-height behavior.
The TPU file is identical in geometry to the upper side pad in the full
package and is reusable if successful. If a different short-track offset
wins, get the full-height/main seats revised to that fit before large prints.

STAGE3 — ACCESSORY SNAP / LIP HOLDERS (4 PIECES)
Print each rigid holder with its matching TPU liner:
  TEST_RIGID_Charger_Snap_Lip_Holder + TEST_TPU_Charger_Liner
  TEST_RIGID_Stopper_Snap_Lip_Holder + TEST_TPU_Stopper_Liner
The holders reproduce the actual seating, beveled lip and sloped snap
pockets in compact standalone shells. They do not reproduce whole-case
wall stiffness, section seams or joints. Both TPU liners are the exact
full-package liner shapes and may be reused if they fit successfully.
Optional reference STEP assemblies show correct seating; do not print
the assembled reference as a merged object.

The cup bottom seats on a floor5mm above the test holder's base. The top
lip should seat flush, the liner should not rock, and both snap detents
should engage. Flex the liner wall inward to disengage before lifting.
It should resist inadvertent removal but remain removable without tools.
Test the real stopper (61.08mm measured), using its loop to lift it out.
The old finger notch is absent. Also check charger and cable packing.

REPORT RESULTS BEFORE THE LARGE PRINTS
Tell me which dovetail trial fits best, whether full-height engagement
binds/lifts, and whether each accessory liner seats and releases cleanly.
The FULL STL package currently remains at+0.15mm: the alternate trials
have NOT silently changed the main insert. Report printer/material/layer
settings with the result so any revised clearances are traceable.

VALIDATION
All10 tester STLs passed watertight edges, consistent winding, positive
volume, bed placement, X1C footprint including5mm brim allowance, and the
same46degree geometric-overhang audit as the18 full parts. These checks
are not a slicer support result, physical fit proof, force or strength test.
