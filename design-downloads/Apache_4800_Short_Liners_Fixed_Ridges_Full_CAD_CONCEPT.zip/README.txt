Apache 4800 — shortened square accessory and cable-end TPU liners
Fixed rigid retaining ridges — CAD CONCEPT, not a printable release.

Both square charger/accessory liners and both cable-end (stopper) liners
are shortened to Z93.5, 6.5 mm below the insert rim at Z100. No TPU rim lip,
flexible tabs, or tab relief slits remain. Fixed rigid ridges capture the
liner on a matching 45-degree upper bevel. TPU upper wall is 0.4 mm thick,
with 1.1 mm retaining overlap and 0.3 mm vertical clearance to the roof.

No deeper side cuts: new seat envelope is a subset of the previous seat.
Unused top flare and snap receiver voids are filled with rigid material.
Original 6 mm wide cable grooves remain at Z94 through the rigid print.
TPU is 0.5 mm below those groove floors; no TPU notch is needed. Ridges
are interrupted by the existing grooves, so no bridge blocks the wire.
The existing provisional wire route is preserved, not re-routed.

Square lower TPU opening:87 x73 mm, floor Z32. Clear rigid top opening:
87.8 x73.8 mm. Cable-end lower TPU opening:62.97 x43.27 mm, floor Z57;
clear rigid top opening:63.77 x44.07 mm. Top openings are larger than the
liner interiors, so the ridges do not reduce the existing entry envelope.

The previous 2.25 mm Voltra shifts, restored charger outer wall, straight
handle pads and fixed side dovetail track positions remain unchanged.

Validation report records CAD validity, seated overlaps, upward capture,
wire-channel clearance, and geometry overhang audit. Printer-specific
slicing, physical liner insertion/pullout, loaded wire path, item passage,
printed fit and wall strength remain unverified. Previous STL downloads
remain unchanged. No STL included in this concept package.

Included: full assembly STEP, four new liner STEP files, rendered full CAD
and square/cable-end detail views, validation report, source scripts.
Scripts reference the previous shifted-Voltra assembly to rebuild the model.
