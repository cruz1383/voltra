from pathlib import Path
import os,json,hashlib
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-v4-print-cache')
import cadquery as cq
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'print_package';CAD=ROOT.parent/'tpu-fixed-ridge/review';BASE=ROOT.parent/'tpu-full-v3p1/review';PREV=ROOT.parent/'tpu-voltra-shift/review'
(OUT/'Rigid').mkdir(parents=True,exist_ok=True);(OUT/'TPU').mkdir(exist_ok=True);(ROOT/'stl_full').mkdir(exist_ok=True)
items=[]
for n in ['BL','BR','TL','TR']:
 p=cq.Shape.importBrep(str(CAD/f'rigid_{n}.brep'));b=p.BoundingBox();p=p.translate((1-b.xmin,1-b.ymin,0))
 items.append((f'PRINT_{n}.stl','Rigid',1,p,'Bottom-down',f'Approved rigid_{n}.brep'))
for name,ref,qty in [('Side_Pad_60mm','Upper_Voltra_side_pad_1',8),('Screen_End_Pad_50mm','Upper_Voltra_end_pad',2)]:
 p=cq.Shape.importBrep(str(BASE/('PRINT_ORIENTATION_'+ref+'.brep')))
 items.append((f'PRINT_{name}_QTY{qty}.stl','TPU',qty,p,'Smooth contact face on bed; rear flex grooves up','Unchanged V3.1 canonical print geometry'))
p=cq.importers.importStep(str(PREV/'Upper_Handle_Band_CONCEPT.step')).val().rotate((0,0,0),(0,1,0),-90).translate((0,0,-127.4375));b=p.BoundingBox();p=p.translate((1-b.xmin,1-b.ymin,0))
items.append(('PRINT_Straight_Handle_Pad_QTY2.stl','TPU',2,p,'Flat contact face down; wider rear up','Approved shifted handle pad'))
for kind,floor in [('Square_accessory',30),('Cable_end',55)]:
 p=cq.importers.importStep(str(CAD/('Upper_'+kind+'_Short_TPU_CONCEPT.step'))).val().translate((0,0,-floor));b=p.BoundingBox();p=p.translate((1-b.xmin,1-b.ymin,0))
 items.append((f'PRINT_{kind}_Short_Liner_QTY2.stl','TPU',2,p,'Upright on outer floor','Approved shortened liner with fixed rigid ridge'))
manifest={'full':[],'total_physical_parts':20,'unique_STL_files':9}
for filename,mat,qty,p,orientation,source in items:
 assert p.isValid() and len(p.Solids())==1,filename
 dest=OUT/mat/filename;assert p.exportStl(str(dest),tolerance=.015,angularTolerance=.05,relative=False)
 (ROOT/'stl_full'/filename).write_bytes(dest.read_bytes())
 manifest['full'].append({'file':filename,'package_path':mat+'/'+filename,'material':mat,'quantity':qty,'orientation':orientation,'source':source,'CAD_volume_mm3':p.Volume(),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
 print('Exported',filename,flush=True)
assert sum(x['quantity'] for x in manifest['full'])==20
(ROOT/'stl_manifest.json').write_text(json.dumps(manifest,indent=2));(OUT/'PRINT_QUANTITIES.json').write_text(json.dumps(manifest,indent=2))
