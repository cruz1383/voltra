from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-ridge-cache')
import cadquery as cq,numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
SRC=ROOT.parent/'tpu-voltra-shift/review'
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,z,h):return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,0,z))
def wire(l,w,r):return next(f for f in rr(l,w,r,0,1).Faces() if f.normalAt().z<-.99).outerWire()
def loft(l,w,r,a,b,z0,z1):return cq.Solid.makeLoft([wire(l+2*a,w+2*a,r+a).translate((0,0,z0)),wire(l+2*b,w+2*b,r+b).translate((0,0,z1))],True)
def prism(points,x,length):
 v=[cq.Vector(x,y,z) for y,z in points]
 return cq.Solid.extrudeLinear(cq.Wire.makePolygon(v+[v[0]]),[],cq.Vector(length,0,0))
def rotate(p,s):return p if s>0 else p.rotate((0,0,0),(0,0,1),180)
parts=cq.importers.importStep(str(SRC/'Shifted_Voltra_Restored_Charger_Wall_Assembly_CONCEPT.step')).val().Solids()
rigid={};soft={}
for i,p in enumerate(parts):
 c=p.Center()
 if p.Volume()>100000:rigid[('T' if c.y>0 else 'B')+('R' if c.x>0 else 'L')]=p
 elif p.Volume()>16000:continue # replace all four cup liners
 else:soft['Existing_TPU_'+str(i)]=p
assert len(rigid)==4 and len(soft)==12
# Original cable route:6mm wide, bottomZ94, unchanged control points.
def groove(side):
 c=np.array([[-45,26.89],[-48,9],[-78,0],[-120,0]],float)*side;t=np.linspace(0,1,101)[:,None]
 p=(1-t)**3*c[0]+3*(1-t)**2*t*c[1]+3*(1-t)*t*t*c[2]+t**3*c[3]
 d=3*(1-t)**2*(c[1]-c[0])+6*(1-t)*t*(c[2]-c[1])+3*t*t*(c[3]-c[2]);n=np.stack([-d[:,1],d[:,0]],axis=1);n/=np.linalg.norm(n,axis=1)[:,None]
 poly=np.vstack([p+3*n,(p-3*n)[::-1]])
 g=cq.Workplane('XY').polyline([tuple(v) for v in poly]).close().extrude(6.2).val().translate((0,0,94))
 for x,y in [p[0],p[-1]]:g=g.fuse(cq.Solid.makeCylinder(3,6.2,cq.Vector(x,y,94)))
 return g
routes=[groove(1),groove(-1)]
newcups={};report={}
for kind,L,W,R,floor,cx,cy in [('Square_accessory',87.,73.,4.,30.,177.5,68.5),('Cable_end',62.97,43.27,21.625,55.,-150.,0.)]:
 oy=W/2+1.5
 # Reconstruct exact previous seat to fill only its now-unused top flare and
 # snap receiver pockets. New seat envelope never exceeds previous seat.
 old=rr(L+3.3,W+3.3,R+1.65,floor,100.2-floor).fuse(loft(L,W,R,1.65,2.65,97.85,98.85),rr(L+5.3,W+5.3,R+2.65,98.85,1.35))
 for d in [1,-1]:
  rec=prism([(oy-.05,90),(oy+1.4,90),(oy+1.4,95.4),(oy-.05,96.85)],-3.6,7.2)
  old=old.fuse(rec if d>0 else rec.mirror('XZ'))
 newseat=rr(L+3.3,W+3.3,R+1.65,floor,92.7-floor).fuse(loft(L,W,R,1.65,.4,92.7,93.95),rr(L+.8,W+.8,R+.4,93.95,6.25))
 assert newseat.cut(old).Volume()<1e-4
 cup=rr(L+3,W+3,R+1.5,floor,92.4-floor).fuse(loft(L,W,R,1.5,.4,92.4,93.5)).cut(rr(L,W,R,floor+2,100-floor))
 assert cup.isValid() and len(cup.Solids())==1
 for side in [1,-1]:
  seat=rotate(newseat.translate((cx,cy,0)),side);oldseat=rotate(old.translate((cx,cy,0)),side);tp=rotate(cup.translate((cx,cy,0)),side)
  # Slightly overlap restoration into existing rigid skin; keep every cut
  # bounded by the old seat so walls are not thinned.
  fill=oldseat.cut(seat)
  for name,p in list(rigid.items()):
   b=p.BoundingBox();xmin=max(.15,b.xmin) if name.endswith('R') else b.xmin;xmax=min(-.15,b.xmax) if name.endswith('L') else b.xmax
   ymin=max(.15,b.ymin) if name.startswith('T') else b.ymin;ymax=min(-.15,b.ymax) if name.startswith('B') else b.ymax
   patch=fill.intersect(box(xmin,ymin,0,xmax-xmin,ymax-ymin,100))
   if patch.Volume()>1e-5:
    p=p.fuse(patch,tol=1e-4).cut(seat,tol=1e-4)
    for g in routes:p=p.cut(g,tol=1e-4)
    assert p.isValid() and len(p.Solids())==1,(name,kind,len(p.Solids()))
    rigid[name]=p
  name=('Upper_' if side>0 else 'Lower_')+kind+'_Short_TPU';newcups[name]=tp
  for p in rigid.values():assert p.intersect(tp).Volume()<1e-4
  assert sum(p.intersect(tp.translate((0,0,.7))).Volume() for p in rigid.values())>1e-4
  for g in routes:assert tp.intersect(g).Volume()<1e-4
  cq.exporters.export(tp,str(OUT/(name+'_CONCEPT.step')))
 report[kind]={'liner_top_Z_mm':93.5,'below_rim_mm':6.5,'retaining_overlap_mm':1.1,'roof_slope_deg':45,'top_TPU_wall_mm':.4,'ridge_clear_opening_mm':[L+.8,W+.8],'existing_TPU_inner_opening_mm':[L,W],'seat_does_not_cut_deeper_than_previous':True}
 print('Short liner and rigid ridge valid:',kind,flush=True)
soft.update(newcups)
assembly=cq.Assembly(name='SHORT_LINERS_FIXED_RIDGES_CONCEPT')
for family,ps in [('rigid',rigid),('TPU',soft)]:
 for n,p in ps.items():assembly.add(p,name=family+'_'+n,color=cq.Color(1,.52,.12) if family=='TPU' else cq.Color(.56,.63,.67))
assembly.save(str(OUT/'Short_Liners_Fixed_Ridges_Full_Assembly_CONCEPT.step'))
def mesh(p):
 v,f=p.tessellate(.04,.08);return np.array([q.toTuple() for q in v])[np.array(f)]
def arrays(name,ps):np.savez_compressed(OUT/(name+'.npz'),**{k:mesh(p) for k,p in ps.items()})
arrays('full',{**{'rigid_'+n:p for n,p in rigid.items()},**{'TPU_'+n:p for n,p in soft.items()}})
for kind,cx,cy,l,w in [('Square_accessory',177.5,68.5,102,90),('Cable_end',-150,0,83,65)]:
 clip=box(cx-l/2,cy-w/2,30,l,w,71)
 arrays(kind,{**{'rigid_'+n:p.intersect(clip) for n,p in rigid.items() if p.intersect(clip).Volume()>1e-4},'TPU_liner':newcups['Upper_'+kind+'_Short_TPU']})
 section=box(cx-l/2,cy,30,l,5,71)
 arrays(kind+'_section',{**{'rigid_'+n:p.intersect(section) for n,p in rigid.items() if p.intersect(section).Volume()>1e-4},'TPU_liner':newcups['Upper_'+kind+'_Short_TPU'].intersect(section)})
 for n,p in rigid.items():p.exportBrep(str(OUT/('rigid_'+n+'.brep')))
checks=[]
for p in rigid.values():
 for t in soft.values():
  v=p.intersect(t).Volume();assert v<1e-4,v;checks.append(v)
audit={}
for n,p in list(rigid.items())+[(n,p.translate((0,0,-(30 if 'Square' in n else 55)))) for n,p in newcups.items()]:
 a=mesh(p);normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(normal,axis=1)/2;normal/=np.maximum(2*area,1e-14)[:,None]
 bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4;bad=(normal[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
 value=float(area[bad].sum());assert value<1e-4,(n,value);audit[n]=value
report.update({'stage':'CAD concept only; previous printable files unchanged','parts':20,'all_rigid_TPU_seated_overlaps_mm3':max(checks),'geometry_overhang_area_beyond46deg_mm2':audit,'wire_channel_bottom_Z_mm':94,'TPU_clearance_below_wire_channel_mm':.5,'wire_channel_original_route_preserved':True,'physical_fit_verified':False,'slicer_verified':False,'pending':['Liner insertion and pullout force','Charger and cable end passage through ridge','Wire route with actual cable','Physical fit and wall strength','Printer-specific slicing']})
(OUT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
