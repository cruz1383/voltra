from pathlib import Path
from collections import Counter
import json,struct,math
import numpy as np
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'stl_manifest.json').read_text())
dtype=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')])
for category,folder in [('full',ROOT/'stl_full')]:
    report={}
    entries=manifest[category]
    assert len(entries)==(9 if category=='full' else 10)
    assert len(list(folder.glob('*.stl')))==len(entries)
    for entry in entries:
        path=folder/entry['file'];data=path.read_bytes();n=struct.unpack_from('<I',data,80)[0]
        assert n>0 and len(data)==84+50*n,path.name
        a=np.frombuffer(data,dtype=dtype,count=n,offset=84)['points'].astype(float)
        assert np.isfinite(a).all()
        # Shared mesh vertices must close after roundoff at STL float32 scale.
        ids={};edges=Counter();winding=Counter()
        for tri in a:
            vi=[ids.setdefault(tuple(np.round(v,5)),len(ids)) for v in tri]
            assert len(set(vi))==3,(path.name,'collapsed triangle')
            for u,v in zip(vi,vi[1:]+vi[:1]):
                e=tuple(sorted((u,v)));edges[e]+=1;winding[e]+=1 if u<v else -1
        assert all(v==2 for v in edges.values()),(path.name,'open or nonmanifold edge')
        assert all(v==0 for v in winding.values()),(path.name,'inconsistent winding')
        xyz=a.reshape(-1,3);mn=xyz.min(axis=0);mx=xyz.max(axis=0)
        assert abs(mn[2])<1e-4,(path.name,'off bed',mn[2])
        assert mx[0]-mn[0]+10<=256 and mx[1]-mn[1]+10<=256,path.name
        volume=np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6
        assert volume>0,path.name
        normals=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(normals,axis=1)/2
        assert (area>1e-10).all(),(path.name,'degenerate face')
        normals/=2*area[:,None]
        bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
        steep=(normals[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
        unsupported=float(area[steep].sum())
        assert unsupported<1e-4,(path.name,'overhang audit',unsupported)
        report[path.name]={'triangles':n,'watertight':True,'consistent_winding':True,
            'positive_volume_mm3':float(volume),'on_bed':True,'bounds_min_mm':mn.tolist(),
            'bounds_max_mm':mx.tolist(),'fits_X1C_with_5mm_brim':True,
            'downward_faces_beyond_46deg_area_mm2':unsupported,
            'material':entry['material'],'slicer_verified':False,'physical_fit_verified':False}
        print('Mesh passed',path.name,n,flush=True)
    (folder/'mesh_validation.json').write_text(json.dumps(report,indent=2))
print('All9 unique full V4 STL mesh and geometric-overhang checks passed',flush=True)
