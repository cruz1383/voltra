from pathlib import Path
import ast,cadquery as cq,numpy as np,json
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review'
tree=ast.parse((ROOT/'build.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='groove')
ns={'cq':cq,'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),'original_wire_route','exec'),ns)
solids=cq.importers.importStep(str(OUT/'Short_Liners_Fixed_Ridges_Full_Assembly_CONCEPT.step')).val().Solids()
assert len(solids)==20
checks=[]
for side in [1,-1]:
 g=ns['groove'](side)
 for p in solids:
  a,b=p.BoundingBox(),g.BoundingBox()
  if a.xmax<b.xmin or b.xmax<a.xmin or a.ymax<b.ymin or b.ymax<a.ymin or a.zmax<b.zmin:continue
  v=p.intersect(g).Volume();assert v<1e-4,(side,v);checks.append(v)
report={'exported_STEP_parts':len(solids),'wire_route_intersection_checks':len(checks),'maximum_material_obstructing_original_wire_route_mm3':max(checks,default=0),'note':'Entire original CAD groove verified open in exported assembly; actual cable bend and fit untested.'}
(OUT/'wire_route_check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
