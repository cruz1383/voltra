APACHE 4800 — FULL V4 PRINT PACKAGE
Approved CAD: shortened accessory liners with fixed rigid retaining ridges.
This is the complete full-size set, not another miniature tester.

9 UNIQUE STL FILES; PRINT 20 TOTAL PARTS
Rigid/PRINT_BL.stl                         x1
Rigid/PRINT_BR.stl                         x1
Rigid/PRINT_TL.stl                         x1
Rigid/PRINT_TR.stl                         x1
TPU/PRINT_Side_Pad_60mm_QTY8.stl            x8
TPU/PRINT_Screen_End_Pad_50mm_QTY2.stl      x2
TPU/PRINT_Straight_Handle_Pad_QTY2.stl      x2
TPU/PRINT_Square_accessory_Short_Liner_QTY2.stl x2
TPU/PRINT_Cable_end_Short_Liner_QTY2.stl    x2
Quantities in filenames are required copies, not copies already in a file.

WHAT TO PRINT
Use all four rigid sections from THIS package. They include the shifted
Voltra cavities, moved pin/end-pad reliefs, expanded charger cavities and
new fixed retaining ridges. Earlier rigid revisions do not match this set.
Side and screen-end TPU pad shapes remain the V3.1 tested-mechanism geometry;
matching successful existing pads may be reused. Handle pads and shortened
square/cable-end liners must match this approved revision. Old tall accessory
liners with flexible tabs and rim lips are not the new shortened liners.

SCALE, MATERIAL AND ORIENTATION
Units:mm. Import at100% scale. Files are already oriented for printing.
Move/arrange them on the bed; preserve their orientation.
- Rigid sections:bottom-down,100 mm tall. Print separately as needed.
- Side and screen-end pads:smooth contact face down, rear flex grooves up;
  thickness3.65 mm. Keep the beveled top end intact.
- Straight handle pads:flat contact face down; wider dovetail rear up;
  thickness1.65 mm. They install horizontally across the handle end wall.
- Square and cable-end liners:upright on their outside floors, openings up.
Use your successful rigid filament and TPU settings. TPU95A remains the
starting material recommendation; changing hardness can change insertion
force. Do not scale parts to compensate without checking mating geometry.

GEOMETRY / SLICING STATUS
All9 unique STL files passed watertightness, consistent winding, positive
volume, nondegenerate-face, on-bed and46-degree geometry overhang checks.
Each footprint fits a256 x256 mm X1 Carbon bed with5 mm brim allowance by
dimensions; check the slicer's actual exclusion/calibration zones.
The design uses45-degree ridge/stop undersides and sloped dovetails for
support-free printing in the supplied orientations. This is a geometry
audit, not a printer-specific slice. No G-code, pre-sliced plates or
printer/material profiles are supplied. Check your slice preview before
printing: closed walls, complete thin ridge paths, open wire channels and
all retention features. Physical full-size fit and retention remain untested.

ASSEMBLY LAYOUT
TL | TR
---+---
BL | BR
Use the existing vertical sliding joints; assemble BL,BR,TL,TR. Retain the
original bottom cushion and lid foam. Install the seam-spanning cable-end
liners after joining the rigid sections. Reference/ contains the colored
full STEP and CAD views. Do not print that assembled STEP as one fused part.

TPU LOCATIONS
TL:2 side pads +1 screen-end pad.
TR:2 side pads +1 straight handle pad +1 square accessory liner.
BL:2 side pads +1 straight handle pad +1 square accessory liner.
BR:2 side pads +1 screen-end pad.
Cable-end liners:one at each end of the horizontal center seam.
Smooth TPU faces point toward the equipment; grooved backs enter rigid seats.

INSTALLATION
Side/end pads use the previously tested captured dovetail mechanism:put
the beveled top under the fixed stop, then flex the pad into the sides and
bottom stop. Confirm both ends and both side edges are seated.
Handle pads flex into their shallow recesses, with the wider rear ends
inside the dovetail seat. Do not force them straight through the retaining
opening as rigid pieces. Keep the upper bevel oriented upward.
Short accessory liners have NO flexible snap tabs and NO TPU rim lip.
Seat their floors, flex the upper walls inward under the rigid ridge and
let the matching upper bevels recover beneath it. Check the perimeter is
captured and the floor lies flat. Cable-end ridge interruptions align with
the existing wire routes. Removal requires deliberately flexing the liner
walls inward; insertion/removal force must be confirmed on the first print.

KEY APPROVED DIMENSIONS
Voltra cavities:2.25 mm shift toward each screen end; side dovetail tracks
stay at reinforced V3.1 locations. Near-seam track margin10.2 mm; screen
end-pad rear seat to outer wall15.95 mm nominal. Straight handle contact
face71 x32.2 mm,0.8 mm proud; handle recess backing3.1125 mm nominal.
Square liner inner opening87 x73 mm; floor2 mm thick, top6.5 mm below rim.
Cable-end liner opening62.97 x43.27 mm; floor2 mm thick, same shortened top.
Rigid ridge opening87.8 x73.8 mm square and63.77 x44.07 mm cable-end:the
ridge does not narrow the existing liner entry envelope. Ridge overlap
1.1 mm;45-degree roof with0.3 mm vertical clearance; TPU upper wall0.4 mm.
Wire groove floors remain Z94; TPU tops Z93.5, leaving0.5 mm below grooves.
No TPU wire notch is needed. Exported assembly wire grooves checked open.

FIRST FULL-SIZE FIT CHECK
Print one rigid section and its matching TPU parts before committing the
remaining filament if you want to check full-size retention first. This
package includes the full set and does not require another miniature trial.
Check chargers, cable ends, sleeved pins, wire bends, real cable packing,
and gentle lid closure before transport. Equipment rests on original foam.
The assembly's full-size retention force, TPU creep, wall strength and
transport protection are not established by mesh/CAD checks.

CONTENTS
Rigid/:4 print-ready section STLs.
TPU/:5 unique TPU STLs with required quantities in filenames.
Reference/:approved colored assembly STEP and full/detail CAD images.
Reports/:mesh audit, approved geometry, wire clearance and source matching.
Source/:export/check scripts plus approved CAD-generation scripts.
PRINT_QUANTITIES.json:material, orientation, quantity, source and STL hashes.
SHA256SUMS.txt:all packaged files except itself.
Source generation refers to earlier local baseline CAD; the supplied STLs
and assembled reference STEP are standalone and do not need those scripts.
