V3 CAPTURED TPU PAD — TEST PIECE CAD PREVIEW

USER REQUEST
A flexible pad tucked into a closed frame with the existing dovetail side
tracks and fixed top/bottom stops. No thin hook, separate keeper or feet.
This is a preview of that test piece BEFORE a new printable STL release.
Earlier tester and full-insert STL packages remain unchanged.

DETAILS
Rigid tester height35mm. Bottom stop atZ5. Front of the top-stop underside
atZ32, sloping45degrees toward the rear. The shorter TPU pad has a matching
top bevel with0.3mm vertical clearance. Front top edge atZ31.7,3.3mm below
the tester rim; front contact height26.7mm. Pad thickness3.65mm, contact
width60mm, rear dovetail width64mm and1.5mm protrusion remain.
The pad bottom rests on the bottom stop. Rear relief channels leave the
1.2mm contact skin and a solid band below the new beveled top.
Preview uses the current+0.15mm profile allowance.

RETENTION
Dovetails block pulling directly away from the wall. The bottom stop blocks
downward travel; the broad fixed top stop blocks upward sliding. Installation
and deliberate removal require flexing the TPU pad into/out of the closed
track. The user tested the flex-in concept; no deformation/force simulation
or physical test of THIS exact revised geometry has been performed.
The pad should not be rigidly slid in through the now-closed top.

VALIDATION
Two valid single CAD solids; no seated volumetric overlap.0.2mm upward
clearance remains; a0.6mm upward displacement intersects the top stop.
A0.5mm downward displacement intersects the bottom stop, and1mm straight
normal pullout intersects the dovetails. These checks demonstrate rigid-body
capture only, not holding force or resistance to deformation during removal.

The geometric overhang audit passed with zero off-bed surface area beyond
46degrees for the rigid holder upright AND flat on its back, and for the
TPU pad flat on its contact face. The small threshold allowance is for
tessellation near45degree slopes. It is not printer-profile slicing or
physical proof of support-free print quality. The top stop's underside is
45degrees specifically to avoid a flat unsupported ceiling when upright.

FILES
V3_Captured_Pad_Tester_CAD_Preview.png: assembly and center cutaway.
V3_Fixed_Top_Stop_CAD_Section.png: enlarged top-stop section.
V3_Captured_Pad_Test_Assembly_CAD_PREVIEW.step: separate colored components.
Individual assembly-coordinate and print-orientation STEP files, validation,
source and hashes. Images are rendered from actual CAD geometry.
No printable STL is supplied in this preview package.

This shorter V3 pad is not the prior open-track V2 pad. Both V3 pad and
closed holder will need matching files for the eventual test print.
