"""Preview of a flex-in TPU pad captured by fixed, printable stops."""
from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-captured-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def prism_yz(points,x=-40,length=80):
    vs=[cq.Vector(x,y,z) for y,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(vs+[vs[0]]),[],cq.Vector(length,0,0))
points=[(-30,0),(30,0),(30,1.15),(32,3.65),(-32,3.65),(-30,1.15)]
def profile():return cq.Workplane('XY').polyline(points).close()
# The channel stops below the rim instead of opening through it. From the
# front hard-face datumY1.5 its roof slopes downward toward the rear at45deg.
channel=profile().offset2D(.15).extrude(30.2).val().translate((0,0,5))
below_roof=prism_yz([(-.5,5),(9.5,5),(9.5,24),(1.5,32),(-.5,32)])
support=box(-38,1.5,0,76,7.65,35).cut(channel.intersect(below_roof))
# The pad has a matching beveled top,0.3mm below the roof. Its front top
# isZ31.7 (3.3mm below the rim); bottom rests on the existingZ5 stop.
pad=profile().extrude(30).val().translate((0,0,5))
pad_limit=prism_yz([(-.5,5),(9.5,5),(9.5,23.7),(1.5,31.7),(-.5,31.7)])
pad=pad.intersect(pad_limit)
for x in np.arange(-22,25,8):pad=pad.cut(box(float(x)-2,1.2,10,4,2.45,16))
assert support.isValid() and len(support.Solids())==1
assert pad.isValid() and len(pad.Solids())==1
v=support.intersect(pad).Volume();assert v<1e-5
assert support.intersect(pad.translate((0,0,.2))).Volume()<1e-5
assert support.intersect(pad.translate((0,0,.6))).Volume()>1e-5
assert support.intersect(pad.translate((0,0,-.5))).Volume()>1e-5
assert support.intersect(pad.translate((0,-1,0))).Volume()>1e-5
def mesh(p):
    v,f=p.tessellate(.015,.05)
    return np.array([p.toTuple() for p in v])[np.array(f)]
def arrays(name,parts):np.savez_compressed(OUT/(name+'.npz'),**{n:mesh(p) for n,p in parts.items()})
arrays('assembled',{'rigid':support,'TPU':pad})
# An exploded view is a separation for inspection, not an installation path.
arrays('exploded',{'rigid':support,'TPU':pad.translate((0,-14,0))})
half=box(0,-1,0,40,12,36)
arrays('section',{'rigid':support.intersect(half),'TPU':pad.intersect(half)})
cut=box(0,-1,25,10,12,11)
arrays('top_detail',{'rigid':support.intersect(cut),'TPU':pad.intersect(cut)})
cut=box(-40,-1,17,80,12,5)
arrays('dovetail_section',{'rigid':support.intersect(cut),'TPU':pad.intersect(cut)})
assembly=cq.Assembly(name='V3_FLEX_IN_CAPTURED_PAD_CAD_PREVIEW')
assembly.add(support,name='Rigid_closed_track_with_fixed_sloped_top_stop',color=cq.Color(.56,.63,.67))
assembly.add(pad,name='Shorter_TPU_pad_with_matching_top_bevel',color=cq.Color(1,.52,.12))
assembly.save(str(OUT/'V3_Captured_Pad_Test_Assembly_CAD_PREVIEW.step'))
for n,p in [('Rigid_holder',support),('TPU_pad',pad)]:cq.exporters.export(p,str(OUT/(n+'_Assembly_Coordinates.step')))
orientations={'Rigid_upright':support,
 'Rigid_flat_on_back':support.rotate((0,0,0),(1,0,0),-90).translate((0,0,9.15)),
 'TPU_flat_contact_face':pad.rotate((0,0,0),(1,0,0),90)}
audit={}
for n,p in orientations.items():
    a=mesh(p);norm=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(norm,axis=1)/2
    norm/=np.maximum(2*area,1e-14)[:,None]
    bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
    over=(norm[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
    value=float(area[over].sum());assert value<1e-5,(n,value)
    assert abs(a[:,:,2].min())<1e-5,n
    audit[n]={'off_bed_downward_faces_beyond_46deg_mm2':value,'on_bed':True}
    cq.exporters.export(p,str(OUT/(n+'_Print_Orientation.step')))
    arrays(n,{'TPU' if n.startswith('TPU') else 'rigid':p})
(OUT/'cad_validation.json').write_text(json.dumps({
 'scope':'V3 test-print CAD preview only; previous full insert and tester STLs unchanged',
 'holder_height_mm':35,'bottom_stop_top_z_mm':5,'front_top_stop_underside_z_mm':32,
 'pad_front_top_z_mm':31.7,'pad_front_contact_height_mm':26.7,
 'pad_front_top_below_rim_mm':3.3,'top_stop_underside_slope_deg':45,
 'vertical_roof_clearance_mm':.3,'TPU_protrusion_mm':1.5,'TPU_thickness_mm':3.65,
 'front_contact_width_mm':60,'rear_dovetail_width_mm':64,'profile_offset_mm':.15,
 'valid_single_solid_components':2,'seated_overlap_mm3':v,
 'upward_point6_mm_lift_blocked':True,'downward_point5_mm_motion_blocked':True,
 'normal_pullout_1mm_blocked':True,'thin_hooks_or_external_feet':False,
 'overhang_audit':audit,'slicer_verified':False,
 'physical_flex_installation_of_this_exact_geometry_verified':False,
 'note':'User tested the flex-in concept. CAD treats TPU as rigid and does not simulate insertion deformation or removal force.'},indent=2))
print('V3 CAD valid; top/bottom/dovetail capture checked; both rigid orientations and flat TPU overhang audits passed')
