APACHE4800 — FULL TPU INSERT STL PACKAGE, V1 (TEST FIT FIRST)

PRINT THE TESTER KIT BEFORE COMMITTING TO THE FOUR LARGE RIGID SECTIONS.
This package exports the complete approved sloped-retention CAD unchanged.
All18 STL meshes passed watertightness, winding, positive-volume, bed,
footprint and geometric-overhang checks. This is a print candidate, NOT
a physically proven fit or a printer-profile support/strength guarantee.

CONTENTS / QUANTITIES
Rigid/:4 unique rigid sections BL,BR,TL,TR. Print each once.
TPU/:8 side pads,2 end pads,2 charger liners,2 stopper liners. Print each
named file once:14 TPU pieces. Some geometry is identical; names identify
the assembly location. Upper/Lower refer to the two CAD rows, not heights.
All18 separate files are needed if printing one complete insert.

MATERIAL AND ORIENTATION
Use the same rigid material and settings for the testers and final rigid
parts. TPU95A is the proposed starting material for pads and liners.
STLs are millimeters. Import at100% scale. Do not globally resize the parts.
Preserve supplied orientation; translating/arranging on the bed is fine,
but do not auto-orient them:
  Rigid sections: flat bottom on bed, pockets upward.
  TPU cups: flat floor on bed, upright.
  TPU pads: flat contact face on bed,2.5mm tall, rear channels open upward.
See Required_Print_Orientations.png. A brim may help adhesion and is not
a support. Check first-layer contact and slicer preview on your printer.

The geometry is designed for support-free printing in these orientations:
beveled lip undersides, sloped snap-pocket roofs, hook-free dovetails and
a peaked valve recess. No off-bed downward surface beyond46degrees was
found in the fine STL surface audit. The threshold allows a small tolerance
around intended45degree slopes. This does not model extrusion sagging,
bridging, filament behavior or slicer toolpaths. See validation reports for
the precise checks actually executed and any separate slicing results.

FIT IS STILL A TRIAL
The full-size dovetail seats use the current+0.15mm normal profile offset.
It is NOT an established friction fit. Dovetails stop sideways pullout,
but upward holding depends on TPU fit, full engagement length and creep.
The tester includes0.00 and-0.10mm trials in addition to current+0.15mm.
Those alternate offsets are ONLY in the tester tracks. If another trial
fits better, request a matching full-size seat revision before printing
the large rigid sections. Do not transfer the trial by globally scaling.

ASSEMBLY
Use all four rigid sections from this revision. Original arrangement:
 TL | TR
 ---+---
 BL | BR
Slide rigid sections together in the established order: BL,BR,TL,TR.
Install the TPU pieces after assembling the rigid frame. Stopper cups
span the horizontal seam. Device pads slide downward from open tracks.
There are no thin locking hooks on the Voltra pads. Accessory liners
locate by their beveled flush lip and sloped snap detents; flex the liner
walls inward to release them. Do not force a fit that binds.

FEATURES RETAINED
Side-pad contact width60mm, rear64mm. End-pad contact width50mm, rear54mm.
TPU contact datums remain at the tested openings; adjacent hard walls are
set back0.35mm so TPU contacts first. Retain original bottom and lid foam.
Voltras remain open-bottom, supported by bottom foam, not their shim pins.
All finger-relief scallops are removed. Stopper opening62.97 x43.27mm;
the measured61.08mm stopper has1.89mm total nominal length allowance.
Carabiner slots remain bare rigid material. Pin channels remain8mm wide,
3mm deep from the original contact datum, with10 x4mm top entries.
Valve recess opens underneath and now has a45degree peaked roof.
Accessory mats remain2mm and cover charger logos. Larger modeled charger/
cable packing has only1.14mm nominal remaining top clearance.

CHECK BEFORE FULL USE
Test dovetail insertion, pad lift resistance and accessory snap release.
Check actual sleeved-pin projection, gentle insertion and bottom-foam
seating. Stop if a pin catches rather than accepting device weight on it.
Check case closure without forcing, accessory packing and printed joint
fit. Local strength, TPU creep, physical drop protection and fit are not
established by mesh validation. No G-code or material profile is included.
