"""Export approved CAD as separate print-oriented STLs, with fit-test kit."""
from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-stl-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;CAD=ROOT/'review'
FULL=ROOT/'stl_full';TEST=ROOT/'stl_testers'
FULL.mkdir(exist_ok=True);TEST.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,z,h):return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,0,z))
def wire_rr(l,w,r):return next(f for f in rr(l,w,r,0,1).Faces() if f.normalAt().z<-.99).outerWire()
def flare(l,w,r,z):return cq.Solid.makeLoft([wire_rr(l,w,r).translate((0,0,z)),wire_rr(l+2,w+2,r+1).translate((0,0,z+1))],True)
def prism_yz(points,x,length):
    vs=[cq.Vector(x,y,z) for y,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(vs+[vs[0]]),[],cq.Vector(length,0,0))
manifest={'full':[],'testers':[],'export_tolerance_mm':.015,'angular_tolerance_rad':.05}
def export(shape,path,material,purpose):
    assert shape.isValid() and len(shape.Solids())==1,path.name
    assert shape.exportStl(str(path),tolerance=.015,angularTolerance=.05,relative=False)
    category='full' if path.parent==FULL else 'testers'
    manifest[category].append({'file':path.name,'material':material,'purpose':purpose})
    print('Exported',path.name,flush=True)
for path in sorted(CAD.glob('PRINT_ORIENTATION_*.brep')):
    name=path.stem.removeprefix('PRINT_ORIENTATION_')
    p=cq.Shape.importBrep(str(path))
    material='Rigid' if name.startswith('Rigid') else 'TPU'
    export(p,FULL/f'PRINT_{name}.stl',material,'Full approved assembly component; physical fit unverified')
assert len(manifest['full'])==18

points=[(-30,0),(30,0),(32,2.5),(-32,2.5)]
def profile():return cq.Workplane('XY').polyline(points).close()
pad=profile().extrude(30).val()
for x in np.arange(-22,25,8):pad=pad.cut(box(float(x)-2,1.2,5,4,1.3,20))
flat=pad.rotate((0,0,0),(1,0,0),90).translate((32,30,0))
export(flat,TEST/'TEST_TPU_Dovetail_Pad_30mm.stl','TPU','Reuse this one short pad in all three test tracks')
for tag,offset in [('CURRENT_plus_015',.15),('LINE_TO_LINE_000',0),('INTERFERENCE_minus_010',-.10)]:
    track=profile().offset2D(offset).extrude(30.2).val().translate((0,0,5))
    support=box(-38,.35,0,76,7.65,35).cut(track)
    # Negative trial is intentionally an interfering fit, not nominal assembly.
    overlap=support.intersect(pad.translate((0,0,5))).Volume()
    if offset>=0:assert overlap<1e-5
    else:assert overlap>0
    export(support.translate((38,0,0)),TEST/f'TEST_RIGID_Short_Dovetail_{tag}.stl','Rigid',f'Short fit trial; profile offset {offset:+.2f}mm')
support=box(-38,.35,0,76,7.65,100).cut(profile().offset2D(.15).extrude(90.2).val().translate((0,0,10)))
export(support.translate((38,0,0)),TEST/'OPTIONAL_TEST_RIGID_Full_Height_Dovetail_CURRENT_plus_015.stl','Rigid','Optional 90mm engagement test at exact full-package offset +0.15mm')
p=cq.Shape.importBrep(str(CAD/'PRINT_ORIENTATION_Upper_Voltra_side_pad_1.brep'))
export(p,TEST/'OPTIONAL_TEST_TPU_Full_Height_Dovetail_Pad.stl','TPU','Same pad as full package; use after short trial at current offset')

for kind,L,W,R,floor in [('charger',87,65,4,30),('stopper',62.97,43.27,21.625,55)]:
    seat=rr(L+3.3,W+3.3,R+1.65,floor,100.2-floor)
    seat=seat.fuse(flare(L+3.3,W+3.3,R+1.65,97.85),rr(L+5.3,W+5.3,R+2.65,98.85,1.35))
    outer_y=W/2+1.5
    for d in [1,-1]:
        receiver=prism_yz([(outer_y-.05,90),(outer_y+1.4,90),(outer_y+1.4,95.4),(outer_y-.05,96.85)],-3.6,7.2)
        if d<0:receiver=receiver.mirror('XZ')
        seat=seat.fuse(receiver)
    # Compact standalone holder reproduces the real seating surfaces. Its
    # thick outer shell is a test fixture, not a production quadrant.
    support=rr(L+15,W+15,R+7.5,floor-5,105-floor).cut(seat)
    cup=cq.Shape.importBrep(str(CAD/f'PRINT_ORIENTATION_Upper_{kind}_TPU_liner.brep'))
    assembled_cup=cup.translate((0,0,floor))
    assert support.intersect(assembled_cup).Volume()<1e-4,kind
    assert support.intersect(assembled_cup.translate((0,0,1))).Volume()>1e-5,kind
    holder=support.translate((0,0,5-floor))
    export(holder,TEST/f'TEST_RIGID_{kind.title()}_Snap_Lip_Holder.stl','Rigid','Exact production seat, lip and snap geometry in a standalone holder')
    export(cup,TEST/f'TEST_TPU_{kind.title()}_Liner.stl','TPU','Exact full-package liner; reusable if fit passes')
    a=cq.Assembly(name=kind+'_fit_test')
    a.add(holder,name='Rigid_test_holder',color=cq.Color(.56,.63,.67))
    a.add(cup.translate((0,0,5)),name='TPU_liner',color=cq.Color(1,.52,.12))
    a.save(str(TEST/f'REFERENCE_{kind.title()}_Test_Assembly.step'))
assert len(manifest['testers'])==10
(ROOT/'stl_manifest.json').write_text(json.dumps(manifest,indent=2))
print('18 full STLs and10 tester STLs exported',flush=True)
