from pathlib import Path
import os,json,hashlib
os.environ.setdefault('XDG_CACHE_HOME','/tmp/hisense-scan-v7-cache')
import numpy as np,trimesh,cadquery as cq,manifold3d as md,pymeshlab as pm
from scipy.spatial import cKDTree
ROOT=Path(__file__).parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
SRC=Path('/workspace/exports/hisense-battery-cover')
base=trimesh.load(SRC/'meshfix_candidate.ply',process=True)
assert base.is_watertight and base.is_winding_consistent and base.volume>0
features=json.loads((ROOT/'rail_features.json').read_text())
def solid(mesh):
 s=md.Manifold(md.Mesh(vert_properties=np.asarray(mesh.vertices,dtype=np.float32),tri_verts=np.asarray(mesh.faces,dtype=np.uint32)))
 assert str(s.status())=='Error.NoError',s.status()
 return s
s=solid(base);patches=[];records=[]
for side in [1,-1]:
 ref=features[str(side)];x=ref['tooth_station_X'];top=ref['rail_top_Z']-.15;bottom=top-1.10
 # Read actual outer rail edge from the repaired source section, not a synthetic rail.
 seg=trimesh.intersections.mesh_plane(base,plane_normal=[1,0,0],plane_origin=[x,0,0])
 points=[]
 for edge in seg:
  if not (side*edge[:,1]>14).all():continue
  z0,z1=edge[:,2];ts=[0.,1.]
  if abs(z1-z0)>1e-10:
   for z in [bottom+.15,top-.05]:
    t=(z-z0)/(z1-z0)
    if 0<=t<=1:ts.append(float(t))
  for t in ts:
   p=edge[0]+t*(edge[1]-edge[0])
   if bottom+.15<=p[2]<=top-.05:points.append(p)
 points=np.asarray(points);assert len(points)>2
 outer=float(side*np.max(side*points[:,1]));tip=outer-side*2.16
 # Narrow flat-ended tooth; all added material is inward and below the rail top.
 root=outer-side*.10
 poly=[(x-1.25,root),(x+1.25,root),(x+.4,tip),(x-.4,tip)]
 p=cq.Workplane('XY').polyline(poly).close().extrude(top-bottom).edges('|Z').fillet(.12).val().translate((0,0,bottom))
 v,f=p.tessellate(.012,.06);mesh=trimesh.Trimesh(np.array([q.toTuple() for q in v]),np.array(f),process=True);mesh.fix_normals();patch=solid(mesh)
 overlap=(s^patch).volume();assert overlap>.02,('Patch does not attach to scanned rail',side,overlap)
 before=s.volume();s=s+patch;assert str(s.status())=='Error.NoError'
 records.append({'side':side,'scan_shoulder_X_mm':ref['scan_shoulder_X'],'tooth_station_X_mm':x,'shoulder_to_station_mm':16.07,'scanned_outer_rail_Y_mm':outer,'inward_tip_Y_mm':tip,'combined_section_nominal_mm':2.16,'base_length_mm':2.5,'flat_nose_length_mm':.8,'height_mm':1.10,'top_below_scan_rail_envelope_mm':.15,'rail_overlap_volume_mm3':overlap,'added_volume_mm3':s.volume()-before,'datum_note':'Rail shoulder inferred from scanned step mid-rise; tooth section uses the local scanned outer edge.'})
 patches.append(mesh)
 print('Attached source-based rail repair',side,records[-1],flush=True)
res=s.to_mesh();final=trimesh.Trimesh(res.vert_properties[:,:3],res.tri_verts,process=True);final.fix_normals();assert final.is_watertight and final.is_winding_consistent and final.volume>0
# Entire rear is protected from the local rail repair operations.
rng=np.random.default_rng(27);rear_vertices=base.vertices[base.vertices[:,0]<-20];sample=rear_vertices[rng.choice(len(rear_vertices),min(4000,len(rear_vertices)),replace=False)]
_,dist,_=trimesh.proximity.closest_point(final,sample);assert float(dist.max())<1e-4,float(dist.max())
# Distance from the dense original scan to the repaired surface at the rear.
raw=trimesh.load(SRC/'surface_pca.ply',process=False);rv=raw.vertices[raw.vertices[:,0]<-26];rawsample=rv[rng.choice(len(rv),min(6000,len(rv)),replace=False)]
_,rawdist,_=trimesh.proximity.closest_point(final,rawsample)
print('Rear kept unchanged from repaired scan; original-scan rear distance percentiles',np.quantile(rawdist,[.5,.95,.99,1]),flush=True)
# Save comparison geometry in source coordinates, before bed placement.
final.export(OUT/'Source_Coordinates_Repaired_Cover.ply')
shift=np.array([-final.bounds[:,0].mean(),-final.bounds[:,1].mean(),-final.bounds[0,2]])
final.apply_translation(shift);final.export(OUT/'Hisense_EN2A27_Scan_Based_V7.stl');final.export(OUT/'Hisense_EN2A27_Scan_Based_V7.3mf')
loaded=trimesh.load(OUT/'Hisense_EN2A27_Scan_Based_V7.stl',process=True);assert loaded.is_watertight and loaded.is_winding_consistent and len(loaded.split())==1 and loaded.volume>0
ms=pm.MeshSet();ms.add_mesh(pm.Mesh(loaded.vertices,loaded.faces));ms.apply_filter('compute_selection_by_self_intersections_per_face');count=ms.current_mesh().selected_face_number();assert count==0,count
# Actual direct source-versus-repaired sections for comparison.
np.savez_compressed(OUT/'scenes.npz',full=loaded.triangles,rear=loaded.triangles[(loaded.triangles[:,:,0]<(-24+shift[0])).all(axis=1)])
report={'model':'Hisense EN2A27','revision':'V7 scan-based repair; replaces approximated CAD body','source_3MF':'Mesh_hisense remote battery cover.3mf','source_3MF_sha256':hashlib.sha256(Path('/workspace/attachments/148bfc86-f98d-41d2-b447-8e696188b3df/Mesh_hisense remote battery cover.3mf').read_bytes()).hexdigest(),'geometry_source':'Original scan; cleaned/closed mesh body plus local rail repair patches','no_synthetic_rear_curve':True,'no_separate_approximated_rear_catch':True,'rear_shape_unchanged_from_repaired_scan_max_error_mm':float(dist.max()),'dense_original_scan_rear_to_final_distance_mm':{'median':float(np.quantile(rawdist,.5)),'p95':float(np.quantile(rawdist,.95)),'p99':float(np.quantile(rawdist,.99)),'max':float(rawdist.max())},'rail_repairs':records,'STL_watertight':True,'STL_one_connected_solid':True,'STL_consistent_winding':True,'STL_self_intersecting_faces':count,'STL_triangles':len(loaded.faces),'volume_mm3':float(loaded.volume),'overall_dimensions_including_original_end_tabs_mm':loaded.extents.tolist(),'bed_translation_mm':shift.tolist(),'units':'millimeters','intentional_scaling_applied':False,'physical_fit_verified':False,'slicer_verified':False,'notes':['This is a scan-based mesh, not a newly invented parametric body. Fine scan texture and marker impressions may remain.','The original scanned rear surfaces and integrated lip are retained; noise reduction/closure came from the prior mesh repair, not V1-V6 rear geometry.','Rail repair uses measured2.16mm combined section and16.07mm shoulder offset with scan-inferred datum and narrow photo-guided profile.','The source scale is retained. Caliper body76.02x39.02 and local2.20mm thickness are cross-reference measurements, not an imposed constant shell profile.','The original end tabs remain scan-derived. Attachment and battery clearance still require physical fit confirmation.']}
(OUT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
