"""Render tessellated CAD using an orthographic CPU depth buffer."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/voltra-tpu-mpl')
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from matplotlib.font_manager import findfont
OUT=Path(__file__).resolve().parent/'output'
FONT=findfont('DejaVu Sans')
def text(d,s,x,y,size=30,anchor='mt',fill='#253d48'):
    d.text((x,y),s,font=ImageFont.truetype(FONT,size),fill=fill,anchor=anchor)
def render(file,view,width,height):
    arrays=np.load(OUT/file)
    triangles=[];base=[]
    for name in arrays.files:
        tri=arrays[name];triangles.append(tri)
        col=(1.,.52,.12) if name.startswith('TPU') else (.56,.63,.67)
        base.extend([col]*len(tri))
    a=np.concatenate(triangles);base=np.array(base)
    normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0])
    normal/=np.maximum(np.linalg.norm(normal,axis=1),1e-12)[:,None]
    view=np.array(view,dtype=float);view/=np.linalg.norm(view)
    right=np.cross([0,0,1],view)
    if np.linalg.norm(right)<1e-8:right=np.array([1.,0,0])
    right/=np.linalg.norm(right);up=np.cross(view,right)
    light=view+np.array([-.2,-.3,.2]);light/=np.linalg.norm(light)
    shade=.50+.50*np.maximum(normal@light,0)
    # Distinguish actual recessed surfaces in the engineering views.
    flex_floor=(np.max(np.abs(a[:,:,2]-1.2),axis=1)<1e-4)&(base[:,0]>.9)
    shade[flex_floor]*=.70
    if file=='valve_detail.npz':
        back=np.max(np.abs(a[:,:,1]+154.04125),axis=1)<1e-4
        shade[back]*=.55
    # Tonal distinction on recessed rigid floors makes bare carabiner slots
    # readable in the orthographic top view; this is not a material change.
    recessed=(np.max(np.abs(a[:,:,2]-65),axis=1)<1e-4)&(base[:,0]<.9)
    shade[recessed]*=.60
    rgb=np.clip(base*shade[:,None]*255,0,255).astype(np.uint8)
    proj=np.stack([a@right,a@up,a@view],axis=-1)
    lo=proj[:,:,:2].reshape(-1,2).min(axis=0)
    hi=proj[:,:,:2].reshape(-1,2).max(axis=0)
    scale=min((width-120)/(hi[0]-lo[0]),(height-100)/(hi[1]-lo[1]))
    center=(lo+hi)/2
    proj[:,:,0]=(proj[:,:,0]-center[0])*scale+width/2
    proj[:,:,1]=height/2-(proj[:,:,1]-center[1])*scale
    canvas=np.full((height,width,3),249,np.uint8)
    zb=np.full((height,width),-np.inf)
    for i,t in enumerate(proj):
        if normal[i]@view<=0:continue
        x0=max(0,int(np.floor(t[:,0].min())));x1=min(width-1,int(np.ceil(t[:,0].max())))
        y0=max(0,int(np.floor(t[:,1].min())));y1=min(height-1,int(np.ceil(t[:,1].max())))
        if x1<x0 or y1<y0:continue
        xs=np.arange(x0,x1+1)[None,:]+.5;ys=np.arange(y0,y1+1)[:,None]+.5
        den=(t[1,1]-t[2,1])*(t[0,0]-t[2,0])+(t[2,0]-t[1,0])*(t[0,1]-t[2,1])
        if abs(den)<1e-12:continue
        w0=((t[1,1]-t[2,1])*(xs-t[2,0])+(t[2,0]-t[1,0])*(ys-t[2,1]))/den
        w1=((t[2,1]-t[0,1])*(xs-t[2,0])+(t[0,0]-t[2,0])*(ys-t[2,1]))/den
        w2=1-w0-w1;depth=w0*t[0,2]+w1*t[1,2]+w2*t[2,2]
        local=zb[y0:y1+1,x0:x1+1]
        mask=(w0>=-1e-7)&(w1>=-1e-7)&(w2>=-1e-7)&(depth>local)
        local[mask]=depth[mask]
        canvas[y0:y1+1,x0:x1+1][mask]=rgb[i]
    def project(p):
        p=np.array(p)
        return ((p@right-center[0])*scale+width/2,
                height/2-(p@up-center[1])*scale)
    return Image.fromarray(canvas),project

