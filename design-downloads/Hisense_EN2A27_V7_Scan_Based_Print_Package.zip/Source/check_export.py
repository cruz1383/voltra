from pathlib import Path
import trimesh,numpy as np,json
r=Path(__file__).parent;out=r/'output'
a=trimesh.load(out/'Hisense_EN2A27_Scan_Based_V7.stl',process=True);b=trimesh.load(out/'Hisense_EN2A27_Scan_Based_V7.3mf',force='mesh',process=True)
assert a.is_watertight and b.is_watertight and a.is_winding_consistent and b.is_winding_consistent
assert np.allclose(a.bounds,b.bounds,atol=1e-5) and abs(a.volume-b.volume)<.01
assert abs(a.bounds[0,2])<1e-5
raw=trimesh.load('/workspace/exports/hisense-battery-cover/surface_pca.ply',process=False)
final=trimesh.load(out/'Source_Coordinates_Repaired_Cover.ply',process=False)
v=raw.vertices;mask=(v[:,0]>-34.5)&(v[:,0]<-31.5)&(abs(v[:,1]+1)<6)&(v[:,2]>3.0)
p=v[mask];rng=np.random.default_rng(11);p=p[rng.choice(len(p),min(4000,len(p)),replace=False)]
closest,d,_=trimesh.proximity.closest_point(final,p)
rpt=json.loads((out/'validation.json').read_text());rpt['STL_3MF_bounds_and_volume_match']=True;rpt['retaining_lip_source_distance_mm']={'median':float(np.quantile(d,.5)),'p95':float(np.quantile(d,.95)),'max':float(d.max())};rpt['retaining_lip_samples']=len(p)
(out/'validation.json').write_text(json.dumps(rpt,indent=2));print('STL/3MF matched. Retaining lip source distances',rpt['retaining_lip_source_distance_mm'])
