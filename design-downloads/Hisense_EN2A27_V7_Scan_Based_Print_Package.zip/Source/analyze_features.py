from pathlib import Path
import trimesh,numpy as np,json
from scipy.optimize import least_squares
root=Path(__file__).parent
raw=trimesh.load('/workspace/exports/hisense-battery-cover/surface_pca.ply',process=False)
c=raw.triangles_center;n=raw.face_normals;a=raw.area_faces
result={}
for side in [1,-1]:
 # Vertical rail outer surfaces; fit in a narrow central band to avoid tabs/end return.
 sel=(side*c[:,1]>15)&(side*c[:,1]<22)&(side*n[:,1]>.70)&(abs(n[:,2])<.55)&(c[:,0]>-8)&(c[:,0]<25)&(c[:,2]>3.4)&(a>.0008)
 p=c[sel]
 if len(p)<20:
  sel=(side*c[:,1]>15)&(side*c[:,1]<22)&(abs(n[:,1])>.80)&(abs(n[:,2])<.45)&(c[:,0]>-8)&(c[:,0]<25)&(c[:,2]>3.4)&(a>.0008);p=c[sel]
 A=np.column_stack([p[:,0],np.ones(len(p))]);fit=least_squares(lambda b:A@b-p[:,1],np.linalg.lstsq(A,p[:,1],rcond=None)[0],loss='soft_l1',f_scale=.05)
 ay,by=fit.x
 # Detect the rail shoulder from the top-edge rise near the rounded end.
 v=raw.vertices;profile=[]
 for x in np.arange(-19,-7,.2):
  q=v[(abs(v[:,0]-x)<.17)&(side*v[:,1]>16)&(side*v[:,1]<22)]
  if len(q)>5:profile.append([float(x),float(np.quantile(q[:,2],.98))])
 prof=np.array(profile)
 # Mid-height of the shoulder step is a stable scan datum.
 lower=float(np.median(prof[:12,1]));upper=float(np.median(prof[-12:,1]));level=(lower+upper)/2
 shoulder=float(np.interp(level,np.maximum.accumulate(prof[:,1]),prof[:,0]))
 station=shoulder+16.07
 # Local rail top comes from intact top edges surrounding the damaged station.
 q=v[(abs(v[:,0]-station)<3)&(side*v[:,1]>16)&(side*v[:,1]<22)]
 top=float(np.quantile(q[:,2],.98));outer=float(ay*station+by)
 result[str(side)]={'rail_outer_Y_fit':[float(ay),float(by)],'rail_outer_Y_at_tooth':outer,'scan_shoulder_X':shoulder,'shoulder_detection':'Mid-rise of scanned rail top step; scan-derived datum, not new caliper measurement','tooth_station_X':station,'rail_top_Z':top,'shoulder_profile':profile,'rail_fit_samples':len(p)}
print(json.dumps(result,indent=2));(root/'rail_features.json').write_text(json.dumps(result,indent=2))
