from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/hisense-v7-mpl')
import numpy as np,trimesh,json
from cad_render import *
r=Path(__file__).parent;raw=trimesh.load('/workspace/exports/hisense-battery-cover/surface_pca.ply',process=False);final=trimesh.load(OUT/'Source_Coordinates_Repaired_Cover.ply',process=False)
for label,m in [('original',raw),('repaired',final)]:
 sel=np.where(m.triangles[:,:,0].max(axis=1)<-26)[0];p=m.submesh([sel],append=True,repair=False)
 if len(p.faces)>80000:p=p.simplify_quadric_decimation(face_count=80000)
 a=p.triangles;c=a.mean(axis=1);highlight=(c[:,0]>-35.0)&(c[:,0]<-31)&(abs(c[:,1]+1)<7)&(c[:,2]>3.7)
 np.savez_compressed(OUT/(label+'_rear.npz'),rigid_body=a[~highlight],TPU_lip_highlight=a[highlight])
im=Image.new('RGB',(2000,1450),'#f9f9f9')
for name,v,pos in [('original_rear.npz',[1,-.7,.4],(0,190)),('repaired_rear.npz',[1,-.7,.4],(1000,190)),('original_rear.npz',[0,-1,.1],(0,850)),('repaired_rear.npz',[0,-1,.1],(1000,850))]:
 pic,_=render(name,v,1000,520);im.paste(pic,pos)
d=ImageDraw.Draw(im);text(d,'V7 — actual scanned rear curve and retaining lip',1000,25,38)
text(d,'Original scan',500,140,31);text(d,'Repaired scan used for V7',1500,140,31)
text(d,'Orange highlights the retaining lip; the entire cover is one rigid printed part.',1000,770,26)
text(d,'No replacement rear curve or separate guessed catch | Physical fit still requires testing',1000,1390,25)
im.save(OUT/'Hisense_EN2A27_V7_Rear_Scan_Comparison.png')
# Full source-derived body after bed placement.
m=trimesh.load(OUT/'Hisense_EN2A27_Scan_Based_V7.stl',process=True);p=m.simplify_quadric_decimation(face_count=100000) if len(m.faces)>100000 else m
np.savez_compressed(OUT/'full_view.npz',rigid_cover=p.triangles)
im=Image.new('RGB',(1800,1350),'#f9f9f9')
for v,pos in [([0,0,1],(0,150)),([1,-1,.8],(900,150)),([0,-1,.2],(0,780)),([1,0,.2],(900,780))]:
 pic,_=render('full_view.npz',v,900,500);im.paste(pic,pos)
d=ImageDraw.Draw(im);text(d,'Hisense EN2A27 — V7 scan-based repair',900,20,38)
text(d,'Original body, rear return, integrated lip and end tabs retained; local rail repairs added',900,90,24)
text(d,'Millimeters, 100% scale | Fine scan texture retained | Watertight mesh; physical fit unverified',900,1300,22)
im.save(OUT/'Hisense_EN2A27_V7_Full_Preview.png')
# Direct unaltered-coordinate section overlays, including open scan edges.
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
fig,axs=plt.subplots(3,1,figsize=(13,12),sharex=True)
for ax,y in zip(axs,[-1,-5,4]):
 for mesh,color,lw in [(raw,'#1865b4',1.8),(final,'#df7500',.8)]:
  seg=trimesh.intersections.mesh_plane(mesh,plane_normal=[0,1,0],plane_origin=[0,y,0]);seg=seg[(seg[:,:,0]<-20).all(axis=1)]
  ax.add_collection(LineCollection(seg[:,:,[0,2]],colors=color,linewidths=lw))
 ax.set_xlim(-39,-20);ax.set_ylim(-3.5,7.5);ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.25);ax.set_title(f'Rear section at source Y={y} mm');ax.set_ylabel('Z (mm)')
axs[-1].set_xlabel('X (mm) in the same aligned source coordinates')
fig.legend(handles=[Line2D([],[],color='#1865b4',lw=2,label='Original scan'),Line2D([],[],color='#df7500',lw=1,label='V7 repaired scan')],loc='upper right')
fig.suptitle('V7 rear profiles overlaid on original scan — no invented rear curve');fig.tight_layout(rect=[0,0,1,.96]);fig.savefig(OUT/'Hisense_EN2A27_V7_Rear_Profile_Overlay.png',dpi=150)
print('Rendered source comparison, full view and original/repaired section overlay')
