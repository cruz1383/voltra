HISENSE EN2A27 — V7 SCAN-BASED REPAIR
Use this in place of the V1-V6 approximated CAD bodies.

WHAT CHANGED
The original scanned body is now the geometric reference. Rear curvature,
turned-up return and integrated retaining lip are retained from the scan;
there is no hand-drawn replacement rear curve or separate guessed catch.
The original end tabs and original rail surfaces remain scan-derived.

Scan defects were cleaned/closed, disconnected debris removed, and mesh
intersections repaired. Two small local inward rail repairs use the confirmed
2.16 mm COMBINED rail/tooth section and16.07 mm offset from the actual scanned
rail shoulder. The shoulder is detected from the scan's step rise; this is
an inferred datum, not a new caliper measurement. Tooth base2.5 mm, nose0.8 mm,
rounded corners and vertical placement remain photo/scan-guided estimates.
The reference shoulder locations in the prior CAD were not source-traced;
V7 uses the shoulder locations present in the scan instead. See validation.

SOURCE FIDELITY
The rear was not changed by the local rail repair operations. Compared with
the dense original scan,95% of6000 sampled rear points are within0.030 mm
of the repaired surface;99% within0.060 mm. Largest deviations are at local
scan damage/holes; full statistics are in validation.json. On the retaining
lip specifically,95% of4000 points are within0.024 mm; max0.077 mm.
The section overlay and original/repaired views show the actual geometry.
Orange in the comparison highlights the lip:the entire part prints in one
rigid material. No TPU or separate colored part is required.

SCALE / DIMENSIONS
Original scan units:mm. No intentional scaling applied. Import at100%.
Overall scan-derived envelope including projecting end tabs is approximately
79.12 x39.11 x8.91 mm. The caliper body measurements76.02 x39.02 mm and local
2.20 mm thickness remain cross-reference measurements. They have not been
used to replace the actual curved/variable-wall scan with a constant-thickness
CAD sheet. Do not assume the overall scan length excludes its end tabs.
Fine scan texture and marker impressions may remain. This version prioritizes
faithful functional shape and mesh repair over the smooth but incorrect
parametric bodies of V1-V6.

PRINTING
STL and3MF contain the same single solid geometry. The3MF is a mesh file,
not a saved printer/material project or pre-sliced plate. There is no G-code.
The part is oriented broad face horizontal, inner features upward, bottom
at Z0. Curvature means it does not sit flat over its whole area. Inspect
supports under curved edges, end tabs and the integrated retaining lip.
Under-lip supports may need to start on the model, not just the build plate.
This file has not been checked in a printer-specific slicer profile and is
not certified support-free. Keep delicate retention features intact during
support removal. PETG with a known calibrated profile is a reasonable starting
material;0.16 mm layer and3-4 walls with a0.4 mm nozzle are starting settings,
not a validated profile. Check the preview for complete thin-feature paths.

FIT STATUS
One closed/watertight connected solid, positive volume, consistent winding,
zero detected self-intersecting faces. STL and3MF bounds and volumes match.
Those are geometry checks. Latch engagement, rail clearance, battery clearance,
printed fit and durability are not physically verified. Treat the first
print as a fit check and do not force it into a binding remote opening.

CONTENTS
Hisense_EN2A27_Scan_Based_V7.stl:print mesh.
Hisense_EN2A27_Scan_Based_V7.3mf:same print mesh in compressed3MF format.
Hisense_EN2A27_V7_Full_Preview.png:four views of the scan-based repair.
Hisense_EN2A27_V7_Rear_Scan_Comparison.png:original versus repaired rear.
Hisense_EN2A27_V7_Rear_Profile_Overlay.png:direct section overlays.
validation.json:checks, source comparison and rail repair datums.
Source/:build/analysis scripts, requiring original scan and repair intermediates
at their documented local paths. The supplied STL/3MF are standalone.
SHA256SUMS.txt:package file hashes, excluding itself.
