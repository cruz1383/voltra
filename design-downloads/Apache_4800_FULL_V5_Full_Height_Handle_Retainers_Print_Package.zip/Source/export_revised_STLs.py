from pathlib import Path
import cadquery as cq
root=Path(__file__).resolve().parent
out=root.parent/'Regenerated_STLs';out.mkdir(exist_ok=True)
for name,filename in [('rigid_BL','PRINT_BL.stl'),('rigid_TR','PRINT_TR.stl'),('TPU_Existing_TPU_16','PRINT_Straight_Handle_Pad_QTY2.stl')]:
 s=cq.Shape.importBrep(str(root/'CAD'/(name+'.brep')))
 if name.startswith('rigid'):
  b=s.BoundingBox();s=s.translate((1-b.xmin,1-b.ymin,0))
 else:
  s=s.rotate((0,0,0),(0,1,0),90);b=s.BoundingBox();s=s.translate((1-b.xmin,1-b.ymin,-b.zmin))
 assert s.exportStl(str(out/filename),tolerance=.015,angularTolerance=.05,relative=False)
 print(filename)
