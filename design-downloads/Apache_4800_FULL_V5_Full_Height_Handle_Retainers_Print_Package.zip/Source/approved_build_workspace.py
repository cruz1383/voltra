import cadquery as cq,json
from pathlib import Path
out=Path('work/full_height_recessed');out.mkdir(exist_ok=True)
old=cq.Shape.importBrep('work/rigid_TR.brep');origpad=cq.Shape.importBrep('work/TPU_Existing_TPU_16.brep')
face=128.2375;low=45.35;high=162-low
# Inward capture lives entirely behind the original rigid face. No outward rails.
profile=[(face,42),(face,low),(129.0875,43.85),(129.2375,43.65),(129.6,43.65),(129.6,42)]
lo=cq.Workplane('XY',origin=(0,0,41.5)).polyline(profile).close().extrude(32.2).val()
hi=lo.mirror('XZ', (0,81,0))
new=old.fuse(lo,hi).clean()
# Keep the original 74 mm rear envelope and front contact face. Reprofile only
# the mating edge bevels so they fit behind the stronger recessed side lips.
neck=low+.15
padprofile=[(127.4375,45.5),(face,neck),(129.0875,44),(129.3,44),(129.3,118),(129.0875,118),(face,162-neck),(127.4375,116.5)]
envelope=cq.Workplane('XY',origin=(0,0,40)).polyline(padprofile).close().extrude(35).val()
pad=origpad.intersect(envelope).clean()
changes={'rigid_TR':new,'TPU_Existing_TPU_16':pad}
bl=cq.Shape.importBrep('work/rigid_BL.brep');changes['rigid_BL']=bl.fuse(lo.rotate((0,0,0),(0,0,1),180),hi.rotate((0,0,0),(0,0,1),180)).clean()
changes['TPU_Existing_TPU_17']=pad.rotate((0,0,0),(0,0,1),180)
report={'status':'CAD REVIEW only - no print exports','profile':'Thin smooth recessed dovetail with side retainers extending over the full 32.2 mm pad height','retainer_z_mm':[41.5,73.7],'source':'Original uploaded V4 STEP','proposed_dimensions_mm':{'seat_opening_before':73.0333333333,'seat_opening_after':high-low,'pad_rear_length':74,'side_capture_nominal_per_end':(74-high+low)/2,'side_capture_if_printed_at_73_02_per_end':(73.02-high+low)/2,'inward_addition_per_end':low-44.4833333333,'pad_side_clearance_at_wall_face':.15},'checks':{}}
for n,s in changes.items():
 assert s.isValid() and len(s.Solids())==1,n
 rec={'valid':True,'solids':1}
 original=cq.Shape.importBrep('work/'+n+'.brep')
 if n.startswith('rigid'):
  removed=original.cut(s).Volume();assert removed<1e-5;rec['original_rigid_material_removed_mm3']=removed
 s.exportBrep('work/'+n+'_full_height.brep');report['checks'][n]=rec
added=new.cut(old);b=added.BoundingBox();assert b.xmin>=face-1e-6
report['checks']['no_outward_projection']=True
for pn,rn in [('TPU_Existing_TPU_16','rigid_TR'),('TPU_Existing_TPU_17','rigid_BL')]:
 v=changes[pn].intersect(changes[rn]).Volume();assert v<1e-5,(pn,v);report['checks'][pn]['seated_overlap_mm3']=v
# Contact face and overall envelopes are unchanged; the side bevels alone are cut.
for key in ['xmin','xmax','ymin','ymax','zmin','zmax']:assert abs(getattr(pad.BoundingBox(),key)-getattr(origpad.BoundingBox(),key))<1e-5,key
report['checks']['pad_envelope_unchanged']=True
added.exportBrep('work/full_height_recessed_added.brep')
json.dump(report,open(out/'validation.json','w'),indent=2);print(json.dumps(report,indent=2),flush=True)
