from pathlib import Path
from collections import Counter
import numpy as np,json,struct,math
root=Path('work/release_v5');out=root/'Full_Package';manifest=json.loads((root/'manifest.json').read_text());report={}
dt=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')])
for e in manifest['full']:
 path=out/e['package_path'];d=path.read_bytes();n=struct.unpack_from('<I',d,80)[0];assert len(d)==84+50*n
 a=np.frombuffer(d,dtype=dt,count=n,offset=84)['points'].astype(float);assert np.isfinite(a).all()
 xyz=a.reshape(-1,3);verts,vi=np.unique(np.round(xyz,5),axis=0,return_inverse=True);vi=vi.reshape(-1,3)
 assert (vi[:,0]!=vi[:,1]).all() and (vi[:,1]!=vi[:,2]).all() and (vi[:,0]!=vi[:,2]).all()
 edges=Counter();winding=Counter()
 for tri in vi:
  for u,v in [(int(tri[0]),int(tri[1])),(int(tri[1]),int(tri[2])),(int(tri[2]),int(tri[0]))]:
   k=(min(u,v),max(u,v));edges[k]+=1;winding[k]+=1 if u<v else -1
 assert all(x==2 for x in edges.values()),(path.name,'open/nonmanifold edges')
 assert all(x==0 for x in winding.values()),(path.name,'inconsistent winding')
 # Connected-component count prevents disconnected fragments in the exported STL.
 parent=np.arange(len(verts))
 def find(x):
  while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
  return x
 for u,v in edges:
  ru,rv=find(u),find(v)
  if ru!=rv:parent[ru]=rv
 comps=len({find(i) for i in range(len(verts))});assert comps==1,(path.name,'disconnected pieces',comps)
 mn=xyz.min(axis=0);mx=xyz.max(axis=0);assert abs(mn[2])<1e-4,(path.name,'off bed')
 assert (mx[0]-mn[0]+10)<=256 and (mx[1]-mn[1]+10)<=256,(path.name,'bed envelope')
 v=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(v,axis=1)/2;assert (area>1e-10).all();norm=v/(2*area[:,None]);bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
 bad=(norm[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7);down=float(area[bad].sum());assert down<1e-4,(path.name,'overhang audit',down)
 vol=float(np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6);assert vol>0
 err=abs(vol-e['CAD_volume_mm3'])/e['CAD_volume_mm3'];assert err<.001,(path.name,'volume mismatch',err)
 report[e['package_path']]={'triangles':n,'watertight':True,'consistent_winding':True,'connected_components':comps,'mesh_volume_mm3':vol,'relative_volume_error_to_CAD':err,'bounds_min_mm':mn.tolist(),'bounds_max_mm':mx.tolist(),'on_bed':True,'fits_256mm_bed_with_5mm_brim':True,'downward_area_beyond_46deg_mm2':down,'slicer_verified':False,'physical_fit_verified':False,'changed_from_V4':e['changed_from_V4']}
 print('Passed',path.name,n,'triangles',flush=True)
(out/'Reports/mesh_validation.json').write_text(json.dumps(report,indent=2));print('All 9 STL meshes passed',flush=True)
