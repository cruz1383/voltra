APACHE 4800 V5 - FULL-HEIGHT RECESSED HANDLE RETAINERS

User-approved CAD revision. Exported STL geometry is checked; physical fit,
retention force, TPU shrinkage, strength and printer-specific slicing are unverified.

REPLACING AN EXISTING MATCHING V4 SET
Reprint Rigid/PRINT_BL.stl x1, Rigid/PRINT_TR.stl x1, and
TPU/PRINT_Straight_Handle_Pad_QTY2.stl x2.
These rigid sections and revised handle pads are a matched set.
BR, TL, eight side pads, two screen-end pads and the four shortened accessory/
cable-end liners are unchanged from the published FULL V4 package and may be reused.
The six unchanged STL files are byte-identical to that package.

APPROVED CHANGE
Return to the thin 1.65 mm handle pad with the smooth straight-front/flared-rear
profile. Both side retainers now cover the full 32.2 mm pad height, Z=41.5 to
73.7, instead of just the middle 26.2 mm. The recessed mouth is 71.30 mm;
nominal 74.00 mm pad rear gives 1.35 mm centered capture per end.
No outward rails or added top hooks. Original pad envelope, contact plane,
rigid wall material, wire channels and other components are retained.
The checked divider web remains 3.1125 mm at Y=60, Z=55.
This is NOT the rejected 3.65 mm thick-pad trial or earlier hook/rib proposals.

PRINT ORIENTATION AND SCALE
Import at 100% scale in millimeters. All files are already oriented on the bed.
Rigid sections: bottom-down, 100 mm tall, as in V4.
IMPORTANT: Revised handle pad is now WIDE REAR FACE DOWN, contact face UP.
Keep the supplied orientation. Front-face-down leaves unsupported rear bevels.
Handle STL bounds are 32.2 x 74.0 x 1.65 mm (X/Y/Z). No shrinkage compensation
is baked in. Measure the cooled pad's widest rear ends; the nominal target is
74.00 mm. The previously reported 73.02 mm result is not a new CAD target.
Other TPU orientations match V4: side/end contact faces down; short liners upright.
Use your successful rigid and TPU settings. No G-code or machine profiles supplied.
Inspect the actual slice preview before printing. Full-size installation and
retention still need a physical check; do not force the pad straight through
as a rigid piece. Flex it gently into the recessed capture, with the top bevel
aligned with the original upper stop.

COMPLETE SET
9 unique STLs; print 20 total parts. See PRINT_QUANTITIES.json.
4 rigid sections x1 each; side pad x8; screen-end pad x2; handle pad x2;
square accessory short liner x2; cable-end short liner x2.
Filename QTY values specify required copies, not copies already inside a file.

CHECKS AND REFERENCES
All nine meshes passed closed/manifold edges, consistent winding, one connected
component, positive volume, nondegenerate faces, on-bed bounds, dimensional bed
fit with 5 mm brim allowance, CAD-volume comparison and a 46-degree geometric
overhang audit in their supplied orientations. This does not establish printer-
specific support needs, dimensional accuracy or print readiness by itself.
Reference/ contains the revised colored assembly STEP and approved CAD image.
Do not print the assembled STEP as one fused part. Reports/ contains checks.
Source/CAD contains standalone revised BREP solids; Source/export_revised_STLs.py
can re-export the three changed files with CadQuery installed.
Source/approved_build_workspace.py records the design-generation step, but needs
the original V4 per-component BREP files at its documented work/ paths.
SHA256SUMS.txt records every packaged file except itself.
