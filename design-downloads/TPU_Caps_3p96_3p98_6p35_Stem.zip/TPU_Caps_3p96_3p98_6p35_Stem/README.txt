VOLTRA TPU CAPS —3.96 AND3.98 TIP-SPAN FIT TRIALS

User reports dried-filament3.94 print remains slightly loose. New tip spans3.96 and3.98 add0.02/0.04 overall respectively (0.01/0.02 per side). All dimensions millimetres.

Head unchanged:10.22 diameter x2.43 thick. Stem6.35 from underside. Total8.78. Same12 tangent circular-arc hexalobular proportions, uniformly scaled only across the stem. Scaled T20-reference cosmetic plugs, not certified drivers. Matching STEP and STL for each size.

PRINT_ files are oriented head face on bed, stem up. Keep dried Creality CR-TPU black and printer settings consistent with the tested3.94 part. Try3.96 first, then3.98 if needed. Small increments can be comparable to print variation; compare actual fit. Aim for thumb-pressure seating rather than forcing. Prior available depth6.51–6.81 leaves0.16–0.46 nominal margin for6.35 stem.

Both models valid single solids;12 exact circular arcs with tangency checked; correct height and bed placement; STLs watertight, consistently wound and positive volume. Physical fit/retention of these new sizes remains UNTESTED.
