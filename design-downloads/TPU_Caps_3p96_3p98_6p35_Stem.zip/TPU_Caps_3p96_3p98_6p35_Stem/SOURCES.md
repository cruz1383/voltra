# Profile reference

The T20 recess reference dimensions (A=3.95 mm, B=2.85 mm, Re=0.307 mm) were read from the [bd_warehouse ISO10664 parameter table](https://github.com/gumyr/bd_warehouse/blob/main/src/bd_warehouse/data/iso10664def.csv). The repository's [hexalobular recess function](https://github.com/gumyr/bd_warehouse/blob/main/src/bd_warehouse/fastener.py) also documents its tangent circular-arc construction.

The new CadQuery script independently solves the circle-tangency equation and constructs six full convex arcs and six full concave arcs. Its uniform scaling to the user-selected plug spans produces a fit-trial profile, not a certified driver geometry. No manufacturer tolerance certificate or exact kit-cap CAD was available.
