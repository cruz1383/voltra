NEW V2 FIT TESTS ONLY

Print both STLs flat, at100percent scale, using your PETG profile. No supports needed.

OPTIONAL_Handle_End_R15:3mm-thick U around the exact new handle end. Test both Voltras. Confirm the R15 corners clear the metal handle without forcing the cover or sample. This is not a test of the full100mm case height.

OPTIONAL_Upright_Carabiner_Pair:two78 x11.5 x35mm-deep slots with5mm divider, on a3mm floor. Stand two carabiners on their narrow edge. About5mm should remain above the test piece for gripping. Check the widest gate/hinge area and easy removal. If you have only one spare, test it in each slot.

V2 changes BL and TR only. TL and BR and the V1 full-height joint tests remain geometrically unchanged. All physical new fits are untested until you try these samples.
