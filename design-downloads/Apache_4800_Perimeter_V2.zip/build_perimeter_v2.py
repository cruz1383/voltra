from pathlib import Path
import os,json,math
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl');os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import cadquery as c
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle
OUT=Path('/workspace/designs/output/Apache_4800_Perimeter_V2');OUT.mkdir(exist_ok=True)
L,W=452.025,320.2625 # 1mm each side from user-provided nominal case dimensions.
R=20.;H=3.;wall=8.;gap=.30
bodyL,bodyW=291.04,107.94
report={'stage':'Fit kit and preliminary layout only;not a full-height insert','case_nominal_reference_mm':[454.025,322.2625],'proposed_frame_footprint_mm':[L,W],'nominal_case_clearance_per_side_mm':1,'corner_radius_mm':R,'corner_radius_status':'Provisional generous corner cutback;test against actual case','case_gauge_height_mm':H,'body_dimensions_mm':[bodyL,bodyW,133.47],'overall_handle_length_mm_approx':329,'full_insert_height_intent_mm':100,'bottom':'Open pockets;original cushion retained','parts':{}}
def box(x,y,z,dx,dy,dz):return c.Solid.makeBox(dx,dy,dz,c.Vector(x,y,z))
def rounded(l,w,h,r):return c.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val()
def polygon(pts,h,z=0):return c.Workplane('XY').polyline(pts).close().extrude(h).val().translate((0,0,z))
def key(axis,cx,cy,h=H,clearance=0):
 pts=[(-1,-1.25),(1.3,-1.25),(4.3,-2.1),(4.3,2.1),(1.3,1.25),(-1,1.25)]
 if axis=='x':pts=[(cx+u,cy+v) for u,v in pts]
 else:pts=[(cx+v,cy+u) for u,v in pts]
 wp=c.Workplane('XY').polyline(pts).close()
 if clearance:wp=wp.offset2D(clearance)
 return wp.extrude(h).val()
def save(name,s):
 s=s.clean();assert s.isValid() and len(s.Solids())==1,(name,s.isValid(),len(s.Solids()))
 c.exporters.export(s,str(OUT/(name+'.step')))
 b=s.BoundingBox();q=s.translate((-b.xmin,-b.ymin,-b.zmin));bb=q.BoundingBox()
 assert bb.xlen<246 and bb.ylen<246,(name,bb.xlen,bb.ylen)
 assert q.exportStl(str(OUT/('PRINT_'+name+'.stl')),tolerance=.03,angularTolerance=.08,relative=False)
 report['parts'][name]={'valid_single_solid':True,'bed_footprint_mm':[bb.xlen,bb.ylen],'height_mm':bb.zlen,'volume_mm3':s.Volume(),'on_bed':True}
 return s
ring=rounded(L,W,H,R).cut(rounded(L-2*wall,W-2*wall,H,R-wall)).clean()
case={}
for name,sx,sy in [('BL',-1,-1),('BR',1,-1),('TL',-1,1),('TR',1,1)]:
 x=-L/2 if sx<0 else gap/2;y=-W/2 if sy<0 else gap/2
 case[name]=ring.intersect(box(x,y,0,L/2-gap/2,W/2-gap/2,H))
for cy,left,right in [(-W/2+wall/2,'BL','BR'),(W/2-wall/2,'TL','TR')]:
 case[left]=case[left].fuse(key('x',0,cy));case[right]=case[right].cut(key('x',0,cy,H+1,.20))
for cx,bottom,top in [(-L/2+wall/2,'BL','TL'),(L/2-wall/2,'BR','TR')]:
 case[bottom]=case[bottom].fuse(key('y',cx,0));case[top]=case[top].cut(key('y',cx,0,H+1,.20))
for name,s in case.items():case[name]=save('Case_Perimeter_'+name,s)
for i,a in enumerate(case):
 for b in list(case)[i+1:]:assert case[a].intersect(case[b]).Volume()<1e-6,(a,b)
c.exporters.export(c.Compound.makeCompound(list(case.values())),str(OUT/'Case_Perimeter_Assembly.step'))

report['stage']='Revised thin perimeter fit test only;not final insert'
report['corner_radius_status']='R20 chosen from user corner tests;complete perimeter fit untested'
report['geometry_checks']='Four valid single solids;zero assembled pairwise overlap;each part within printer bed'
(OUT/'CAD_validation.json').write_text(json.dumps(report,indent=2))
import shutil
shutil.copy(__file__,OUT/'build_perimeter_v2.py')
(OUT/'README.txt').write_text('APACHE 4800 PERIMETER TEST V2\n\nChanges: frame width 320.2625 mm, based on measured case width 12 11/16 inches (322.2625 mm), allowing 1 mm per side. Outer corner radius R20, selected from physical corner samples. Length unchanged at 452.025 mm and still subject to physical fit testing. Height 3 mm; wall 8 mm.\nPrint all four PRINT_Case_Perimeter STL files, each flat at 100% scale, one per plate. No supports needed. STEP files are included for reference; do not print the assembly STEP as one part. Use the same PETG settings as the previous test. Position clear of printer excluded areas.\nJoin the drop-in keys as in the previous frame. BL and BR form one long side; TL and TR form the opposite long side. Test on the retained bottom cushion. The assembled frame should lie flat without being forced or bowed. Small clearance from the walls is intentional. Check all four corners and both middle joints. Report if length is tight, if width is tight, or if a particular corner contacts the case. Also check near the intended 100 mm insert height if possible, since the case may taper.\nThis is a thin perimeter gauge, not the full-height insert. Device pocket width 108.22 mm remains the previously successful fit; no device bands are included here. Physical assembled fit untested.\n')
print(json.dumps(report['parts'],indent=2))
