V3.1 — BL / TR DOVETAIL EDGE-MARGIN CORRECTION

REPLACE ONLY Rigid/PRINT_BL.stl and Rigid/PRINT_TR.stl from the previous
FULL V3 captured-pad package. Do not print its older BL or TR files.
TL,BR and every TPU STL are byte-for-byte unchanged and may be reused.
This patch is for the FULL V3 captured-pad version, not earlier prototypes.

REASON
The60mm pads were widened at their prior centers. The rear dovetail track
width including clearance is64.30mm. At the outer track's32.5mm center,
the rear cut starts atX0.35 while the split plane isX0.15: only0.20mm
of material remained. The inner track had5.20mm. That unequal narrow
edge was a design oversight and was not established as strong by the
earlier watertight-mesh/assembly-clearance checks.

CORRECTION
Move the two near-seam tracks in each affected part farther into their
own half:10mm for the outer-wall track and5mm for the inner-wall track.
Both centers are now42.5mm from the center plane (mirrored for BL).
Both rear track-to-split-plane edge margins are now10.20mm.
The separate distances to nearby existing joint recesses are4.772mm
(outer track) and3.805mm (inner track). These are geometric clearances,
not physical strength ratings. No frame or pad scaling was used.

UNCHANGED
Case footprint, device openings, joints, accessory packing, pin channels,
valve relief, pad shape,1.5mm protrusion,3.65mm TPU thickness, tested
dovetail allowance and top/bottom capture remain. Only pad POSITIONS
within BL/TR change; the existing TPU pieces fit those relocated tracks.

VALIDATION
All18 source CAD solids valid; all18 source STLs passed mesh and46degree
geometric-overhang checks. Assembled seating, all10 top/bottom capture
checks, sampled rigid assembly motion, pin and valve clearances passed.
CAD probes verify the corrected edge margins in both BL and TR.
16 of18 source STLs are byte-identical to V3: only rigid BL and TR changed.
Printer-specific slicing, physical full-size fit and strength remain untested.

Print the two revised files at100% in their supplied orientation, using
the existing full-package material/assembly instructions. Both are rigid
material, not TPU. No extra tester or TPU reprint is required by this patch.
