ROGUE FLANGE — X1 CARBON / KEXCELLED CHERRY RED PLA
WALL CONSISTENCY TRIAL — PRINT SETTINGS ONLY

OPEN
Extract the ZIP. In Bambu Studio choose File > Open and open Rogue_Flange_Wall_Consistency_Trial.3mf AS A PROJECT, using its project settings. Do not import geometry only; that would discard the changes. Re-slice the plate before printing. Keep your existing PLA/PETG material mapping. This package contains a project, not printer-ready G-code.

PRESERVED
Both original placed model instances, the609334-triangle shared mesh, all exterior surfaces, both ROGUE logos, socket fit and internal geometry are byte-for-byte unchanged. All3D archive entries and object metadata were compared by hash against your uploaded project. No mesh was rebuilt, scaled, carved or compensated.
Your Kexcelled-calibrated filament flow values, temperatures,65C plate profile, nozzle/printer configuration, custom machine/toolchange code, layer height,4 walls,30% cubic infill, material assignments and PETG support-interface setup are retained. User confirmed the PolyLite-named custom profile was calibrated for this Kexcelled PLA, so its calibration was preserved.

FIVE SETTINGS CHANGED
Outer wall speed:200 ->100mm/s.
Outer wall acceleration:5000 ->2000mm/s2.
Wall order:inner/outer ->inner/outer/inner.
Smoothing wall speed alongZ:off ->on (Bambu's experimental smoothing option).
Don't slow down outer walls for cooling:on for the active red PLA profile only (filament3). Other filament cooling flags are unchanged.
The existing0.16 process and0.20 first layer remain as uploaded. Overhang detail slowdown remains enabled.

WHY THIS TRIAL
The uploaded smooth mesh has no modeled outward ridge at the lettering height. The original toolpaths command up to200mm/s on the outer wall, with some short lettering-related detail paths as slow as10mm/s; plain walls return to200mm/s. This is evidence of a speed/flow transition, not proof of the physical cause. The trial limits the high-speed wall to100, lowers acceleration, smooths speed changes with height and prints a supporting inner wall before the visible wall, with remaining inner walls afterward. This targets pressure and wall-consistency effects while retaining the same geometry and calibrated flow.
Thermal effects from internal solid layers/infill can also produce circumferential bands. A photo alone does not distinguish them conclusively. Do not treat this trial as a physically proven fix.

VALIDATION
Both source and trial were sliced in official Bambu Studio02.08.02.61, matching the uploaded project. Both final runs returned0 / Success., with200 layers,2 objects and1218668 total triangles. Both slices report identical object geometry bounds and no plate warnings. Modified settings and retained calibration/material parameters were checked in resolved slicer settings. CLI initialization warned about absent *_full preset snapshots and color metadata; it used the embedded project settings, which were explicitly verified.
Estimated plate time increased from approximately3h08m to3h19m (about11 minutes) for the same two models. Estimates depend on actual machine behavior.
Wall_Speed_Comparison.png shows commanded external-wall speeds from generated toolpaths, not measured printer speed. Internal analysis G-code is not included or sent to the printer.

PHYSICAL TEST
The outcome still needs a print trial. For a like-for-like comparison, keep material, calibration, plate, chamber conditions and material mapping consistent with the previous print; use Normal speed mode. The supplied plate retains both objects. You may print one first to save filament, but changing object count changes layer cooling/timing and weakens a strict comparison.
If the ridge persists, measure its height from the base and send a side photo of the completed print. That lets us compare the band to the internal step near8mm and lettering region approximately6.36–14.64mm, then investigate thermal/infill effects without changing the exterior or logos. Do not sand or modify the geometry to mask the cause before evaluating the test.

Printed bulge reduction, finish, dimensional fit and load capacity remain physically untested.
