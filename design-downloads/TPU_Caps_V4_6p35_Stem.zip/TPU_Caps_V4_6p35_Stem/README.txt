VOLTRA TPU CAPS V4 — SLIGHT LENGTH INCREASE, TIGHTER WIDTH TRIALS
Current version; supersedes the V3 long-stem trials.

DIMENSIONS, MM
Head unchanged:10.22 diameter x2.43 thick.
Stem:6.35 from head underside, only0.05 longer than the original6.30.
Total CAD height:8.78.

TWO VARIANTS
3p89:3.89 opposing tips, a0.05 total /0.025 per-side increase over the tested V2 3.84.
3p94:3.94 opposing tips, a0.10 total /0.050 per-side increase over tested V2 3.84.
Both have the same6.35 stem and8.78 overall height. Start with3p89, then3p94 if still loose. These are fit trials, not measured retention guarantees. Each STEP/STL file name includes tip span, stem length and total height.

FEEDBACK AND INTENT
User found V2 3.84 slightly looser than kit original and measured approximately8.74 overall on the previous print (CAD8.73). User now attributes fit primarily to insufficient tightness and requests only0.05 additional stem length. V4 therefore focuses on increased radial interference while keeping length near the original, not the previously considered10.00 overall length.

PROFILE
The same12 tangent circular arcs from V2/V3 are preserved, uniformly scaled only across the stem. Six convex lobes and six concave valleys, based on scaled T20-recess reference proportions. This is a cosmetic TPU plug fit trial, not a certified driver geometry or exact kit-cap reproduction. Head geometry unchanged. SeeSOURCES.md.

PRINT AND FIT
PRINT_ STLs have the circular head face on the bed and stem up. No supports expected. Use the same calibrated Creality CR-TPU black material/profile and compensation as your successful V2 lobe-definition test to keep the width comparison meaningful. Dry filament according to its instructions. Unknown Shore hardness, printer error and screw dimensions affect retention.
The0.05 CAD length change is smaller than common layer heights. Slicer rounding may give the same final layer count as the prior cap. Check final height in Preview; do not interpret an unchanged printed height as a failed CAD edit. Width fit is the primary objective.
Earlier available depth6.51–6.81 leaves0.16–0.46 nominal margin for the6.35 stem, assuming the head underside seats at the measured cover surface. Check full seating and distinguish comfortable stem-side retention from bottom contact. Retention target remains thumb pressure.

VALIDATION
Each part is a valid single CAD solid. Exact12-arc section, tangency and sampled tip/valley extrema checked. Head and stem lengths retained as above. Both meshes pass watertight edge, consistent winding, positive volume, on-bedZ0 and8.78 height checks. STEP/STL, source and reports included.
V4 printing, press-fit retention and full seating remain physically UNTESTED.
