APACHE 4800 / VOLTRA TPU CONCEPT — STOPPER FINGER RELIEFS REMOVED

CHANGE
Both stopper cradles now have continuous closed rounded ends, with no
finger-relief scallop. The rigid inserts and their TPU side/floor liners
are revised together. Original 0.30 mm rigid section seams are retained.

DIMENSIONS
Main stopper opening remains 62.97 x 43.27 mm; it has NOT been shortened.
The former finger notch extended 8 mm beyond the nominal rounded end,
making the old complete cutout 70.97 mm long. Removing only that notch
returns the complete cutout to 62.97 mm. The user's 61.08 mm measured
overall stopper length therefore has 1.89 mm total nominal length
clearance. This is an envelope allowance, not a verified close-fitting
trace of the stopper's stem and body. Physical steadiness still needs
checking with the real part. The loop provides the retrieval grip.

UNCHANGED
All Voltra pads (including 60 mm side pads), both charger liners and mats,
the bare metal-carabiner slots, main envelope, pockets elsewhere and the
previous air-valve relief remain. Original bottom foam is still retained.

REVIEW FILES
STEP assembly and three PNG renders of actual CAD, plus source and
revision_validation.json. Orange is TPU; gray is rigid. All four rigid
sections and all fourteen TPU components are valid single CAD solids.

This is still the TPU design CONCEPT, not a printable release. Final pad
retention, first-contact clearance (TPU proud of hard walls), tolerances,
remaining wall strength and physical cushioning/packing checks are pending.
No printable STLs or drop-protection rating are supplied.
The accessory floor mats still raise their floors 2 mm and cover the
charger logos. The larger modeled cable stack has 1.14 mm spare height.
