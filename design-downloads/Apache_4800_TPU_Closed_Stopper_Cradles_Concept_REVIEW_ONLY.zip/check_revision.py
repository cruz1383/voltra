from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-tpu-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent
old=np.load(ROOT.parent/'tpu-concept-wide/review/cad_triangles.npz')
new=np.load(ROOT/'review/cad_triangles.npz')
unchanged=[]
for name in old.files:
    if name.startswith('TPU') and 'stopper' not in name:
        assert np.array_equal(old[name],new[name]),name
        unchanged.append(name)
checks={}
for row in ['Upper','Lower']:
    name='TPU__'+row+'_stopper_TPU_cup'
    previous=cq.Shape.importBrep(str(ROOT.parent/'tpu-concept-wide/review'/f'{row}_stopper_TPU_cup.brep'))
    current=cq.Shape.importBrep(str(ROOT/'review'/f'{row}_stopper_TPU_cup.brep'))
    before=previous.BoundingBox().xlen;after=current.BoundingBox().xlen
    assert abs(before-73.97)<1e-5 and abs(after-65.97)<1e-5
    shape=cq.Shape.importBrep(str(ROOT/'review'/f'{row}_stopper_TPU_cup.brep'))
    assert shape.isValid() and len(shape.Solids())==1
    checks[row]={'original_cutout_including_finger_notch_length_mm':70.97,
        'new_cutout_length_mm':62.97,'new_cutout_width_mm':43.27,
        'measured_stopper_length_mm':61.08,'total_nominal_length_clearance_mm':1.89,
        'TPU_outer_length_before_mm':float(before),'TPU_outer_length_after_mm':float(after),
        'valid_single_solid':True}
report={'unchanged_TPU_components_exact_tessellation_match':unchanged,
 'revised_stopper_liners':checks,
 'stage':'CAD concept only; physical fit not tested'}
(ROOT/'review/revision_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
