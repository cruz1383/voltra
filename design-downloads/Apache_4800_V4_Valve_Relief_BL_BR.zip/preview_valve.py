"""Orthographic depth-buffer render of the revised CAD; no generated imagery."""
from pathlib import Path
import os
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-cad-cache')
import cadquery as cq
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from matplotlib.font_manager import findfont
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'revised'
WALL=-160.13125
colors={'BL':(.28,.53,.63),'BR':(.61,.72,.76)}
triangles=[]
base=[]
for name,col in colors.items():
    p=cq.importers.importStep(str(OUT/f'Insert_{name}_Valve_Relief.step')).val()
    # Actual CAD section around the joint; artificial crop faces expose depth.
    crop=cq.Solid.makeBox(44,22,72,cq.Vector(-22,WALL-.1,0))
    p=p.intersect(crop)
    verts,faces=p.tessellate(.015,.05)
    a=np.array([v.toTuple() for v in verts])[np.array(faces)]
    triangles.append(a)
    base.extend([col]*len(a))
a=np.concatenate(triangles)
base=np.array(base)
norm=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0])
norm/=np.maximum(np.linalg.norm(norm,axis=1),1e-12)[:,None]
light=np.array([-.4,-1,.8]);light/=np.linalg.norm(light)
shade=.40+.60*np.maximum(norm@light,0)
rgb=np.clip(base*shade[:,None]*255,0,255).astype(np.uint8)

def render(view,width=1100,height=1100):
    view=np.array(view,dtype=float);view/=np.linalg.norm(view)
    right=np.cross([0,0,1],view);right/=np.linalg.norm(right)
    up=np.cross(view,right)
    proj=np.stack([a@right,a@up,a@view],axis=-1)
    lo=proj[:,:,:2].reshape(-1,2).min(axis=0)
    hi=proj[:,:,:2].reshape(-1,2).max(axis=0)
    scale=min((width-100)/(hi[0]-lo[0]),(height-100)/(hi[1]-lo[1]))
    proj[:,:,0]=(proj[:,:,0]-(lo[0]+hi[0])/2)*scale+width/2
    proj[:,:,1]=height/2-(proj[:,:,1]-(lo[1]+hi[1])/2)*scale
    canvas=np.full((height,width,3),248,np.uint8)
    zb=np.full((height,width),-np.inf)
    for i,t in enumerate(proj):
        if norm[i]@view<=0:continue
        x0=max(0,int(np.floor(t[:,0].min())));x1=min(width-1,int(np.ceil(t[:,0].max())))
        y0=max(0,int(np.floor(t[:,1].min())));y1=min(height-1,int(np.ceil(t[:,1].max())))
        if x1<x0 or y1<y0:continue
        xs=np.arange(x0,x1+1)[None,:]+.5;ys=np.arange(y0,y1+1)[:,None]+.5
        denom=(t[1,1]-t[2,1])*(t[0,0]-t[2,0])+(t[2,0]-t[1,0])*(t[0,1]-t[2,1])
        if abs(denom)<1e-12:continue
        w0=((t[1,1]-t[2,1])*(xs-t[2,0])+(t[2,0]-t[1,0])*(ys-t[2,1]))/denom
        w1=((t[2,1]-t[0,1])*(xs-t[2,0])+(t[0,0]-t[2,0])*(ys-t[2,1]))/denom
        w2=1-w0-w1
        depth=w0*t[0,2]+w1*t[1,2]+w2*t[2,2]
        local=zb[y0:y1+1,x0:x1+1]
        mask=(w0>=-1e-7)&(w1>=-1e-7)&(w2>=-1e-7)&(depth>local)
        local[mask]=depth[mask]
        canvas[y0:y1+1,x0:x1+1][mask]=rgb[i]
    return Image.fromarray(canvas)

im=Image.new('RGB',(2200,1390),'#f8f8f8')
im.paste(render([.4,-1,.35]),(0,170))
im.paste(render([.4,-1,-.8]),(1100,170))
d=ImageDraw.Draw(im)
font=lambda size:ImageFont.truetype(findfont('DejaVu Sans'),size)
def text(s,x,y,size=30):d.text((x,y),s,font=font(size),fill='#203d48',anchor='mt')
text('V4 valve relief — actual revised CAD',1100,30,44)
text('Local cutaway at outside BL / BR center joint | Blue: BL | Gray: BR',1100,95,29)
text('Outside wall view',550,155,32)
text('View from underneath',1650,155,32)
text('7.08 mm wide × 6.09 mm deep | Rounded roof: 55.30 mm above underside',1100,1270,30)
text('Insert top flush with case rim | Valve center: 51.76 mm above underside',1100,1318,29)
text('Cutaway crop faces expose existing dovetail behind relief. Physical fit untested.',1100,1360,26)
im.save(OUT/'Valve_Relief_CAD_Preview.png')
print('Rendered revised STEP geometry')
