APACHE 4800 V4 — BL/BR AIR-VALVE RELIEF

Only the two bottom sections are revised. Keep the original V4 TL and TR.
Use the supplied PRINT_*.stl files for printing. STEP files retain original
assembly coordinates. Print STLs have the same bottom-down orientation and
local bed placement convention as V4. Print at 100%; do not scale globally.

DATUM AND LOCATION
User confirms insert top is flush with case rim. Insert height is 100 mm.
Valve is placed at x=0 on outside wall of the BL/BR center joint, following
the task handoff. Its measured diameter is 6.08 mm and inward projection
6.59 mm. Top edge 45.20 below rim gives center 48.24 below rim, or Z51.76
above insert underside. The valve bottom is at Z48.72.

RELIEF
Shared underside-open slot, 7.08 mm total width, 6.09 mm inward depth from
the insert's outside face, with an R3.54 semicircular roof at Z55.30.
Slot is centered on the existing seam. The seam remains 0.30 mm.
This provides 0.50 mm radial clearance and 0.50 mm tip clearance using V4's
nominal 1.00 mm case-wall-to-insert gap. That gap is a design nominal, not
a new measurement; tip clearance depends on actual installed wall spacing.
The relief opens continuously to the underside so it can slide down over
the installed valve. Inspect the small arched roof in slicer preview.

PRESERVATION AND VALIDATION
Direct subtraction from original V4 STEP solids, with no global rebuild.
Zero measured geometry difference outside the localized relief envelope.
Confirmed-fit perimeter elsewhere, pockets, floors, logos, top sections,
and all dovetail profiles are retained. The recess stops 1.34125 mm before
the nearest extent of the outside dovetail socket. This is geometric
separation; printed strength of the remaining local material is untested.

Both revised parts are valid single CAD solids; both STL meshes have
watertight edges, consistent winding, positive volume, and Z0-100 bounds.
Both fit a 256 mm bed with 5 mm brim allowance. Sampled valve insertion
positions and BL/BR sliding assembly show no interference. See
validation.json for exact results. Physical valve fit remains untested.

Valve_Relief_CAD_Preview.png is rendered from the revised STEP geometry.
It is a localized cutaway; flat crop faces expose the joint and are not
additional model changes. Blue is BL and gray is BR.

REPRODUCTION
Use Python 3.12 with CadQuery 2.6.1, NumPy, Matplotlib and Pillow.
Extract the original Apache_4800_Full_Insert_V4.zip into source-v4/ beside
revise_valve.py and preview_valve.py, then run:
  python revise_valve.py --rim-offset 0 --wall-gap 1
  python preview_valve.py
Scripts are included for traceability. No printer G-code is supplied.
