"""Cut an underside-open valve relief directly from the original V4 STEP solids.

Requires the measured downward offset from case rim to installed insert top.
Run only after confirming valve is centered on the outside BL/BR wall.
"""
from pathlib import Path
import argparse, json, os, struct
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/voltra-cad-cache')
import cadquery as cq
import numpy as np
from collections import Counter

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--rim-offset', type=float, required=True,
                    help='Case rim to installed insert top, mm downward positive')
parser.add_argument('--wall-gap', type=float, default=1.0,
                    help='Installed case wall to insert outside face, mm')
args = parser.parse_args()
root = Path(__file__).resolve().parent
out = root / 'revised'
out.mkdir(exist_ok=True)
H, wall = 100., -160.13125
radius, projection = 6.08 / 2, 6.59
clearance = .5
roof_radius = radius + clearance
center_z = H + args.rim_offset - 48.24
depth = projection - args.wall_gap + clearance
assert args.wall_gap >= 0 and depth > 0
assert 0 < center_z and center_z + roof_radius < H
assert depth < 7.43125, 'Relief would reach the existing dovetail socket'

def box(x,y,z,l,w,h):
    return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))

# Rectangular path to underside, capped with a semicircular roof. A full
# cylinder plus the rectangle is identical and robust to boolean operations.
cutter = box(-roof_radius, wall-1, -1, 2*roof_radius, depth+1, center_z+1)
cutter = cutter.fuse(cq.Solid.makeCylinder(
    roof_radius, depth+1, cq.Vector(0,wall-1,center_z), cq.Vector(0,1,0))).clean()

report = {'rim_to_insert_top_mm': args.rim_offset,
          'nominal_wall_gap_mm': args.wall_gap,
          'valve_diameter_mm': 6.08, 'valve_projection_mm': projection,
          'valve_top_below_rim_mm': 45.20,
          'valve_center_above_insert_bottom_mm': center_z,
          'recess_roof_above_insert_bottom_mm': center_z+roof_radius,
          'recess_width_mm': 2*roof_radius, 'recess_depth_mm': depth,
          'radial_and_tip_clearance_mm': clearance,
          'recess_to_dovetail_socket_min_y_separation_mm': 7.43125-depth,
          'physical_fit': 'UNTESTED', 'parts': {}}
parts, originals = {}, {}
for name in ['BL','BR']:
    original = cq.importers.importStep(str(root/'source-v4'/f'Insert_{name}.step')).val()
    revised = original.cut(cutter).clean()
    assert revised.isValid() and len(revised.Solids()) == 1
    removed = original.Volume()-revised.Volume()
    assert removed > 0
    # The construction only subtracts this localized cutter. Check an expanded
    # neighborhood's complement to independently verify retained geometry.
    allowed = box(-roof_radius-.01,wall-1.01,-1.01,
                  2*roof_radius+.02,depth+1.02,center_z+roof_radius+1.02)
    before = original.cut(allowed)
    after = revised.cut(allowed)
    delta = before.cut(after).Volume() + after.cut(before).Volume()
    assert delta < 1e-5
    cq.exporters.export(revised,str(out/f'Insert_{name}_Valve_Relief.step'))
    b = revised.BoundingBox()
    print_shape = revised.translate((-b.xmin,-b.ymin,-b.zmin))
    stl = out/f'PRINT_Insert_{name}_Valve_Relief.stl'
    assert print_shape.exportStl(str(stl),tolerance=.025,angularTolerance=.07,relative=False)
    data = stl.read_bytes()
    n = struct.unpack_from('<I',data,80)[0]
    assert len(data) == 84+50*n and n>0
    dtype=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')])
    a=np.frombuffer(data,dtype=dtype,offset=84,count=n)['points'].astype(float)
    assert np.isfinite(a).all()
    ids, edges, winding = {}, Counter(), Counter()
    for tri in a:
        vi=[ids.setdefault(tuple(np.round(v,5)),len(ids)) for v in tri]
        assert len(set(vi))==3
        for u,v in zip(vi,vi[1:]+vi[:1]):
            edge=tuple(sorted((u,v)))
            edges[edge]+=1
            winding[edge]+=1 if u<v else -1
    assert all(v==2 for v in edges.values())
    assert all(v==0 for v in winding.values())
    vol=np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6
    assert vol>0 and abs(a[:,:,2].min())<1e-5 and abs(a[:,:,2].max()-H)<1e-5
    assert b.xlen+10<=256 and b.ylen+10<=256
    parts[name], originals[name] = revised, original
    report['parts'][name] = {'valid_single_solid':True,'removed_mm3':removed,
        'difference_outside_relief_mm3':delta,'triangles':n,
        'watertight':True,'consistent_winding':True,'positive_volume_mm3':vol,
        'on_bed':True,'fits_with_5mm_brim':True}
    print(name,'exported and mesh checked',flush=True)

# The cylindrical valve and the full downward installation sweep must clear
# both revised parts. Model the external valve from the actual case wall.
for dz in [0,1,5,10,20,40,60,80,100]:
    valve = cq.Solid.makeCylinder(radius,projection,
        cq.Vector(0,wall-args.wall_gap,center_z-dz),cq.Vector(0,1,0))
    for name,p in parts.items():
        assert p.intersect(valve).Volume()<1e-5,(name,dz,'valve collision')
report['sampled_valve_installation_offsets_mm']=[0,1,5,10,20,40,60,80,100]
report['no_valve_collision_at_samples']=True
assert parts['BL'].intersect(parts['BR']).Volume()<1e-5
for dz in [0,1,5,12,20,40,60,66,71,77,90,100.2]:
    assert parts['BR'].translate((0,0,dz)).intersect(parts['BL']).Volume()<1e-5
report['sampled_BL_BR_sliding_joint_clear']=True
(out/'validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
