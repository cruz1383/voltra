RACK JIG V2.2 — STRAIGHT CHEEKS, 75.80 INSIDE SPAN
Millimetres. Physical fit untested. Supersedes V2 and V2.1 halves.

USER-REQUESTED CHANGE
Straight inside cheek walls:75.80 apart over the entire15 depth. No lip, hook or inward step. Outer cheek width remains88.08; each cheek wall6.14 thick, height48.
Upright measured75.58: nominal0.22 total clearance /0.11 each side. This is intentionally a tighter trial. Actual print shrinkage, dimensional error or rack coating can consume that clearance. Trial fit by hand; do not force it onto the rack. Do not assume the printed span equals CAD.
The rack's measured rounded-corner reach8.85 means a15-deep straight cheek has nominal6.15 depth overlap with the flat side, compared with5 for the previous distal pads. Near the front, the rack's corners recede from the walls. Removing the lip cannot make the rounded corner flat; the whole15 depth will not bear on flat steel. Clearance also means both walls do not necessarily bear simultaneously when centered. The long straight walls provide the available flat-side alignment surfaces.

OTHER DIMENSIONS RETAINED
Main plate:88.08 wide,82 high,8 thick, plus bottom tongue.
Existing-hole boss16.75 diameter x2.50 projection; existing rack hole16.86.
Target center49.53 above old hole, centered across upright. Cutter opening16.175 for15.875 nominal annular cutter.
Magnet pockets20.40 diameter x4.45 depth; magnets20.01x3.04 and pads20.03xapproximately1.29 measured with liners. Verify actual liner-free stack and compression; magnets must not protrude and rock the jig. Adhesive thickness may need adjustment.
Seam pegs4.40 diameter x4 engagement, sockets4.64 x4.30.
Tongue thickness4, recessed2 from both plate faces. Bottom clip has0.20 nominal face clearances and approximately0.24..0.30 total transverse clearance; close sliding fit, not guaranteed preload. Retention untested. V2.2 clip geometry is unchanged from V2.1; a matching file is included. Replace older V2 clip if still using it.

STEEL CONTACT AND PRINTING
Rack front faceZ=0; plateZ0..8. Boss and cheeks extend behind this plane into existing hole and outside rack sides, respectively. TongueZ2..6, clipZ0.2..7.8, so neither projects into steel or beyond outward plate face.
PRINT_ files: broad outward face of each half directly on bed, boss/cheeks point upward. Approximately3508.54mm2 broad-face bed contact per half. Recessed bottom tongue starts2 above bed: ADD LOCAL SUPPORT UNDER TONGUE. Inspect/support seam pegs if needed. Clip printed on upper edge; inspect channel bridging and support if required.0.16–0.20 layers,4walls,25–35% infill are starting trial settings, not tested printer settings. Preview first layer before printing.

STATIONARY REMOVAL
Pull clip down until free (25 travel sampled). Pull joined halves forward at least15.5 to clear cheeks and boss, then separate sideways to disengage pegs and clear stationary cutter.50 sideways travel per half sampled. Actual drill housing, flutes, pilot, shoulders, magnetic base dimensions and available travel are not supplied. Check the real removal path with cutter stationary.
REMOVE ENTIRE JIG BEFORE CUTTER ROTATION. Alignment only, not a cutting bearing or drill restraint. Magnetic base contacts steel directly.

VALIDATION
All3 parts valid single solids, no mutual assembled penetration. No modeled upright penetration with75.58-wide rack and16.86 existing hole. Sampled forward/sideways removal clears ideal15.875 cylindrical cutter and steel; downward clip removal clears halves. Broad plate contact and maxZ8 checked. STL checks: watertight edges, consistent winding, positive volume, Z0 bed placement. Inside span independently checked through cheek depth.
All physical fits, clip/magnet retention and printing remain UNTESTED.
