from pathlib import Path
import cadquery as c
import json, shutil
O=Path('/workspace/designs/output/Apache_4800_Corner_Tests')
O.mkdir(exist_ok=True)
report={}
parts=[]
for i,r in enumerate([15,20,25,30,35,40,45]):
 outer=c.Workplane('XY').box(150,150,3,centered=(False,False,False)).edges('|Z').fillet(r).val()
 inner=c.Workplane('XY').box(134,134,4,centered=(False,False,False)).edges('|Z').fillet(r-8).val().translate((8,8,-.5))
 corner=outer.cut(inner).intersect(c.Solid.makeBox(70,70,3)).clean()
 label=c.Workplane('XY').text('R'+str(r),5,.6,combine=False).val().translate((52,4,2.5))
 corner=corner.cut(label).clean()
 assert corner.isValid() and len(corner.Solids())==1
 corner.exportStl(str(O/f'PRINT_Corner_R{r}.stl'),tolerance=.01,angularTolerance=.05,relative=False)
 c.exporters.export(corner,str(O/f'Corner_R{r}.step'))
 report[f'R{r}']={'valid_single_solid':True,'size_mm':[70,70,3],'radius_mm':r}
 parts.append(corner.translate(((i%3)*78,(i//3)*78,0)))
plate=c.Compound.makeCompound(parts)
plate.exportStl(str(O/'PRINT_All_7_Corners.stl'),tolerance=.01,angularTolerance=.05,relative=False)
(O/'CAD_validation.json').write_text(json.dumps(report,indent=2))
(O/'README.txt').write_text('APACHE 4800 CORNER FIT SAMPLES\n\nSeven separate 70 x 70 x 3 mm samples: R15, R20, R25, R30, R35, R40 and R45. Radius labels are recessed into the top. R40 repeats the original curve for comparison. These are trial circular curves, not measured case radii.\n\nPrint either individual STLs or PRINT_All_7_Corners.stl (all seven arranged 226 x 226 mm). Do not print both sets. Flat unmarked face on bed; no supports. PETG, same settings as the frame. With a 5 mm brim, combined footprint is 236 x 236 mm; check placement against printer excluded areas in Bambu Studio.\n\nRemove the old frame. Test one sample at a time, flat on the retained bottom cushion. Position the two OUTSIDE straight edges about 1 mm from the corresponding case walls. Compare the outside curved edge with the wall. Do not force or bend the sample. Try all case corners and report which radius follows the wall best and whether either straight arm interferes. Also check at the intended top height if possible; the case may taper. A molded irregular contour may not match any exact circular radius.\n\nCorrected case width: 12 11/16 inches = 322.2625 mm. Next frame width with 1 mm clearance each side: 320.2625 mm. Frame length remains provisional 452.025 mm. This package contains corner tests only, not a revised full frame or final insert. Physical fit untested.\n')
shutil.copy(__file__,O/'build_corner_tests.py')
print(report)
