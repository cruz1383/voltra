APACHE 4800 CORNER FIT SAMPLES

Seven separate 70 x 70 x 3 mm samples: R15, R20, R25, R30, R35, R40 and R45. Radius labels are recessed into the top. R40 repeats the original curve for comparison. These are trial circular curves, not measured case radii.

Print either individual STLs or PRINT_All_7_Corners.stl (all seven arranged 226 x 226 mm). Do not print both sets. Flat unmarked face on bed; no supports. PETG, same settings as the frame. With a 5 mm brim, combined footprint is 236 x 236 mm; check placement against printer excluded areas in Bambu Studio.

Remove the old frame. Test one sample at a time, flat on the retained bottom cushion. Position the two OUTSIDE straight edges about 1 mm from the corresponding case walls. Compare the outside curved edge with the wall. Do not force or bend the sample. Try all case corners and report which radius follows the wall best and whether either straight arm interferes. Also check at the intended top height if possible; the case may taper. A molded irregular contour may not match any exact circular radius.

Corrected case width: 12 11/16 inches = 322.2625 mm. Next frame width with 1 mm clearance each side: 320.2625 mm. Frame length remains provisional 452.025 mm. This package contains corner tests only, not a revised full frame or final insert. Physical fit untested.
