from pathlib import Path
import os,json,ast
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-edge-cache')
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'tpu-full-v3';OUT=ROOT/'review'
points=[(-30,0),(30,0),(30,1.15),(32,3.65),(-32,3.65),(-30,1.15)]
t=cq.Workplane('XY').polyline(points).close().offset2D(.15).extrude(1).val()
b=Bnd_Box();BRepBndLib.AddOptimal_s(t.wrapped,b,False,False)
half=b.Get()[3];assert abs(half-32.15)<1e-6
s=(ROOT.parent/'valve-clearance/source-v4/build_full_insert_v4.py').read_text()
tree=ast.parse(s);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['key_wire','female_key']]
ns={'cq':cq,'H':100};exec(compile(ast.Module(body=nodes,type_ignores=[]),'original_joint_geometry','exec'),ns)
clearances={}
for name,sgn in [('TR',1),('BL',-1)]:
    p=cq.Shape.importBrep(str(OUT/f'rigid_{name}.brep'))
    for x in [.16,5,10.30,10.34]:
        assert p.isInside(cq.Vector(sgn*x,sgn*138.76,50),1e-6),(name,x)
    assert not p.isInside(cq.Vector(sgn*10.36,sgn*138.76,50),1e-6),name
    clearances[name]={'old_outer_track_edge_margin_mm':.2,'old_inner_track_edge_margin_mm':5.2,
        'new_both_track_edge_margins_mm':10.2,'seam_half_gap_mm':.15,
        'shift_away_from_center_seam_mm':{'outer':10,'inner':5}}
joints={}
for label,py,d,jy in [('outer',135.11,1,147.5),('inner',26.89,-1,16)]:
    seat=cq.Workplane('XY').polyline(points).close().offset2D(.15).extrude(80).val().translate((0,0,10))
    if d<0:seat=seat.mirror('XZ')
    seat=seat.translate((42.5,py,0))
    dist=seat.distance(ns['female_key']('x',0,jy));assert dist>3.8
    joints[label]={'track_to_adjacent_original_joint_cavity_mm':dist}
unchanged=[]
for path in sorted((ROOT/'stl_full').glob('*.stl')):
    same=path.read_bytes()==(OLD/'stl_full'/path.name).read_bytes()
    should_change=path.name in ['PRINT_Rigid_BL.stl','PRINT_Rigid_TR.stl']
    assert same != should_change,path.name
    if same:unchanged.append(path.name)
assert len(unchanged)==16
report={'edge_margins':clearances,'joint_web_clearance':joints,
 'unchanged_source_STLs_byte_identical':unchanged,
 'changed_source_STLs':['PRINT_Rigid_BL.stl','PRINT_Rigid_TR.stl'],
 'note':'Edge margins are to the center split plane; adjacent-joint clearances are separate. This is geometric validation, not a physical strength rating.'}
(OUT/'edge_margin_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
