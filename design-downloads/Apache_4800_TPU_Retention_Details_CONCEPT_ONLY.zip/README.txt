TPU RETENTION — CAD DETAIL CONCEPTS, NOT PRINT-READY

These are separate real CAD samples illustrating the proposed mechanism.
They are NOT integrated into the full Apache 4800 insert. Existing complete
insert downloads are preserved and are not superseded by these coupons.
Orange = TPU. Gray = rigid supporting structure.

VOLTRA PAD
A dovetail-shaped pad slides down from the open top into matching rails.
The wider rear edges prevent pulling the pad straight away from the wall.
A bottom stop establishes seating height. A flexible side cantilever snaps
below a rigid receiving ledge, preventing the pad from following the Voltra
up during removal. Squeeze the side tab inward to clear the ledge and lift
the pad out. The mechanism is separate from the Voltra shim-pin channels.
Current nominal track offset is 0.2 mm. That is a trial CAD allowance,
not a verified printed fit. The side latch adds space beside the pad that
must be checked against the full insert's walls, joints and channel sites.

ACCESSORY LINER
Shown as an actual-size reference charger liner. A top locating lip sits
in a recessed shelf with its top at Z100, flush with the rigid support.
Two wall snap tongues catch below receiving shoulders. Flex the liner
wall inward to disengage before lifting. No adhesive is intended. The
same retention principle would be adapted to the stopper liners; an
individual stopper-liner retention design is not yet included.

VALIDATION AND LIMITS
Four CAD components are valid single solids. The nominal seated positions
have no rigid/TPU volume overlap. A 1 mm upward displacement intersects
the retaining shoulders, demonstrating the modeled lock. CAD does not
simulate TPU deformation: insertion force, allowable strain, fatigue,
release access with loaded equipment and printer tolerances are untested.
The flared lead surfaces require TPU flex during insertion and release.
Test an actual coupon before integrating the mechanism and exporting
print-ready insert parts. No printable STL or load/drop rating is supplied.

FILES
Voltra_TPU_Retention_CAD.png: exploded pad, side latch close-up, rail section.
Accessory_TPU_Retention_CAD.png: assembled half-cutaway and lifted liner.
TPU_Retention_Details_CONCEPT_ONLY.step: colored four-component assembly.
validation.json and generation/render Python source for traceability.
Views are rendered from CAD tessellations, not generated product imagery.
Python dependencies: CadQuery 2.6.1, NumPy, Pillow, Matplotlib.
