"""Real CAD detail concepts; not a printable retention release."""
from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-retention-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,z,h):return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,0,z))
def prism_xz(points,y,depth):
    verts=[cq.Vector(x,y,z) for x,z in points]
    wire=cq.Wire.makePolygon(verts+[verts[0]])
    return cq.Solid.extrudeLinear(wire,[],cq.Vector(0,depth,0))
def save_arrays(name,shapes):
    arrays={}
    for key,p in shapes.items():
        v,f=p.tessellate(.025,.09)
        arrays[key]=np.array([x.toTuple() for x in v])[np.array(f)]
    np.savez_compressed(OUT/(name+'.npz'),**arrays)

# 60 x 90 mm pad. Wider rear edge is trapped by two matching side rails.
profile=cq.Workplane('XY').polyline([(-29,0),(29,0),(30,2.5),(-30,2.5)]).close()
pad=profile.extrude(90).val().translate((0,0,5))
for x in [-24,-16,-8,0,8,16,24]:
    pad=pad.cut(box(x-2,1.2,10,4,1.3,70))
# Side latch is a cantilever with a bottom attachment and lateral flex gap.
root=box(29,0,80,6,2.5,2)
arm=box(33,0,81.5,2,2.5,12.5)
hook=prism_xz([(35,88),(37,92),(37,94),(35,94)],0,2.5)
pad=pad.fuse(root,arm,hook)
track=(cq.Workplane('XY').polyline([(-29,0),(29,0),(30,2.5),(-30,2.5)]).close()
       .offset2D(.2).extrude(96).val().translate((0,0,5)))
rail=box(-40,0,0,80,8,100).cut(track)
# Receiver cavity leaves a roof above the snap shoulder at Z94.
rail=rail.cut(box(28.8,-.1,79.8,8.7,3,14.5))
assert rail.isValid() and len(rail.Solids())==1
assert pad.isValid() and len(pad.Solids())==1
assert rail.intersect(pad).Volume()<1e-5
# Dovetail remains sliding along Z until the snap reaches its receiving pocket.
for z in [0,.1]:assert rail.intersect(pad.translate((0,0,z))).Volume()<1e-5
assert rail.intersect(pad.translate((0,0,1))).Volume()>0 # lock catches upward motion

# Actual-size charger liner reference, with flush top locating flange.
inner=rr(87,65,4,32,70)
cup=rr(90,68,5.5,30,70).cut(inner)
lip=rr(92,70,6.5,99,1).cut(rr(87,65,4,98.9,1.2))
cup=cup.fuse(lip)
for side in [1,-1]:
    # Side-wall slits isolate the flexing snap tongue, without cutting floor.
    for y in [-3.8,3.2]:
        cup=cup.cut(box(43.4 if side>0 else -45.2,y,86,1.8,.6,12))
    bump=prism_xz([(45,91),(46,94),(46,96),(45,96)],-3,6)
    if side<0:bump=bump.mirror('YZ')
    cup=cup.fuse(bump)
support=rr(102,80,9,25,75).cut(rr(90.4,68.4,5.7,30,71))
support=support.cut(rr(92.4,70.4,6.7,98.8,2))
for side in [1,-1]:
    support=support.cut(box(45.1 if side>0 else -46.4,-4,90,1.3,8,6.3))
assert cup.isValid() and len(cup.Solids())==1
assert support.isValid() and len(support.Solids())==1
assert cup.intersect(support).Volume()<1e-5
assert cup.translate((0,0,1)).intersect(support).Volume()>0

assembly=cq.Assembly(name='TPU_RETENTION_DETAIL_CONCEPT')
assembly.add(rail,name='Device_pad_rail',color=cq.Color(.56,.63,.67))
assembly.add(pad,name='Device_pad_with_side_snap',color=cq.Color(1,.52,.12))
assembly.add(support.translate((150,0,0)),name='Charger_support_coupon',color=cq.Color(.56,.63,.67))
assembly.add(cup.translate((150,0,0)),name='Charger_liner_with_lip_and_snaps',color=cq.Color(1,.52,.12))
assembly.save(str(OUT/'TPU_Retention_Details_CONCEPT_ONLY.step'))
save_arrays('pad_assembled',{'rigid':rail,'TPU':pad})
save_arrays('pad_exploded',{'rigid':rail,'TPU':pad.translate((0,0,110))})
# Crop the top section to expose the side snap and bottom cut faces. The
# removed left region is only a display cutaway, not a production alteration.
clip=box(25,-10,75,17,20,25)
save_arrays('pad_latch_closeup',{'rigid':rail.intersect(clip),'TPU':pad.intersect(clip)})
# Horizontal cross section makes both dovetail lips visible.
slice=box(-42,-1,44,84,11,7)
save_arrays('pad_rail_cross_section',{'rigid':rail.intersect(slice),'TPU':pad.intersect(slice)})
# Half of the cup/support remains: open cut plane at Y0 reveals lip, floor
# and wall while preserving the far-side attachment geometry.
half=box(-60,0,20,120,45,85)
save_arrays('liner_cutaway',{'rigid':support.intersect(half),'TPU':cup.intersect(half)})
save_arrays('liner_exploded',{'rigid':support.intersect(half),'TPU':cup.translate((0,0,85))})
(OUT/'validation.json').write_text(json.dumps({
 'stage':'Separate CAD retention detail coupons, not integrated into full insert',
 'four_components_valid_single_solids':True,'assembled_rigid_TPU_overlap_mm3':0,
 'nominal_pad_track_side_clearance_mm':.2,
 'pad_bottom_stop_z_mm':5,'pad_snap_shoulder_z_mm':94,'receiver_roof_z_mm':94.3,
 'pad_1mm_lift_catches_snap':True,'liner_1mm_lift_catches_snaps':True,
 'liner_locating_lip_top_flush_z_mm':100,
 'pending':['TPU strain and insertion force','Snap ramp assembly simulation with deformation',
 'Release access with equipment installed','Print tolerances and coupon fit',
 'Integration and wall/joint checks in complete insert'],
 'note':'Rigid interference on lifting demonstrates retaining shoulders only; TPU deformation and fatigue not simulated.'},indent=2))
print('Saved valid retention detail CAD and render geometry',flush=True)
