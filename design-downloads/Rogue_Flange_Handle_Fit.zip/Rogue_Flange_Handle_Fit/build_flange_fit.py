from pathlib import Path
import cadquery as c,json,math
O=Path('/workspace/designs/output/Rogue_Flange_Handle_Fit');O.mkdir(exist_ok=True)
P=Path(__file__).resolve().parent/'Source_Original.step'
if not P.exists():P=Path('/workspace/designs/flange_original/45mm_Flange_ROGUE_Dual.step')
s=c.importers.importStep(str(P)).val()
assert s.isValid() and len(s.Solids())==1
report={}
# Fill only existing socket region, then machine a straight 3mm socket at the original floor.
# All changes confined to the top socket; outside shape, dual logos and lower bores preserved.
zone=c.Solid.makeCylinder(24.10,3.02,c.Vector(0,0,28.99))
for d in [45.14,45.64,46.10]:
 tag=f'{d:.2f}'.replace('.','p');name='Rogue_Flange_Socket_'+tag
 fill=c.Solid.makeCylinder(24.05,3,c.Vector(0,0,29))
 bore=c.Solid.makeCylinder(d/2,3.2,c.Vector(0,0,29))
 # 0.25x45 degree lead-in, straight fitting wall ends at31.75.
 mouth=c.Solid.makeCone(d/2,d/2+.25,.25,c.Vector(0,0,31.75))
 q=s.fuse(fill).cut(bore.fuse(mouth)).clean()
 assert q.isValid() and len(q.Solids())==1
 added=q.cut(s);removed=s.cut(q)
 assert added.cut(zone).Volume()<1e-5 and removed.cut(zone).Volume()<1e-5
 bb=q.BoundingBox();print('Analytic bounds',d,bb.zmin,bb.zmax,flush=True)
 vertices_z=[v.Center().z for v in q.Vertices()];assert abs(min(vertices_z))<1e-5 and abs(max(vertices_z)-32)<1e-5
 # Bounds may be conservatively expanded by existing face triangulations; actual vertex extrema and exported mesh checked separately.
 # Nominal cylinder representing user handle must reach socket floor without interference.
 handle=c.Solid.makeCylinder(44.74/2,30,c.Vector(0,0,29))
 assert q.intersect(handle).Volume()<1e-6
 # Quantify actual analytic cylindrical fitting face and axial extent.
 faces=[]
 for f in q.Faces():
  if f.geomType()=='CYLINDER' and abs(f._geomAdaptor().Cylinder().Radius()-d/2)<1e-6:
   b=f.BoundingBox();faces.append([b.zmin,b.zmax])
 assert any(abs(a-29)<1e-5 and abs(b-31.75)<1e-5 for a,b in faces),(d,faces)
 c.exporters.export(q,str(O/(name+'.step')))
 c.exporters.export(q,str(O/('PRINT_'+name+'.stl')),tolerance=.025,angularTolerance=.08)
 ring=c.Solid.makeCylinder(27,3).cut(c.Solid.makeCylinder(d/2,3.1)).cut(c.Solid.makeCone(d/2,d/2+.25,.25,c.Vector(0,0,2.75)))
 assert ring.isValid() and len(ring.Solids())==1
 c.exporters.export(ring,str(O/('PRINT_Fit_Ring_'+tag+'.stl')),tolerance=.025,angularTolerance=.08)
 report[str(d)]={'valid_single_solid':True,'socket_diameter_mm':d,'handle_diameter_mm':44.74,'nominal_diametral_clearance_mm':round(d-44.74,2),'socket_floor_z_mm':29,'socket_depth_mm':3,'straight_wall_depth_mm':2.75,'entrance_chamfer_mm':.25,'handle_to_floor_no_interference':True,'change_outside_socket_volume_mm3':0,'cylinder_face_z_intervals':faces,'added_volume_mm3':added.Volume(),'removed_volume_mm3':removed.Volume(),'physical_fit':'UNTESTED'}
 (O/'CAD_validation.json').write_text(json.dumps(report,indent=2))
 print(name,'valid; handle-to-floor clearance and confined modification checks passed',flush=True)
(O/'CAD_validation.json').write_text(json.dumps(report,indent=2))
