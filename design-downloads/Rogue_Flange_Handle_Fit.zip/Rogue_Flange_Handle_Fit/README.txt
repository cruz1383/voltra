ROGUE FLANGE — REVISED HANDLE SOCKET FIT TRIALS
Units millimetres. Based directly on supplied45mm_Flange_ROGUE_Dual.step. Handle measured44.74. Printed original socket measured47.04.

Original STEP:48.00 cylindrical socket mouth,3.00 overall depth(Z29..32), with a large1.75 internal floor fillet. Fillet reduces opening toward the floor to44.50. Because diameter changes with caliper contact depth, the difference between CAD48.00 and physical47.04 is not proven to be a uniform printer error. Do not blindly scale the entire part or assume a0.96 correction.

REVISED SOCKET
Socket floor remainsZ29, topZ32. Straight cylindrical fitting wall for2.75 depth, then0.25 x45-degree entrance chamfer. No large floor fillet; nominal44.74 cylindrical handle clears to original socket floor. Mouth at the very top is0.50 larger in diameter than the straight fitting wall. Measure the fitting wall below the chamfer, not the extreme top edge.

THREE ALTERNATIVE FULL FLANGES — PRINT ONLY ONE AFTER RING TRIAL
Socket45.14: primary close slip-fit trial,0.40 nominal total clearance /0.20 radial around44.74 handle.
Socket45.64: looser alternative,0.90 nominal total clearance.
Socket46.10: print-undersize allowance alternative,1.36 nominal total clearance. IF the original48.00-to47.04 difference repeated uniformly, this would print approximately45.14. That compensation is hypothetical, not established, because the original socket had a large fillet.
Filename number is straight fitting diameter, not extreme chamfer mouth or measured printed diameter.

FIT RINGS
Three short54OD x3 thick rings reproduce each socket's fitting diameter, straight depth and entrance chamfer. Print them flat in the same material/profile and XY compensation as the flange. The chamfer is on the top. Try the handle gently and select the smallest diameter that slips on to full depth without force or obvious rocking. Rings are quick fit screens; they do not reproduce the full flange's thermal history or the handle-end floor/fastener seating, so final flange fit is still untested.
Keep ring file names/positions identifiable on the print plate. No embossed size marks were added to the rings. Print one at a time if necessary to avoid confusing sizes.

PRINT
PRINT_ flange STLs preserve source orientation with flat base atZ0 and socket upward. No global scaling. Use calibrated first layer/XY dimensions and your established material profile. Supports, if needed, should not obstruct the fitting wall; inspect slicer for the existing lower internal bores. Print ring trials before another full flange.

PRESERVED
Outer envelope72 diameter x32 high, both opposite ROGUE engravings, lower stepped center bores and floor/fastener seating belowZ29. Changes confined to the original top socket region (insideR24.10,Z28.99..32.01). Only handle socket rebuilt; no recreation of lettering or general shape from a photograph. Original uploaded lettering is preserved as supplied.

VALIDATION
Each full flange: valid single CAD solid; ideal44.74 handle reaches socket floor with zero intersection; expected cylindrical fitting diameter/height verified; added/removed material confined to socket region. STEP and STL provided. Ring and flange STLs checked separately for watertightness, winding, positive volume and bed placement. Physical fit, retention and intended load use are UNTESTED. This geometry adjustment does not establish load capacity.
