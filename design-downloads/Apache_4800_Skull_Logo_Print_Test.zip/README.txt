SKULL FITNESS LOGO PRINT TEST

One flat64 x65 x2mm sample plate. Print STL at100percent scale, flat bottom down, with your intended PETG/nozzle/layer settings. The53.93 x55mm source-traced artwork is recessed0.6mm, exactly matching the two charger-pocket logos. No supports or extra filament color are needed.

Use the sample to assess fine skull/barbell/text detail before the large prints. Some very thin strokes and gaps can soften or disappear with a0.4mm nozzle. Source outlines have been preserved rather than replaced with a font. At0.20mm layers, the recess is3 nominal layers deep. Physical engraving quality has not yet been tested.
