APACHE 4800 / TWO VOLTRAS — FULL INSERT V3

V3 adds subtle R2 (2 mm) curves to the two SCREEN-END corners of each
Voltra opening, opposite the handle. The R15 handle-end curves and four
upright carabiner slots retain their user-confirmed fit dimensions.

This version also completes the agreed hardware-free joint revision:
four enlarged outer sliding joints plus four new middle joints, across
both directions of the center split. No screws, dowels or heat-set inserts.

ALL FOUR V3 SECTIONS MUST BE USED TOGETHER. V2 sections do not have matching
joint profiles or locations. Earlier claims that TL/BR could be reused
applied to the V1-to-V2 revision only, not to V3.

FILES TO PRINT

PRINT_Insert_BL.stl, PRINT_Insert_BR.stl, PRINT_Insert_TL.stl,
PRINT_Insert_TR.stl: one main section per plate, 100% scale, flat unmarked
bottom on the bed and recessed section label facing up. The files are
already placed in that print orientation. STEP files and Assembly.step
are included for inspection; do not print the assembly as a single piece.

NEW FIT TESTS — PRINT THESE BEFORE LARGE SECTIONS

OPTIONAL_Screen_End_R2.stl is a 3 mm thick U around the exact new screen-end
opening, with a 6 mm rim. Check it against both protected units at the end
opposite the metal handle. The corners should sit around the covers without
forcing. At the nominal measured width and length, the R2 shape clears the
full rectangular cover envelope; real print fit remains untested.

OPTIONAL_Joint_Test_Male.stl and OPTIONAL_Joint_Test_Female.stl are the
new enlarged 100 mm tall test tracks with broad feet. Print both using
the intended PETG settings, with a brim. Slide the female track down over
the male pads until their feet reach the same flat surface. It should move
by hand without tools, spreading or cracking. If it binds, report the fit;
do not globally scale the main insert. Earlier smaller V1/V2 joint tests
do not establish the fit of this new profile.

OPTIONAL_Handle_End_R15.stl and OPTIONAL_Upright_Carabiner_Pair.stl retain
the previously successful handle and carabiner test geometry. They are
included for reference; there is no need to repeat those successful tests.

PRINT SETTINGS

PETG, 0.4 mm nozzle, 0.20 mm layers, 4 wall loops, 12% gyroid infill,
6 top and 5 bottom layers are a starting point. Use temperatures, cooling
and flow settings suited to your PETG. Inspect the slice before printing.

Use sparse infill, NOT 100% infill. CAD contains filled volumes under
accessory floors; slicer infill supports them and reduces material use.
Review Bambu Studio's time and filament estimates before starting.

The model is designed for bottom-down printing without supports. The upper
male pads have a gradual lead-in ramp; accessory floors are supported by
infill beneath them. Check those ramps and pocket floors in slice preview.
An approximately 5 mm brim can help adhesion. Main parts fit within the
256 x 256 mm bed by dimensions, including that brim; position them clear
of excluded/calibration areas in Bambu Studio.

ASSEMBLY

In the supplied orientation, red Voltra is above green:

    TL | TR
    -------
    BL | BR

Remove BOTH upper pick-and-pluck layers. Retain the solid bottom foam
cushion and lid foam. Start with BL, lower BR onto its tracks, then TL,
then TR last onto the matching tracks in both directions. The extra center
connections use the same vertical assembly motion as the outside joints.
Clean stray strings from mating surfaces without changing their dimensions.
Do not force the parts or glue anything during initial fit checking.

Both devices rest directly on the original cushion through open-bottom
pockets. Accessory pockets have raised floors. Confirm that all four
sections sit flat and that the case closes gently with everything loaded.

DIMENSIONS (mm)

Outer footprint 452.025 x 320.2625, R20; height 100. Seam gaps 0.30.
Voltra openings 333 x 108.22; body-end corners R2, handle-end corners R15.
The measured covered body is 291.04 x 107.72. Nominal width clearance is
0.25 per side; nominal overall length including handle is approximately329.
Outer-side finger scallops provide grip access. R2 changes the corner
profile only; the overall opening length and width remain as tested.

Eight sliding dovetail joints: 6 mm neck,10 mm head,7 mm reach, with1 mm
curved root transitions. Socket offset remains0.20 mm. Lower pads Z0–20,
upper lead-in ramp Z66–77, upper pads Z77–100, sockets open through the
height. Outer joints move into thicker material; middle joints are centered
at (0,+/-16) and (+/-16,0). The larger dimensions provide more bearing area;
print strength and fit have not been physically tested.

Shim-pin relief remains5.2 wide x2 deep, full height,100.79 from the handle
end of each protective COVER BODY, with matching channels on both long
walls to allow either installed pin orientation.

Four upright carabiner openings78 x11.5, R2 corners, depth35, floor Z65.
Each pair has a5 mm divider. The measured75.78 x39.81 x8.91 carabiners stand
on their8.91 mm edge, leaving about4.81 mm above the insert for gripping.
The user reports these holder tests fit perfectly. Full loaded-case lid
clearance still needs checking.

Stopper cradle envelopes62.97 x43.27, depth45, floors Z55. Conservative
clearance shapes, not exact traces of the molded stoppers. Check cable/loop
orientation without forcing a cable bend.

Charger compartments87 x65 x70 deep, R4, floors Z30. Identical charger bodies
59.96 x60.12 x28.86; overall with pins75.91. Chargers stay flat, cables above.
Measured cable bundle85.47 x40.92 x11.15 fits the CAD envelope. A bulkier
85.5 x57 x35 bundle also fits above the charger, with3 mm packing allowance
and3.14 mm top clearance. Flexible cables can be rearranged within that space.

Two curved resting grooves6 wide x6 deep in the upper surface connect the
device openings to the stopper cradles. These remain provisional because
actual cable diameter and minimum bend radius were not measured. Do not
pull the cables into a groove under tension; check the route physically.

CHECKS AND PHYSICAL FIT STATUS

See CAD_validation.json and mesh_validation.json for completed checks:
single valid solid per part, dimensions including tabs/brim, no assembled
overlap, sampled vertical assembly motion, measured cover clearance,
hardware envelopes and closed consistently oriented STL meshes.

Physical fits confirmed by the user: thin case perimeter V2 at cushion
level,108.22 mm device opening, R15 handle corners and upright carabiners.
Physical fits not yet confirmed: R2 screen corners, enlarged joints,
100 mm case taper, accessory packing and full loaded-case lid clearance.
The handle's U-shaped CAD envelope is an approximation; the prior physical
R15 test supplies the relevant handle-fit evidence.

Full-size STL/STEP files, assembly previews, fit tests and source scripts
are included. No printer G-code or changed filament profile is supplied.
