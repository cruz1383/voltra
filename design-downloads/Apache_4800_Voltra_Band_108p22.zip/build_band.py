from pathlib import Path
import os,json,math
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl');os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import cadquery as c
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle
OUT=Path('/workspace/designs/output/Apache_4800_Voltra_Band_108p22');OUT.mkdir(exist_ok=True)
L,W=452.025,325.025 # 1mm each side from user-provided nominal case dimensions.
R=40.;H=3.;wall=8.;gap=.30
bodyL,bodyW=291.04,107.72
report={'stage':'Fit kit and preliminary layout only;not a full-height insert','case_nominal_reference_mm':[454.025,327.025],'proposed_frame_footprint_mm':[L,W],'nominal_case_clearance_per_side_mm':1,'corner_radius_mm':R,'corner_radius_status':'Provisional generous corner cutback;test against actual case','case_gauge_height_mm':H,'body_dimensions_mm':[bodyL,bodyW,133.47],'overall_handle_length_mm_approx':329,'full_insert_height_intent_mm':100,'bottom':'Open pockets;original cushion retained','parts':{}}
def box(x,y,z,dx,dy,dz):return c.Solid.makeBox(dx,dy,dz,c.Vector(x,y,z))
def rounded(l,w,h,r):return c.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val()
def polygon(pts,h,z=0):return c.Workplane('XY').polyline(pts).close().extrude(h).val().translate((0,0,z))
def key(axis,cx,cy,h=H,clearance=0):
 pts=[(-1,-1.25),(1.3,-1.25),(4.3,-2.1),(4.3,2.1),(1.3,1.25),(-1,1.25)]
 if axis=='x':pts=[(cx+u,cy+v) for u,v in pts]
 else:pts=[(cx+v,cy+u) for u,v in pts]
 wp=c.Workplane('XY').polyline(pts).close()
 if clearance:wp=wp.offset2D(clearance)
 return wp.extrude(h).val()
def save(name,s):
 s=s.clean();assert s.isValid() and len(s.Solids())==1,(name,s.isValid(),len(s.Solids()))
 c.exporters.export(s,str(OUT/(name+'.step')))
 b=s.BoundingBox();q=s.translate((-b.xmin,-b.ymin,-b.zmin));bb=q.BoundingBox()
 assert bb.xlen<246 and bb.ylen<246,(name,bb.xlen,bb.ylen)
 assert q.exportStl(str(OUT/('PRINT_'+name+'.stl')),tolerance=.03,angularTolerance=.08,relative=False)
 report['parts'][name]={'valid_single_solid':True,'bed_footprint_mm':[bb.xlen,bb.ylen],'height_mm':bb.zlen,'volume_mm3':s.Volume(),'on_bed':True}
 return s
clear=2.;innerL=329+2*clear;innerW=108.22;bandwall=6.;bandH=6.
outer=rounded(innerL+2*bandwall,innerW+2*bandwall,bandH,6.5)
inner=rounded(innerL,innerW,bandH,.5)
band=outer.cut(inner).clean();bl=band.intersect(box(-200,-100,0,200-gap/2,200,bandH));br=band.intersect(box(gap/2,-100,0,200-gap/2,200,bandH))
for yy in [-innerW/2-bandwall/2,innerW/2+bandwall/2]:
 bl=bl.fuse(key('x',0,yy,bandH));br=br.cut(key('x',0,yy,bandH+1,.20))
bl=save('Device_Envelope_Band_Left',bl);br=save('Device_Envelope_Band_Right',br)
assert bl.intersect(br).Volume()<1e-6
# Verify an ideal measured rectangular body fits band, even with mildly rounded cavity corners.
envelope=box(-329/2,-bodyW/2,0,329,bodyW,bandH)
assert bl.intersect(envelope).Volume()<1e-6 and br.intersect(envelope).Volume()<1e-6
report['whole_device_band_opening_mm']=[innerL,innerW];report['device_band_clearance_per_side_mm']=.25;report['measured_covered_device_width_mm']=107.72
report['connection']='Prismatic drop-in puzzle keys;0.20 offset sockets;0.30 seams. Fit gauges only;not final insert retention joints.'
report['geometry_checks']='Both halves valid single solids;no overlap;ideal rectangular device envelope clears;footprints below246mm.'
(OUT/'CAD_validation.json').write_text(json.dumps(report,indent=2))

import shutil
shutil.copy(__file__,OUT/'build_band.py')
(OUT/'README.txt').write_text('REVISED VOLTRA WIDTH FIT BAND\n\nPrint both PRINT_Device_Envelope_Band halves, flat on the bed, then join the drop-in keys. No supports.\nOpening: 333.00 x 108.22 mm. Width based on measured covered Voltra 107.72 mm plus 0.25 mm per side. Length unchanged from prior test. Height 6 mm; wall 6 mm. Keep at 100% scale.\nTest with the protective cover installed. Physical fit untested. The previous print measured about 0.42 mm narrower than the nominal CAD opening, so this tighter trial could bind; do not force it. Report actual printed opening and fit. No global scaling or assumed printer compensation applied.\nThese two halves are a device fit gauge, not the revised case perimeter or final insert. Print separately from the corner samples if plate space is insufficient.\n')
