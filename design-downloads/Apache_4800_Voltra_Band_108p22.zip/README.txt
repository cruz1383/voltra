REVISED VOLTRA WIDTH FIT BAND

Print both PRINT_Device_Envelope_Band halves, flat on the bed, then join the drop-in keys. No supports.
Opening: 333.00 x 108.22 mm. Width based on measured covered Voltra 107.72 mm plus 0.25 mm per side. Length unchanged from prior test. Height 6 mm; wall 6 mm. Keep at 100% scale.
Test with the protective cover installed. Physical fit untested. The previous print measured about 0.42 mm narrower than the nominal CAD opening, so this tighter trial could bind; do not force it. Report actual printed opening and fit. No global scaling or assumed printer compensation applied.
These two halves are a device fit gauge, not the revised case perimeter or final insert. Print separately from the corner samples if plate space is insufficient.
