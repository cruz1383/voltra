ROGUE FLANGE — SINGLE-MODEL PACKAGE

Print PRINT_Fit_Ring_45p14.stl first to check the44.74mm handle against the45.14mm nominal socket diameter (0.40mm nominal diametral clearance). Physical fit remains untested.

Selected full model:PRINT_SMOOTH_Rogue_Flange_Socket_45p14.stl. Flat base down, socket up. Matching STEP included.

Exterior shape, dimensions and both original ROGUE engravings preserved. Handle socket revised to45.14 straight fitting diameter,3mm total depth with0.25 entrance chamfer. The fitting wall is2.75 deep. Large original internal floor fillet removed; changes confined to socket. Fine mesh exported from same revised CAD with absolute0.005mm deflection and0.02rad angular setting.

X1 Carbon, standard0.4 nozzle, Kexcelled Cherry Red PLA:Generic PLA profile with temperature within spool range;0.16 High Quality;Normal speed mode. Run filament flow dynamics/flow rate calibration. Aligned seams localize seam marks. Ventilate chamber if warm during PLA printing. Do not globally scale to adjust socket fit.

Valid single-solid source; STL watertight, consistently wound, positive volume,baseZ0 and height32 checked. Improved mesh smoothness, actual printing, fit and load capacity remain physically untested.
