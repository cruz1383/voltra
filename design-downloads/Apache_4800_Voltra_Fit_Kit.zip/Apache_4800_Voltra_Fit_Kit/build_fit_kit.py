from pathlib import Path
import os,json,math
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl');os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import cadquery as c
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle
OUT=Path('/workspace/designs/output/Apache_4800_Voltra_Fit_Kit');OUT.mkdir(exist_ok=True)
L,W=452.025,325.025 # 1mm each side from user-provided nominal case dimensions.
R=40.;H=3.;wall=8.;gap=.30
bodyL,bodyW=291.04,107.94
report={'stage':'Fit kit and preliminary layout only;not a full-height insert','case_nominal_reference_mm':[454.025,327.025],'proposed_frame_footprint_mm':[L,W],'nominal_case_clearance_per_side_mm':1,'corner_radius_mm':R,'corner_radius_status':'Provisional generous corner cutback;test against actual case','case_gauge_height_mm':H,'body_dimensions_mm':[bodyL,bodyW,133.47],'overall_handle_length_mm_approx':329,'full_insert_height_intent_mm':100,'bottom':'Open pockets;original cushion retained','parts':{}}
def box(x,y,z,dx,dy,dz):return c.Solid.makeBox(dx,dy,dz,c.Vector(x,y,z))
def rounded(l,w,h,r):return c.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val()
def polygon(pts,h,z=0):return c.Workplane('XY').polyline(pts).close().extrude(h).val().translate((0,0,z))
def key(axis,cx,cy,h=H,clearance=0):
 pts=[(-1,-1.25),(1.3,-1.25),(4.3,-2.1),(4.3,2.1),(1.3,1.25),(-1,1.25)]
 if axis=='x':pts=[(cx+u,cy+v) for u,v in pts]
 else:pts=[(cx+v,cy+u) for u,v in pts]
 wp=c.Workplane('XY').polyline(pts).close()
 if clearance:wp=wp.offset2D(clearance)
 return wp.extrude(h).val()
def save(name,s):
 s=s.clean();assert s.isValid() and len(s.Solids())==1,(name,s.isValid(),len(s.Solids()))
 c.exporters.export(s,str(OUT/(name+'.step')))
 b=s.BoundingBox();q=s.translate((-b.xmin,-b.ymin,-b.zmin));bb=q.BoundingBox()
 assert bb.xlen<246 and bb.ylen<246,(name,bb.xlen,bb.ylen)
 assert q.exportStl(str(OUT/('PRINT_'+name+'.stl')),tolerance=.03,angularTolerance=.08,relative=False)
 report['parts'][name]={'valid_single_solid':True,'bed_footprint_mm':[bb.xlen,bb.ylen],'height_mm':bb.zlen,'volume_mm3':s.Volume(),'on_bed':True}
 return s
ring=rounded(L,W,H,R).cut(rounded(L-2*wall,W-2*wall,H,R-wall)).clean()
case={}
for name,sx,sy in [('BL',-1,-1),('BR',1,-1),('TL',-1,1),('TR',1,1)]:
 x=-L/2 if sx<0 else gap/2;y=-W/2 if sy<0 else gap/2
 case[name]=ring.intersect(box(x,y,0,L/2-gap/2,W/2-gap/2,H))
for cy,left,right in [(-W/2+wall/2,'BL','BR'),(W/2-wall/2,'TL','TR')]:
 case[left]=case[left].fuse(key('x',0,cy));case[right]=case[right].cut(key('x',0,cy,H+1,.20))
for cx,bottom,top in [(-L/2+wall/2,'BL','TL'),(L/2-wall/2,'BR','TR')]:
 case[bottom]=case[bottom].fuse(key('y',cx,0));case[top]=case[top].cut(key('y',cx,0,H+1,.20))
for name,s in case.items():case[name]=save('Case_Perimeter_'+name,s)
for i,a in enumerate(case):
 for b in list(case)[i+1:]:assert case[a].intersect(case[b]).Volume()<1e-6,(a,b)
c.exporters.export(c.Compound.makeCompound(list(case.values())),str(OUT/'Case_Perimeter_Assembly.step'))
# Six-mm-high band screens complete329mm device envelope,including handle;no end wall across handle.
clear=2.;innerL=329+2*clear;innerW=bodyW+2*clear;bandwall=6.;bandH=6.
outer=rounded(innerL+2*bandwall,innerW+2*bandwall,bandH,9)
inner=rounded(innerL,innerW,bandH,3)
band=outer.cut(inner).clean();bl=band.intersect(box(-200,-100,0,200-gap/2,200,bandH));br=band.intersect(box(gap/2,-100,0,200-gap/2,200,bandH))
for yy in [-innerW/2-bandwall/2,innerW/2+bandwall/2]:
 bl=bl.fuse(key('x',0,yy,bandH));br=br.cut(key('x',0,yy,bandH+1,.20))
bl=save('Device_Envelope_Band_Left',bl);br=save('Device_Envelope_Band_Right',br)
assert bl.intersect(br).Volume()<1e-6
# Verify an ideal measured rectangular body fits band, even with mildly rounded cavity corners.
envelope=box(-329/2,-bodyW/2,0,329,bodyW,bandH)
assert bl.intersect(envelope).Volume()<1e-6 and br.intersect(envelope).Volume()<1e-6
report['whole_device_band_opening_mm']=[innerL,innerW];report['device_band_clearance_per_side_mm']=clear
report['connection']='Prismatic drop-in puzzle keys;0.20 offset sockets;0.30 seams. Fit gauges only;not final insert retention joints.'
report['geometry_checks']='All6 parts single valid solids;no pairwise case or band overlaps;ideal complete device envelope clears band;all individual footprints below246mm.'
(OUT/'CAD_validation.json').write_text(json.dumps(report,indent=2))
# Preliminary layout proof (equipment and handle rectangles are measured/approximate envelopes).
fig,ax=plt.subplots(figsize=(12,9))
outerpatch=FancyBboxPatch((-L/2,-W/2),L,W,boxstyle=f'round,pad=0,rounding_size={R}',facecolor='#e4e9ed',edgecolor='#303b43',linewidth=2);ax.add_patch(outerpatch)
ax.plot([0,0],[-W/2,W/2],ls='--',color='#77828b',lw=1);ax.plot([-L/2,L/2],[0,0],ls='--',color='#77828b',lw=1)
for label,x,y in [('TL',-160,147),('TR',160,147),('BL',-160,-147),('BR',160,-147)]:ax.text(x,y,label,ha='center',fontsize=11,fontweight='bold')
for xc,yc,sign,col in [(-L/2+24,80,1,'#c35d58'),(L/2-24,-80,-1,'#7e9168')]:
 if sign==1:
  xmin=xc;xmax=xc+bodyL;hx=xmax;overallmin=xmin;overallmax=xmin+329
 else:
  xmax=xc;xmin=xmax-bodyL;hx=xmin-38;overallmin=xmax-329;overallmax=xmax
 ax.add_patch(FancyBboxPatch((overallmin-2,yc-bodyW/2-2),333,bodyW+4,boxstyle='round,pad=0,rounding_size=4',facecolor='white',edgecolor='#667078',lw=1.2))
 ax.add_patch(FancyBboxPatch((xmin,yc-bodyW/2),bodyL,bodyW,boxstyle='round,pad=0,rounding_size=4',facecolor=col,edgecolor='black',lw=1))
 ax.add_patch(Rectangle((hx,yc-bodyW/2+8),38,bodyW-16,fill=False,edgecolor='#777',linestyle='--',linewidth=2))
 ax.text((xmin+xmax)/2,yc,'Covered body\n291.04 × 107.94 mm\n≈329 mm overall with handle',ha='center',va='center',fontsize=11,color='white')
 ax.text(hx+19,yc,'Handle\nenvelope',ha='center',va='center',fontsize=8,color='#555')
for x,y in [(142,33),(-207,-128)]:
 ax.add_patch(Rectangle((x,y),65,95,facecolor='#bccbd3',edgecolor='#6a7d88',linestyle=':'));ax.text(x+32.5,y+47.5,'Accessory\nspace\n(provisional)',ha='center',va='center',fontsize=9)
ax.text(0,8,'Central divider / finger-access area',ha='center',fontsize=11)
ax.annotate('',xy=(-L/2,-W/2-17),xytext=(L/2,-W/2-17),arrowprops={'arrowstyle':'<->'});ax.text(0,-W/2-32,f'{L:.1f} mm proposed outside footprint',ha='center',fontsize=11)
ax.annotate('',xy=(L/2+16,-W/2),xytext=(L/2+16,W/2),arrowprops={'arrowstyle':'<->'});ax.text(L/2+28,0,f'{W:.1f} mm',rotation=90,ha='center',va='center',fontsize=11)
ax.set_aspect('equal');ax.set_xlim(-L/2-20,L/2+50);ax.set_ylim(-W/2-45,W/2+25);ax.axis('off');fig.suptitle('Apache 4800 / two Voltras — preliminary PETG insert layout',fontsize=16)
ax.set_title('100 mm high sections • open-bottom pockets • existing foam cushion retained\nNominal case footprint and generous corner cutbacks require fit testing',fontsize=10,pad=12)
fig.tight_layout(rect=[0,0,1,.94]);fig.savefig(OUT/'Preliminary_Layout.png',dpi=160)
print(json.dumps(report,indent=2),flush=True)
