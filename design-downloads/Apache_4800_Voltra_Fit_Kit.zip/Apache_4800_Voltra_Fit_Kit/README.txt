APACHE 4800 / TWO VOLTRAS — PETG FIT KIT, STAGE1
These are thin fit gauges and a preliminary layout, not the final100mm-high insert.

CONFIRMED INPUTS
Nominal case footprint from supplied screenshot fractions:454.025 x327.025.
Two upper foam layers measured99.72;use100 nominal replacement height.
Original solid bottom foam cushion and lid padding retained.
Covered body291.04 long x107.94 wide x133.47 overall height,as user labeled.
Complete length including metal handle approximately329 (tape measurement,not caliper precision).
Underside photos show circular rear attachment,rail recess and vent grille. Proposed final device pockets stay OPEN AT THE BOTTOM:devices continue to rest on original foam;no PETG floor or hard bearing against those features. Final seating/lid clearance still require physical checking.

PRINT FIRST — CASE GAUGE
Print four PRINT_Case_Perimeter_ files:TL,TR,BL,BR. Each3mm high,flat on bed. Fit_Kit_Assembly_Guide.png shows orientation. Hinges are at the top of the guide, latches at bottom. Leave parts in their supplied STL orientation; no supports needed.
Assemble the puzzle tabs by dropping them into the matching sockets vertically,not forcing them horizontally. There is0.20 socket offset and0.30 nominal seam gap. Small pieces of tape underneath can hold this lightweight gauge at the illustrated positions. These temporary joints test fit only;they are not the final frame's retention system.
Assembled outside footprint452.025 x325.025:nominal1mm per-side clearance from supplied case dimensions. Corner radius40 is a provisional generous corner cutback,not a measured match to the molded case.
Remove the two upper foam layers,keep the bottom cushion,and check the assembled gauge where the insert base will sit. It should lie flat without bowing or being wedged against corners.
Then check near the intended insert top100 above that cushion. Replacing the old two foam layers temporarily provides a convenient support height for this second check. This reveals case taper;published dimensions do not establish the bottom profile.
Report whether the gauge sits flat at both heights,and which sides/corners bind or have excessive gaps. A photo of the gauge in the case is more useful than repeating the previous tape measurements. Do not change global slicer scale to hide a local fit problem.

PRINT SECOND — DEVICE GAUGE
Print PRINT_Device_Envelope_Band_Left andRight. Each6mm high. Assemble around one covered Voltra INCLUDING its handle. The opening is333 x111.94:approximately329 x107.94 complete envelope plus2mm each side. The longer opening avoids placing a closed end wall across the handle.
Check the cover's widest areas and both ends. The gap is intentional space for future soft lining/pads,not a bare-plastic interference fit. Check that the handle and circular rear attachment clear;band is open through the center. Separate the gauge to reposition it rather than dragging it over controls or cables.
Report whether both length and width clear comfortably and whether the nominal2mm lining space looks appropriate. Tape uncertainty may require extra end clearance. These gauges do not reproduce a100mm-deep pocket or prove lid clearance.

PRINT SETTINGS
Use your calibrated PETG profile for X1 Carbon/0.4 nozzle. Suggested fit-test starting process:0.20 layers,4 walls,3 top/bottom layers,15–20% infill. All profiles are vertical extrusions with flat bases and need no supports. A small brim may help the long thin pieces. Maximum piece footprint is approximately230.3 x166.8,so each fits individually on the256 bed;verify any brim/bed exclusions in Preview and split across plates as needed. Do not stack pieces.
STLs are in bed coordinates. STEP parts and Case_Perimeter_Assembly.step preserve assembly coordinates and are reference CAD,not prearranged print plates.

LAYOUT PROOF
Preliminary_Layout.png shows the proposed two-row,opposite-orientation arrangement with accessory spaces at the free ends,central divider/finger access,and four module regions. Rectangles represent measured clearance envelopes,not a detailed reverse-engineered Voltra model. Accessory spaces,case corner radius,liner thickness and final joints remain provisional. No custom accessory pockets are printed in this kit.
A100mm-high structural insert is deliberately not included yet. After perimeter/device fit feedback,we can finalize its frame walls,liner pads,finger openings and secure section joints. The thin gauge joints should not simply be assumed adequate for the final assembly.

VALIDATION
All6 parts valid single CAD solids. No mutual penetration between case gauge parts or between device gauge halves. Ideal complete329 x107.94 device envelope clears the band. Individual footprints below246 in both axes. STL meshes watertight,consistently wound,positive volume,and correctly placed atZ0 with3/6 heights. CAD_validation.json and mesh_validation.json included.
Physical case fit,device clearance,padding/compression,final joint strength,closed-lid clearance and transport protection remain UNTESTED. This kit establishes fit before a large PETG print.
