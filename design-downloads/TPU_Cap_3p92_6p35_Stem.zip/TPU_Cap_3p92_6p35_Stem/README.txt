VOLTRA TPU CAP — USER-SELECTED3.92 TIP SPAN

Millimetres. Opposing tips3.92; stem6.35 from head underside; circular head10.22 diameter x2.43 thick; total8.78. Same12 tangent circular-arc hexalobular proportions as V4, uniformly sized to3.92. Scaled T20-reference cosmetic retention plug, not a certified driver.

PRINT_TPU_Cap_3p92_Stem6p35_Total8p78.stl is oriented with circular head on bed and stem upright. Matching STEP and source included. Use the same calibrated CR-TPU black settings as your fit trials. No supports expected. The0.05 stem-length increment over6.30 may round to the same final layer count at common layer heights; width is the primary fit adjustment.

Valid single CAD solid;12 arc section and tangency verified; STL watertight with consistent winding and positive volume;Z0 base and8.78 height checked. Nominal axial clearance from earlier6.51–6.81 depth is0.16–0.46, subject to actual seating. Printed fit and retention remain UNTESTED.
