from pathlib import Path
import math,json,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import cadquery as c
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path('/workspace/designs/output/TPU_Cap_3p92_6p35_Stem');O.mkdir(exist_ok=True)
# Reference dimensions: bd_warehouse iso10664def.csv T20 RECESS row.
# Scale reference proportions to user's measured plug tip span; not a certified driver.
A0,B0,R0=3.95,2.85,.307
report={};profiles={}
def vec(a):return c.Vector(float(a[0]),float(a[1]),0)
def unit(theta):return np.array([math.cos(theta),math.sin(theta)])
for label,A,stem_length in [('3p92_Stem6p35_Total8p78',3.92,6.35)]:
 scale=A/A0;B=B0*scale;Re=R0*scale;h=A/2-Re;b=B/2;co=math.cos(math.pi/6)
 # External tangency: |(b+Ri)u30 - h*u0| = Ri+Re.
 Ri=(Re*Re-b*b-h*h+2*h*b*co)/(2*b-2*h*co-2*Re)
 assert Ri>0 and Re>0
 centers=[h*unit(k*math.pi/3) for k in range(6)]
 valleys=[(b+Ri)*unit(k*math.pi/3+math.pi/6) for k in range(6)]
 P=[];Q=[]
 for k in range(6):
  C=centers[k];D=valleys[k];Cnext=centers[(k+1)%6]
  assert abs(np.linalg.norm(D-C)-(Ri+Re))<1e-9
  p=C+Re*(D-C)/(Re+Ri);q=Cnext+Re*(D-Cnext)/(Re+Ri)
  P.append(p);Q.append(q)
 edges=[];sampled=[]
 def sample_arc(center,start,middle,end,n=60):
  a=math.atan2(*(start-center)[::-1]);m=math.atan2(*(middle-center)[::-1]);e=math.atan2(*(end-center)[::-1])
  total=(e-a)%(2*math.pi);mid=(m-a)%(2*math.pi)
  if mid>total:total-=2*math.pi
  rr=np.linalg.norm(start-center)
  return [center+rr*unit(t) for t in np.linspace(a,a+total,n,endpoint=False)]
 for k in range(6):
  tip=A/2*unit(k*math.pi/3);valley=b*unit(k*math.pi/3+math.pi/6)
  edges.append(c.Edge.makeThreePointArc(vec(Q[(k-1)%6]),vec(tip),vec(P[k])))
  edges.append(c.Edge.makeThreePointArc(vec(P[k]),vec(valley),vec(Q[k])))
  sampled+=sample_arc(centers[k],Q[(k-1)%6],tip,P[k])
  sampled+=sample_arc(valleys[k],P[k],valley,Q[k])
 wire=c.Wire.assembleEdges(edges);assert wire.IsClosed() and wire.isValid()
 assert len(wire.Edges())==12 and all(e.geomType()=='CIRCLE' for e in wire.Edges())
 face=c.Face.makeFromWires(wire);assert face.isValid()
 stem=c.Solid.extrudeLinear(wire,[],c.Vector(0,0,stem_length)).translate((0,0,2.43))
 head=c.Solid.makeCylinder(10.22/2,2.43)
 part=head.fuse(stem).clean();assert part.isValid() and len(part.Solids())==1
 bb=part.BoundingBox();assert abs(bb.zmin)<1e-7 and abs(bb.zmax-(2.43+stem_length))<1e-7
 radii=np.linalg.norm(np.array(sampled),axis=1)
 assert abs(radii.max()-A/2)<.0001 and abs(radii.min()-B/2)<.0001
 name='TPU_Cap_'+label
 c.exporters.export(part,str(O/(name+'.step')))
 assert part.exportStl(str(O/('PRINT_'+name+'.stl')),tolerance=.002,angularTolerance=.035,relative=False)
 profiles[label]=np.array(sampled)
 report[label]={'valid':True,'solids':1,'tip_diameter_mm':A,'valley_diameter_mm':B,'convex_lobe_radius_mm':Re,'concave_valley_radius_mm':Ri,'exact_circular_arcs_in_section':12,'tangent_arc_junctions':12,'head_diameter_mm':10.22,'head_thickness_mm':2.43,'stem_from_head_underside_mm':stem_length,'total_height_mm':2.43+stem_length,'volume_mm3':part.Volume(),'on_bed':True,'reference':'ISO10664 recess proportions from bd_warehouse T20 row,scaled to plug dimensions;not a certified driver or exact kit reproduction','physical_fit':'UNTESTED'}
 print(label,'12 tangent circular arcs;valid solid; exported',flush=True)


report['user_feedback']='Tested V2 3.84 slightly looser than kit original; current printed overall height8.74; user attributes fit primarily to width and requests only0.05 additional stem length relative to original6.30.'
report['earlier_available_depth_mm']=[6.51,6.81]
report['nominal_axial_margin_mm']=[6.51-6.35,6.81-6.35]
report['revision']='User-selected3.92 tip span; same head,6.35 stem,8.78 total and tangent-arc proportions as V4.'
(O/'CAD_validation.json').write_text(json.dumps(report,indent=2))
