"""Trace supplied high-contrast artwork, without fonts or a generative redraw."""
from pathlib import Path
from collections import defaultdict
import json,math,shutil
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT=Path('/workspace/designs/Apache_4800_Voltra_Insert')
OUT=Path('/workspace/designs/output/Skull_Fitness_Logo_Trace')
OUT.mkdir(exist_ok=True,parents=True)
SOURCE=Path('/tmp/codex-remote-attachments/01a15b88-57c3-7187-adef-99fc64b5b028/c9db0d12-2dcb-44c1-84fe-9e277a990048/1-1000017381.jpg')
gray=np.array(Image.open(SOURCE).convert('L'))
mask=ndi.gaussian_filter(gray.astype(float),.55)>=128
labels,count=ndi.label(mask)
sizes=np.bincount(labels.ravel())
mask &= sizes[labels]>=8
yy,xx=np.where(mask)
mn=np.array([xx.min(),yy.min()],float)
mx=np.array([xx.max()+1,yy.max()+1],float)
mid=(mn+mx)/2
scale=55/(mx[1]-mn[1])

def area(p):
    p=np.array(p)
    return float(np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1))/2)

def rdp(p,tolerance):
    p=np.array(p,float)
    if len(p)<=2:return p
    d=p[-1]-p[0]
    if np.dot(d,d)<1e-12:dist=np.linalg.norm(p-p[0],axis=1)
    else:dist=np.abs(d[0]*(p[:,1]-p[0,1])-d[1]*(p[:,0]-p[0,0]))/np.linalg.norm(d)
    j=int(np.argmax(dist))
    if dist[j]<=tolerance:return p[[0,-1]]
    return np.vstack([rdp(p[:j+1],tolerance)[:-1],rdp(p[j:],tolerance)])

def simplify_closed(p,tolerance=1.):
    p=np.array(p,float)
    j=int(np.argmax(np.linalg.norm(p-p[0],axis=1)))
    return np.vstack([rdp(p[:j+1],tolerance)[:-1],rdp(np.vstack([p[j:],p[:1]]),tolerance)[:-1]])

direction={(1,0):0,(0,1):1,(-1,0):2,(0,-1):3}
rank={1:0,0:1,3:2,2:3}
shapes=[]
bounds=ndi.find_objects(labels)
for lab in range(1,count+1):
    if sizes[lab]<8:continue
    sy,sx=bounds[lab-1]
    sub=(labels[sy,sx]==lab)
    pad=np.pad(sub,1)
    transitions=[sub & ~pad[:-2,1:-1],sub & ~pad[1:-1,2:],
                 sub & ~pad[2:,1:-1],sub & ~pad[1:-1,:-2]]
    graph=defaultdict(list)
    for side,transition in enumerate(transitions):
        for y,x in np.argwhere(transition):
            x=int(x)+sx.start;y=int(y)+sy.start
            if side==0:a,b=(x,y),(x+1,y)
            elif side==1:a,b=(x+1,y),(x+1,y+1)
            elif side==2:a,b=(x+1,y+1),(x,y+1)
            else:a,b=(x,y+1),(x,y)
            graph[a].append(b)
    loops=[]
    while graph:
        start=next(iter(graph));cur=start;prev=None;loop=[]
        while True:
            loop.append(cur)
            choices=graph[cur]
            if prev is None or len(choices)==1:k=0
            else:
                incoming=direction[(cur[0]-prev[0],cur[1]-prev[1])]
                k=min(range(len(choices)),key=lambda i:rank[(direction[(choices[i][0]-cur[0],choices[i][1]-cur[1])]-incoming)%4])
            nxt=choices.pop(k)
            if not choices:del graph[cur]
            prev,cur=cur,nxt
            if cur==start:break
        original_area=area(loop)
        if abs(original_area)<8:continue
        p=simplify_closed(loop)
        assert area(p)*original_area>0
        q=(p-mid)*[scale,-scale]
        # Explicit CCW outer and CW holes in world XY.
        if (area(q)>0)!=(original_area>0):q=q[::-1]
        loops.append({'outer':original_area>0,'points_mm':q.tolist(),
                      'source_area_px':original_area,'points_px':p.tolist()})
    assert sum(l['outer'] for l in loops)==1,(lab,'multiple outer contours')
    shapes.append({'source_component':lab,'loops':loops})

result={'source_filename':'1000017381.jpg','source_size_px':[gray.shape[1],gray.shape[0]],
        'threshold':128,'noise_component_min_px':8,'smoothing_sigma_px':.55,
        'outline_simplification_tolerance_px':1,'outline_tolerance_mm':scale,
        'logo_height_mm':55,'logo_width_mm':(mx[0]-mn[0])*scale,
        'trace_method':'Foreground pixel boundary trace of supplied artwork; white areas engraved; grayscale flattened; no replacement font or generative redraw',
        'shapes':shapes}
(OUT/'Skull_Fitness_Trace.json').write_text(json.dumps(result,indent=2))
w,h=result['logo_width_mm'],55
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{-w/2-2:.5f} {-h/2-2:.5f} {w+4:.5f} {h+4:.5f}">',
     '<title>Skull Fitness — source-traced contours for recessed CAD logo</title>',
     f'<rect x="{-w/2-2}" y="{-h/2-2}" width="{w+4}" height="{h+4}" fill="black"/>']
for shape in shapes:
    path=''
    for loop in shape['loops']:
        p=np.array(loop['points_mm'])*[1,-1]
        path+='M '+' L '.join(f'{x:.5f} {y:.5f}' for x,y in p)+' Z '
    svg.append(f'<path fill="white" fill-rule="evenodd" d="{path}"/>')
svg.append('</svg>')
(OUT/'Skull_Fitness_Trace.svg').write_text('\n'.join(svg))

# Engineering proof of traced outlines, using the same polygons as the CAD.
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MP
from matplotlib.patches import PathPatch
fig,ax=plt.subplots(figsize=(7,7.5));fig.patch.set_facecolor('#15191d');ax.set_facecolor('#15191d')
for shape in shapes:
    verts=[];codes=[]
    for loop in shape['loops']:
        p=loop['points_mm'];verts.extend(p+[p[0]]);codes.extend([MP.MOVETO]+[MP.LINETO]*(len(p)-1)+[MP.CLOSEPOLY])
    ax.add_patch(PathPatch(MP(verts,codes),facecolor='white',edgecolor='none'))
ax.set_aspect('equal');ax.set_xlim(-w/2-2,w/2+2);ax.set_ylim(-h/2-2,h/2+2);ax.axis('off')
fig.text(.5,.025,f'Source-traced logo • {w:.2f} × 55 mm • no font substitution',ha='center',fontsize=10,color='white')
fig.subplots_adjust(left=.02,right=.98,top=.98,bottom=.07)
fig.savefig(OUT/'Skull_Fitness_Flat_Proof.png',dpi=180)
shutil.copy(SOURCE,OUT/'Supplied_Skull_Fitness_Logo.jpg')
shutil.copy(__file__,OUT/'trace_skull_logo.py')
print(json.dumps({k:v for k,v in result.items() if k!='shapes'},indent=2))
print('Components:',len(shapes),'boundary vertices:',sum(len(l['points_mm']) for s in shapes for l in s['loops']))
