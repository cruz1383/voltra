from pathlib import Path
import json
from functools import lru_cache
import cadquery as cq

TRACE=Path('/workspace/designs/output/Skull_Fitness_Logo_Trace/Skull_Fitness_Trace.json')

@lru_cache(maxsize=4)
def logo_cutters(height=.62):
    data=json.loads(TRACE.read_text())
    result=[]
    for shape in data['shapes']:
        outer=None;holes=[]
        for loop in shape['loops']:
            wire=cq.Workplane('XY').polyline([tuple(p) for p in loop['points_mm']]).close().val()
            assert wire.isValid()
            if loop['outer']:outer=wire
            else:holes.append(wire)
        assert outer is not None
        solid=cq.Solid.extrudeLinear(outer,holes,cq.Vector(0,0,height))
        assert solid.isValid() and len(solid.Solids())==1,shape['source_component']
        assert solid.Volume()>0
        result.append(solid)
    return data,result

def placed_logo(x,y,z,angle=0,height=.62):
    _,solids=logo_cutters(height)
    if angle:solids=[s.rotate((0,0,0),(0,0,1),angle) for s in solids]
    return cq.Compound.makeCompound([s.translate((x,y,z)) for s in solids])

if __name__=='__main__':
    data,solids=logo_cutters()
    print('Validated',len(solids),'logo engraving solids; dimensions',data['logo_width_mm'],data['logo_height_mm'])
