from pathlib import Path
from collections import Counter
import json, struct
import numpy as np

OUT=Path('/workspace/designs/output/Apache_4800_Full_Insert_V4')
report={}
files=list(OUT.glob('*.stl'))
assert len(files)==10
for p in files:
    data=p.read_bytes()
    n=struct.unpack_from('<I',data,80)[0]
    assert len(data)==84+50*n
    dtype=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')])
    a=np.frombuffer(data,dtype=dtype,offset=84,count=n)['points'].astype(float)
    assert np.isfinite(a).all()
    ids={};counts=Counter();orient=Counter()
    for t in a:
        vi=[]
        for v in t:
            key=tuple(np.round(v,5))
            vi.append(ids.setdefault(key,len(ids)))
        assert len(set(vi))==3,(p,'collapsed triangle')
        for u,v in zip(vi,vi[1:]+vi[:1]):
            edge=tuple(sorted((u,v)))
            counts[edge]+=1;orient[edge]+=1 if u<v else -1
    assert all(v==2 for v in counts.values()),(p,'nonmanifold/open edge')
    assert all(v==0 for v in orient.values()),(p,'winding inconsistency')
    volume=np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6
    assert volume>0
    xyz=a.reshape(-1,3)
    mn=xyz.min(axis=0);mx=xyz.max(axis=0)
    expected_h={'OPTIONAL_Handle_End_R15.stl':3,'OPTIONAL_Screen_End_R2.stl':3,'OPTIONAL_Logo_Print_Test.stl':2,'OPTIONAL_Upright_Carabiner_Pair.stl':38}.get(p.name,100)
    assert abs(mn[2])<1e-5 and abs(mx[2]-expected_h)<1e-5,(p,'height/bed placement')
    assert mx[0]-mn[0]+10<=256 and mx[1]-mn[1]+10<=256
    report[p.name]={'triangles':n,'watertight':True,'consistent_winding':True,
                    'on_bed':True,'bounds_min_mm':mn.tolist(),'bounds_max_mm':mx.tolist(),
                    'positive_volume_cm3':volume/1000,'fits_with_5mm_brim':True}
(OUT/'mesh_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
