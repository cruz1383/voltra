"""Small two-slot coupon using the full model's exact upright pocket geometry."""
from pathlib import Path
import os,json,shutil
os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import cadquery as cq
OUT=Path('/workspace/designs/output/Apache_4800_Full_Insert_V4')
def rr(l,w,r,y=0,h=38,z=0):
    return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,y,z))
p=rr(88,38,5)
for y in [-8.25,8.25]:
    p=p.cut(rr(78,11.5,2,y,h=35.2,z=3))
    hardware=cq.Solid.makeBox(75.78,8.91,39.81,cq.Vector(-75.78/2,y-8.91/2,3))
    assert p.intersect(hardware).Volume()<1e-6
p=p.clean()
assert p.isValid() and len(p.Solids())==1
b=p.BoundingBox()
cq.exporters.export(p,str(OUT/'OPTIONAL_Upright_Carabiner_Pair.step'))
p.translate((-b.xmin,-b.ymin,0)).exportStl(str(OUT/'OPTIONAL_Upright_Carabiner_Pair.stl'),tolerance=.025,angularTolerance=.07,relative=False)
rp=OUT/'CAD_validation.json'
r=json.loads(rp.read_text())
r['optional_upright_carabiner_coupon']={'height_mm':38,'opening_mm':[78,11.5],
                                      'depth_mm':35,'divider_mm':5,'count':2,
                                      'envelope_clearance_checked':True,'actual_full_model_slot_geometry':True}
rp.write_text(json.dumps(r,indent=2))
shutil.copy(__file__,OUT/'build_v4_fit_tests.py')
print('Small upright carabiner test exported')
