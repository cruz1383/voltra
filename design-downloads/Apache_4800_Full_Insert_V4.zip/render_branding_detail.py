"""Engineering plan-view detail drawn from the same contours used in the CAD."""
from pathlib import Path
import json,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MP
from matplotlib.patches import FancyBboxPatch,PathPatch
OUT=Path('/workspace/designs/output/Apache_4800_Full_Insert_V4')
trace=json.loads(Path('/workspace/designs/output/Skull_Fitness_Logo_Trace/Skull_Fitness_Trace.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(13,7))
fig.patch.set_facecolor('#fafbf9')
for ax,angle,title in zip(axes,[0,180],['Right charger pocket','Left charger pocket']):
    ax.set_facecolor('#fafbf9')
    ax.add_patch(FancyBboxPatch((-43.5,-32.5),87,65,
                 boxstyle='round,pad=0,rounding_size=4',facecolor='#b2c0c4',edgecolor='#415761',lw=2))
    for shape in trace['shapes']:
        vertices=[];codes=[]
        for loop in shape['loops']:
            p=np.array(loop['points_mm'])
            if angle:p=-p
            vertices.extend(p.tolist()+[p[0].tolist()])
            codes.extend([MP.MOVETO]+[MP.LINETO]*(len(p)-1)+[MP.CLOSEPOLY])
        ax.add_patch(PathPatch(MP(vertices,codes),facecolor='#314954',edgecolor='none'))
    ax.set_aspect('equal');ax.set_xlim(-47,47);ax.set_ylim(-37,37);ax.axis('off')
    ax.set_title(title,fontsize=13,pad=14)
fig.suptitle('Skull Fitness - both charger-pocket floors',fontsize=19,weight='bold',y=.96)
fig.text(.5,.885,'Source-traced artwork: 53.93 × 55 mm | Recessed 0.6 mm | No part ID lettering on the main sections',
         ha='center',fontsize=10)
fig.text(.5,.08,'Engineering top-view detail from the exact CAD contours. Engraved areas darkened for clarity; print uses one color.\n'
         'Logos face opposite directions to follow the two Voltras. Fine detail depends on nozzle and slicer resolution.',
         ha='center',fontsize=10,linespacing=1.8)
fig.subplots_adjust(left=.03,right=.97,top=.81,bottom=.17,wspace=.12)
fig.savefig(OUT/'Charger_Logo_Detail.png',dpi=180)
fig.savefig(OUT/'Charger_Logo_Detail.pdf')
print('Branding detail rendered')
