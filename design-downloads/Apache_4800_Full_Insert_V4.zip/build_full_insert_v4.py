"""V4: source-traced Skull Fitness logos recessed in charger floors, no part labels."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/jig-mpl')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/jig-cache')
import json
import math
import shutil
import numpy as np
import cadquery as cq
from skull_logo_geometry import placed_logo,logo_cutters

ROOT = Path('/workspace/designs/Apache_4800_Voltra_Insert')
OUT = Path('/workspace/designs/output/Apache_4800_Full_Insert_V4')
OUT.mkdir(parents=True, exist_ok=True)
L, W, R, H = 452.025, 320.2625, 20., 100.
SEAM = .30

def box(x,y,z,l,w,h):
    return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))

def rr(l,w,r,x=0,y=0,h=H,z=0):
    return (cq.Workplane('XY').box(l,w,h,centered=(True,True,False))
            .edges('|Z').fillet(r).val().translate((x,y,z)))

def disk(r,x,y,h,z=0):
    return cq.Solid.makeCylinder(r,h,cq.Vector(x,y,z))

def extrude_profile(shape, z, h):
    faces=[f for f in shape.Faces() if abs(f.Center().z)<1e-7 and f.normalAt().z<-.99]
    assert len(faces)==1
    f=faces[0]
    return cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),cq.Vector(0,0,h)).translate((0,0,z))

# Reuse the reviewed pocket definitions, without executing preview exports or plots.
preview_source=(ROOT/'build_layout_preview_v3.py').read_text()
prefix=preview_source[:preview_source.index('validation =')]
namespace={'__name__':'preview_profiles'}
exec(prefix,namespace)
review_pockets=namespace['pockets']

# Retain tested R15 handle curves and add a subtle R2 cover/screen-end radius.
def handle_opening(l,w,cx,cy,side,h=3,body_r=2.,handle_r=15):
    wp=cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).translate((cx,cy,0))
    handle_selector='|Z and >X' if side>0 else '|Z and <X'
    body_selector='|Z and <X' if side>0 else '|Z and >X'
    return wp.edges(handle_selector).fillet(handle_r).edges(body_selector).fillet(body_r).val()

profile_changes={}
for name,side in [('Red',1),('Green',-1)]:
    cx=side*(-L/2+24+329/2)
    yc=side*81
    old_base=rr(333,108.22,.5,cx,yc,h=3)
    base=handle_opening(333,108.22,cx,yc,side)
    extras=review_pockets[name+' device'].cut(old_base)
    new=base.fuse(extras).clean()
    assert new.isValid() and len(new.Solids())==1
    # Added curves at either end must still clear the full measured cover envelope.
    cover_cx=side*(-L/2+24+291.04/2)
    body=box(cover_cx-291.04/2,yc-107.72/2,0,291.04,107.72,3)
    change=review_pockets[name+' device'].cut(new)
    assert change.intersect(body).Volume()<1e-6
    profile_changes[name]={'handle_end_radius_mm':15,'body_end_radius_mm':2.,
                           'change_intersects_measured_body':False}
    review_pockets[name+' device']=new
    del review_pockets[name+' carabiner']
    for slot,cy in enumerate([side*118.75,side*135.25],start=1):
        review_pockets[f'{name} {slot} carabiner']=rr(78,11.5,2,side*177,cy,h=3)

# Check all revised openings before constructing the tall model.
profile_names=list(review_pockets)
profile_distances={}
for i,name in enumerate(profile_names):
    p=review_pockets[name]
    for other in profile_names[i+1:]:
        distance=p.distance(review_pockets[other])
        assert distance>=5-1e-6,(name,other,distance)
        profile_distances[name+' / '+other]=distance

depths={'device':100., 'stopper':45., 'carabiner':35., 'charger':70.}
pockets={}
for name,p in review_pockets.items():
    category=name.split()[-1]
    dep=depths[category]
    # Device openings go through the base. Other pockets have raised floors.
    pockets[name]=extrude_profile(p,H-dep,dep+.2)

# The pin's longitudinal station is known. Matching small channels on both long
# walls accommodate either installed cover orientation, without guessing the side.
for name,side in [('Red',1),('Green',-1)]:
    yc=side*81
    px=side*(-L/2+24+291.04-100.79)
    for py in [yc-108.22/2,yc+108.22/2]:
        pin=box(px-2.6,py-2 if py<yc else py-.01,0,5.2,2.01,H+.2)
        pockets[name+' device']=pockets[name+' device'].fuse(pin).clean()

full=rr(L,W,R)
for name,p in pockets.items():
    full=full.cut(p)
full=full.clean()
assert full.isValid() and len(full.Solids())==1
print('Full-height pockets built',flush=True)

def cable_groove(side):
    # Same cubic as the reviewed plan. Build a constant-width polygon around it.
    control=np.array([[-45,26.89],[-48,9],[-78,0],[-120,0]],float)*side
    t=np.linspace(0,1,101)[:,None]
    p=((1-t)**3*control[0]+3*(1-t)**2*t*control[1]
       +3*(1-t)*t*t*control[2]+t**3*control[3])
    d=(3*(1-t)**2*(control[1]-control[0])+6*(1-t)*t*(control[2]-control[1])
       +3*t*t*(control[3]-control[2]))
    normal=np.stack([-d[:,1],d[:,0]],axis=1)
    normal/=np.linalg.norm(normal,axis=1)[:,None]
    poly=np.vstack([p+3*normal,(p-3*normal)[::-1]])
    shape=(cq.Workplane('XY').polyline([tuple(v) for v in poly]).close()
           .extrude(6.2).val().translate((0,0,94)))
    for x,y in [p[0],p[-1]]:
        shape=shape.fuse(disk(3,x,y,6.2,94))
    return shape.clean()

grooves=[cable_groove(1),cable_groove(-1)]
for g in grooves:
    full=full.cut(g)
full=full.clean()
assert full.isValid() and len(full.Solids())==1

# Use the same in-plane key profile and clearances as the successful perimeter
# gauge. Female tracks are open along Z; two shorter male pads limit friction.
# Wider dovetail: 6mm neck,10mm head,7mm reach, with1mm concave root arcs.
KEY_POINTS=[(-2,-4),(-.15,-4),(.85,-3),(2,-3),(7,-5),(7,5),(2,3),(.85,3),(-.15,4),(-2,4)]
def key_wire(axis,cx,cy,scale=1):
    def t(u,v):
        u=-2+(u+2)*scale
        return (cx+u,cy+v) if axis=='x' else (cx+v,cy+u)
    return (cq.Workplane('XY').moveTo(*t(-2,-4)).lineTo(*t(-.15,-4))
            .threePointArc(t(.1428932188,-3.2928932188),t(.85,-3))
            .lineTo(*t(2,-3)).lineTo(*t(7,-5)).lineTo(*t(7,5))
            .lineTo(*t(2,3)).lineTo(*t(.85,3))
            .threePointArc(t(.1428932188,3.2928932188),t(-.15,4))
            .lineTo(*t(-2,4)).close())

def male_key(axis,cx,cy):
    # Lower 20 mm pad sits on the bed. Upper pad has a ~45 degree lead-in ramp.
    low=key_wire(axis,cx,cy).extrude(20).val()
    # Clip a constant curved key prism with a planar incline. This avoids
    # sliver faces from intersecting an evolving curved loft with the key.
    uz=[(-2,66),(-.15,66),(7,77),(-2,77)]
    points=[cq.Vector(cx+u,cy-6,z) if axis=='x' else cq.Vector(cx-6,cy+u,z) for u,z in uz]
    wire=cq.Wire.makePolygon(points+[points[0]])
    vector=cq.Vector(0,12,0) if axis=='x' else cq.Vector(12,0,0)
    wedge=cq.Solid.extrudeLinear(wire,[],vector)
    ramp=key_wire(axis,cx,cy).extrude(H).val().intersect(wedge)
    upper=key_wire(axis,cx,cy).extrude(23).val().translate((0,0,77))
    return low.fuse(ramp,upper).clean()

def female_key(axis,cx,cy):
    return key_wire(axis,cx,cy).offset2D(.20).extrude(H+2).val().translate((0,0,-1))

parts={}
for name,sx,sy in [('BL',-1,-1),('BR',1,-1),('TL',-1,1),('TR',1,1)]:
    x=-L/2 if sx<0 else SEAM/2
    y=-W/2 if sy<0 else SEAM/2
    parts[name]=full.intersect(box(x,y,0,L/2-SEAM/2,W/2-SEAM/2,H))

joints=[]
for cy,left,right in [(-147.5,'BL','BR'),(147.5,'TL','TR'),(-16,'BL','BR'),(16,'TL','TR')]:
    parts[left]=parts[left].fuse(male_key('x',0,cy))
    parts[right]=parts[right].cut(female_key('x',0,cy))
    joints.append({'axis':'x','male':left,'female':right,'center_xy_mm':[0,cy]})
for cx,bottom,top in [(-211.5,'BL','TL'),(211.5,'BR','TR'),(-16,'BL','TL'),(16,'BR','TR')]:
    parts[bottom]=parts[bottom].fuse(male_key('y',cx,0))
    parts[top]=parts[top].cut(female_key('y',cx,0))
    joints.append({'axis':'y','male':bottom,'female':top,'center_xy_mm':[cx,0]})

report={'stage':'FULL INSERT V4; no physical part labels; two recessed source-traced logos; full-height and branding print fit untested',
        'height_mm':H,'outside_mm':[L,W],'outer_corner_radius_mm':R,
        'part_count':4,'seam_gap_mm':SEAM,
        'construction':'Solid CAD volumes; use sparse slicer infill, not100percent solid printing',
        'pocket_depths_mm':depths,
        'device_open_bottom':True,'device_opening_mm':[333,108.22],
        'stopper_opening_envelope_mm':[62.97,43.27],
        'carabiner_opening_envelope_mm':[78,11.5],
        'carabiner_slot_count':4,'carabiner_orientation':'Standing on narrow edge',
        'carabiner_divider_mm':5,'carabiner_protrusion_above_insert_mm':4.81,
        'handle_opening_changes':profile_changes,
        'minimum_spacing_between_openings_mm':min(profile_distances.values()),
        'charger_opening_mm':[87,65],'charger_floor_z_mm':30,
        'cable_groove_mm':{'width':6,'depth':6,'status':'Provisional route; physical cable bend and retraction behavior untested'},
        'pin_relief':{'cover_handle_end_to_center_mm':100.79,'width_mm':5.2,'depth_mm':2,
                      'walls':'Both long walls of each device pocket; full height, for either cover-pin orientation'},
        'joints':joints,'joint_details':{'socket_offset_mm':.20,'male_lower_pad_z_mm':[0,20],
                                       'male_upper_ramp_z_mm':[66,77],'male_upper_pad_z_mm':[77,100],
                                       'socket_open_z_mm':[-1,101],'joint_count':8,'new_middle_joint_count':4,
                                       'neck_mm':6,'head_mm':10,'reach_mm':7,'root_radius_mm':1},
        'physical_fit_confirmed':['Thin V2 perimeter at cushion level','108.22mm device band','Four upright carabiner slots','R15 handle-end curves'],
        'physical_fit_untested':['100mm case taper and lid closure','Stopper and charger packing in full-height pockets',
                                'Reinforced vertical sliding joints','Cable routes and larger cable packing','R2 screen-end corners'],
        'parts':{},'assembly_overlap_checks':[],'vertical_assembly_checks':[]}

for name,p in parts.items():
    # User requested no physical TR/BR/etc labels. File names retain assembly IDs.
    if name=='TR':p=p.cut(placed_logo(177.5,61.5,29.4,0))
    elif name=='BL':p=p.cut(placed_logo(-177.5,-61.5,29.4,180))
    p=p.clean()
    assert p.isValid() and len(p.Solids())==1,(name,'invalid or disconnected')
    assert p.cut(rr(L,W,R)).Volume()<1e-5,(name,'protrudes past case envelope')
    parts[name]=p
    cq.exporters.export(p,str(OUT/f'Insert_{name}.step'))
    b=p.BoundingBox()
    q=p.translate((-b.xmin,-b.ymin,-b.zmin))
    assert b.xlen+10<=256 and b.ylen+10<=256 and abs(b.zlen-H)<1e-6
    q.exportStl(str(OUT/f'PRINT_Insert_{name}.stl'),tolerance=.025,
                angularTolerance=.07,relative=False)
    report['parts'][name]={'valid_single_solid':True,'footprint_mm':[b.xlen,b.ylen],
                           'with_5mm_brim_mm':[b.xlen+10,b.ylen+10],
                           'height_mm':b.zlen,'solid_cad_volume_cm3':p.Volume()/1000,
                           'print_orientation':'Flat bottom on bed; open pockets up; no engraved part ID'}
    print('Exported '+name,flush=True)

for i,a in enumerate(parts):
    for b in list(parts)[i+1:]:
        vol=parts[a].intersect(parts[b]).Volume()
        assert vol<1e-5,(a,b,vol)
        report['assembly_overlap_checks'].append({'parts':[a,b],'intersection_mm3':vol})

# Simulate lowering BR, then TL, then TR onto BL. Motion is along open socket
# tracks. Sampled checks complement the prismatic socket geometry inspection.
placed=['BL']
for name in ['BR','TL','TR']:
    for dz in [1,5,12,20,40,60,66,71,77,90,100.2]:
        moving=parts[name].translate((0,0,dz))
        for other in placed:
            v=moving.intersect(parts[other]).Volume()
            assert v<1e-5,(name,other,dz,v)
    report['vertical_assembly_checks'].append({'part':name,'placed_parts':placed.copy(),
              'sampled_z_offsets_mm':[1,5,12,20,40,60,66,71,77,90,100.2],'no_interference':True})
    placed.append(name)

# Check the measured cover independently of the approximate U-shaped handle.
body_checks=[]
for side in [1,-1]:
    yc=side*81
    body_cx=side*(-L/2+24+291.04/2)
    ideal_body=box(body_cx-291.04/2,yc-107.72/2,0,291.04,107.72,H)
    handle_end=side*(-L/2+24+291.04)
    outer_handle=rr(2*(329-291.04),107.72-16,15,handle_end,yc,h=H)
    inner_handle=rr(2*(329-291.04)-20,107.72-36,5,handle_end,yc,h=H)
    approximate_handle=outer_handle.cut(inner_handle)
    exposed_half=box(handle_end if side>0 else handle_end-50,yc-60,0,50,120,H)
    approximate_handle=approximate_handle.intersect(exposed_half)
    for name,p in parts.items():
        assert p.intersect(ideal_body).Volume()<1e-5,(name,'cover interference')
        assert p.intersect(approximate_handle).Volume()<1e-5,(name,'approximate handle interference')
    body_checks.append({'side':side,'measured_cover_clear':True,
                        'approximate_handle_clear':True,'handle_shape_status':'Illustrative U envelope; width91.72mm and R15 corners are not measured handle dimensions'})
report['body_and_approximate_handle_checks']=body_checks

# Four measured-size hardware envelopes clear their independent upright slots.
carabiner_checks=[]
for side in [1,-1]:
    for cy in [side*118.75,side*135.25]:
        hardware=box(side*177-75.78/2,cy-8.91/2,65,75.78,8.91,39.81)
        for name,p in parts.items():
            assert p.intersect(hardware).Volume()<1e-5,(name,'carabiner interference')
        carabiner_checks.append({'center_xy_mm':[side*177,cy],'floor_z_mm':65,
                                'envelope_mm':[75.78,8.91,39.81],'no_interference':True})
report['carabiner_envelope_checks']=carabiner_checks

# Report all changed sections: do not mix V2 and V3 mating joints.
old_dir=Path('/workspace/designs/output/Apache_4800_Full_Insert_V3')
report['V3_section_comparison']={}
for name,p in parts.items():
    old=cq.importers.importStep(str(old_dir/f'Insert_{name}.step')).val()
    # Prove cosmetic-only changes: label patches and shallow floor engravings.
    lx=-140 if name.endswith('L') else 140
    ly=147 if name.startswith('T') else -147
    allowed=box(lx-7,ly-4,99.49,14,8,.52)
    if name in ['BL','TR']:
        side=1 if name=='TR' else -1
        allowed=allowed.fuse(box(side*177.5-28,side*61.5-28.5,29.39,56,57,.64))
    # Remove the cosmetic regions FIRST. This avoids a costly intersection
    # between thousands of coincident artwork edges and the original floor.
    base_new=p.cut(allowed).clean()
    base_old=old.cut(allowed).clean()
    added=base_new.cut(base_old).Volume()
    removed=base_old.cut(base_new).Volume()
    assert added+removed<1e-5,(name,'unintended functional change',added,removed)
    report['V3_section_comparison'][name]={'functional_geometry_unchanged':True,
                       'difference_outside_cosmetic_regions_mm3':added+removed,
                       'main_part_labels_removed':True,'charger_floor_logo':name in ['BL','TR']}
    print('Cosmetic-only comparison passed: '+name,flush=True)

assembly=cq.Assembly(name='Apache_4800_Full_Insert_V4')
colors={'BL':(.35,.48,.55),'BR':(.53,.63,.66),'TL':(.49,.60,.63),'TR':(.34,.47,.54)}
for name,p in parts.items():
    assembly.add(p,name=name,color=cq.Color(*colors[name]))
cq.exporters.export(cq.Compound.makeCompound(list(parts.values())),str(OUT/'Assembly.step'))

# Optional full-height track coupons use the exact production key and socket.
# Broad feet aid adhesion; these are separate tests, not extra insert components.
coupons={
    'Male':box(-12,-10,0,12-SEAM/2,20,H).fuse(box(-22,-14,0,22-SEAM/2,28,2),male_key('x',0,0)),
    'Female':box(SEAM/2,-10,0,12-SEAM/2,20,H).fuse(box(SEAM/2,-14,0,22-SEAM/2,28,2)).cut(female_key('x',0,0))
}
for label,cp in coupons.items():
    cp=cp.clean()
    assert cp.isValid() and len(cp.Solids())==1
    cb=cp.BoundingBox()
    cq.exporters.export(cp,str(OUT/f'OPTIONAL_Joint_Test_{label}.step'))
    cp.translate((-cb.xmin,-cb.ymin,0)).exportStl(str(OUT/f'OPTIONAL_Joint_Test_{label}.stl'),
                    tolerance=.025,angularTolerance=.07,relative=False)
    coupons[label]=cp
assert coupons['Male'].intersect(coupons['Female']).Volume()<1e-5
# Small U-shaped handle-end test: the new exact opening, with a 6mm rim.
cx=-L/2+24+329/2
yc=81.
inner=handle_opening(333,108.22,cx,yc,1)
outer=handle_opening(345,120.22,cx,yc,1,body_r=8,handle_r=21)
end_x=cx+333/2
handle_coupon=outer.cut(inner).intersect(box(end_x-50,yc-70,0,56,140,3)).clean()
label=cq.Workplane('XY').text('R15',4,.4,combine=False).val().translate((end_x-36,yc+57,2.6))
handle_coupon=handle_coupon.cut(label).clean()
assert handle_coupon.isValid() and len(handle_coupon.Solids())==1
hb=handle_coupon.BoundingBox()
cq.exporters.export(handle_coupon,str(OUT/'OPTIONAL_Handle_End_R15.step'))
handle_coupon.translate((-hb.xmin,-hb.ymin,0)).exportStl(str(OUT/'OPTIONAL_Handle_End_R15.stl'),tolerance=.02,angularTolerance=.07,relative=False)
# New screen-end U coupon, using the exact R2 opening and a6mm outer rim.
start_x=cx-333/2
screen_coupon=outer.cut(inner).intersect(box(start_x-6,yc-70,0,56,140,3)).clean()
label=cq.Workplane('XY').text('R2',4,.4,combine=False).val().translate((start_x+36,yc+57,2.6))
screen_coupon=screen_coupon.cut(label).clean()
assert screen_coupon.isValid() and len(screen_coupon.Solids())==1
sb=screen_coupon.BoundingBox()
cq.exporters.export(screen_coupon,str(OUT/'OPTIONAL_Screen_End_R2.step'))
screen_coupon.translate((-sb.xmin,-sb.ymin,0)).exportStl(str(OUT/'OPTIONAL_Screen_End_R2.stl'),tolerance=.02,angularTolerance=.07,relative=False)
report['optional_R2_screen_coupon']={'height_mm':3,'footprint_mm':[sb.xlen,sb.ylen],'exact_model_opening':True}
report['optional_R15_handle_coupon']={'height_mm':3,'footprint_mm':[hb.xlen,hb.ylen],'actual_full_model_opening':True}
report['optional_joint_coupons']={'count':2,'height_mm':H,'purpose':'Test actual100mm track and two-tier key before large prints'}
# Optional flat plate checks the artwork at its actual production scale/depth.
logo_data,_=logo_cutters()
logo_plate=rr(64,65,3,h=2)
logo_plate=logo_plate.cut(placed_logo(0,0,1.4,0)).clean()
assert logo_plate.isValid() and len(logo_plate.Solids())==1
cq.exporters.export(logo_plate,str(OUT/'OPTIONAL_Logo_Print_Test.step'))
logo_plate.translate((32,32.5,0)).exportStl(str(OUT/'OPTIONAL_Logo_Print_Test.stl'),tolerance=.015,angularTolerance=.07,relative=False)
report['branding']={'source':'1000017381.jpg','method':logo_data['trace_method'],
                    'logo_size_mm':[logo_data['logo_width_mm'],55],
                    'recess_depth_mm':.6,'floor_z_mm':30,'engraving_bottom_z_mm':29.4,
                    'locations':[{'part':'TR','center_xy_mm':[177.5,61.5],'rotation_deg':0},
                                 {'part':'BL','center_xy_mm':[-177.5,-61.5],'rotation_deg':180}],
                    'main_part_ID_lettering':False,'trace_component_count':45,
                    'fine_detail_status':'Faithful trace; sub-nozzle details may soften or disappear in actual FDM print',
                    'physical_print_tested':False}
report['measured_body_envelope_clearance_checked']=True
report['total_solid_CAD_volume_cm3']=sum(x['solid_cad_volume_cm3'] for x in report['parts'].values())
(OUT/'CAD_validation.json').write_text(json.dumps(report,indent=2))
shutil.copy(__file__,OUT/'build_full_insert_v4.py')
shutil.copy(ROOT/'build_layout_preview_v3.py',OUT/'build_layout_preview_v3.py')
shutil.copy(ROOT/'design_brief.json',OUT/'design_brief.json')

# Software depth-buffer render of actual exported STL surfaces.
import runpy
runpy.run_path(str(ROOT/'build_v4_fit_tests.py'),run_name='__main__')
runpy.run_path(str(ROOT/'render_full_insert_v4.py'),run_name='__main__')
print(json.dumps({'output':str(OUT),'part_count':len(parts),'all_CAD_checks_passed':True},indent=2),flush=True)
