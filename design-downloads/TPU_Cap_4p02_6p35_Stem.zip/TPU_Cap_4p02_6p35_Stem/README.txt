VOLTRA TPU CAP —4.02 TIP SPAN

Units mm. User requested4.02 after previous3.96/3.98 trials remained slightly loose. Opposing tips4.02 (+0.04 overall /0.02 per side relative to3.98). Same uniformly scaled12 tangent circular-arc hexalobular profile. Head unchanged10.22 diameter x2.43;stem6.35 from head underside;total8.78. Cosmetic TPU plug, not certified driver geometry.

PRINT_ STL is head face on bed, stem up. Matching STEP included. Keep dried CR-TPU black and printer settings consistent with prior tests. Aim for thumb-pressure retention and full seating. Earlier available depth6.51–6.81 leaves0.16–0.46 nominal axial margin.

Valid single CAD solid;12 exact arcs/tangency and dimensions checked. Mesh watertight, consistently wound, positive volume, atZ0 with8.78 total height. Physical fit and retention of4.02 remain UNTESTED.
