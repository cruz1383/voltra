"""Complete support-conscious CAD revision. Geometry audit, not slicer proof."""
from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-support-cache')
os.environ.setdefault('MPLCONFIGDIR','/tmp/voltra-support-mpl')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
import base as baseline
rigid=baseline.rigid
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,z,h):return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,0,z))
def wire_rr(l,w,r):
    p=rr(l,w,r,0,1)
    f=next(f for f in p.Faces() if f.normalAt().z<-.99)
    return f.outerWire()
def prism_yz(points,x,length):
    vs=[cq.Vector(x,y,z) for y,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(vs+[vs[0]]),[],cq.Vector(length,0,0))
def prism_xz(points,y,length):
    vs=[cq.Vector(x,y,z) for x,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(vs+[vs[0]]),[],cq.Vector(0,length,0))
def rr_flare(l,w,r,z):
    # One mm outward growth per1mm vertical height. Inner boundary is cut later.
    a=wire_rr(l,w,r).translate((0,0,z))
    b=wire_rr(l+2,w+2,r+1).translate((0,0,z+1))
    return cq.Solid.makeLoft([a,b],True)

# A45-degree peaked roof tangent outside the original valve clearance circle.
rad=3.54;zc=51.76;apex=zc+rad*math.sqrt(2);shoulder=apex-rad
valve=prism_xz([(-rad,-1),(rad,-1),(rad,shoulder),(0,apex),(-rad,shoulder)],-161.13125,7.09)
for name in ['BL','BR']:rigid[name]=rigid[name].cut(valve,tol=1e-4)

# Keep TPU contact datums; expose them0.35mm ahead of adjacent rigid walls.
for side in [1,-1]:
    cx=side*(-452.025/2+24+329/2);yc=side*81
    wp=cq.Workplane('XY').box(333,108.22,1,centered=(True,True,False)).translate((cx,yc,0))
    p=wp.edges('|Z and >X' if side>0 else '|Z and <X').fillet(15).edges('|Z and <X' if side>0 else '|Z and >X').fillet(2).val()
    face=next(f for f in p.Faces() if f.normalAt().z<-.99)
    w=face.outerWire()
    tool=cq.Workplane('XY').add(w).toPending().offset2D(.35).extrude(100.4).val().translate((0,0,-.2))
    for name in (['TL','TR'] if side>0 else ['BL','BR']):rigid[name]=rigid[name].cut(tool,tol=1e-4)

seats=[];soft={};print_shapes={};report={'parts':{},'geometry_audit':{}}
for label,side in [('Upper',1),('Lower',-1)]:
    specs=[(-147.5,135.11,60,1), (32.5,135.11,60,1),
           (-87.5,26.89,60,-1),(37.5,26.89,60,-1)]
    for i,(cx,py,width,direction) in enumerate(specs,1):
        points=[(-width/2,0),(width/2,0),(width/2+2,2.5),(-width/2-2,2.5)]
        profile=lambda:cq.Workplane('XY').polyline(points).close()
        pad=profile().extrude(90).val()
        for x in np.arange(-width/2+8,width/2-5,8):pad=pad.cut(box(float(x)-2,1.2,5,4,1.3,80))
        seat=profile().offset2D(.15).extrude(90.2).val()
        # Local V points outward into the wall. Global mirror keeps both rows.
        if direction<0:
            pad=pad.mirror('XZ');seat=seat.mirror('XZ')
        pad=pad.translate((cx,py,10));seat=seat.translate((cx,py,10))
        if side<0:pad=pad.rotate((0,0,0),(0,0,1),180);seat=seat.rotate((0,0,0),(0,0,1),180)
        name=f'{label}_Voltra_side_pad_{i}'
        soft[name]=pad;seats.append(seat)
        # Flat contact face on bed:2mm bevel grows over2.5mm height.
        local=profile().extrude(90).val()
        for x in np.arange(-width/2+8,width/2-5,8):local=local.cut(box(float(x)-2,1.2,5,4,1.3,80))
        print_shapes[name]=local.rotate((0,0,0),(1,0,0),90).translate((width/2+2,90,0))
    # End pad: same hook-free profile,50mm front contact width.
    width=50;points=[(-25,0),(25,0),(27,2.5),(-27,2.5)]
    local=cq.Workplane('XY').polyline(points).close().extrude(90).val()
    for x in [-16,-8,0,8,16]:local=local.cut(box(x-2,1.2,5,4,1.3,80))
    seat=cq.Workplane('XY').polyline(points).close().offset2D(.15).extrude(90.2).val()
    # LocalU -> worldY; localV -> -worldX at the screen end.
    pad=local.rotate((0,0,0),(0,0,1),90).translate((-204.0125,81,10))
    seat=seat.rotate((0,0,0),(0,0,1),90).translate((-204.0125,81,10))
    if side<0:pad=pad.rotate((0,0,0),(0,0,1),180);seat=seat.rotate((0,0,0),(0,0,1),180)
    name=f'{label}_Voltra_end_pad';soft[name]=pad;seats.append(seat)
    print_shapes[name]=local.rotate((0,0,0),(1,0,0),90).translate((27,90,0))

for label,side in [('Upper',1),('Lower',-1)]:
    for kind,L,W,R,floor,cx,cy in [('charger',87,65,4,30,side*177.5,side*61.5),
                                  ('stopper',62.97,43.27,21.625,55,-side*150,0)]:
        outer_y=W/2+1.5
        outer=rr(L+3,W+3,R+1.5,floor,100-floor)
        outer=outer.fuse(rr_flare(L+3,W+3,R+1.5,98),rr(L+5,W+5,R+2.5,99,1))
        cup=outer.cut(rr(L,W,R,floor+2,101-floor))
        seat=rr(L+3.3,W+3.3,R+1.65,floor,100.2-floor)
        seat=seat.fuse(rr_flare(L+3.3,W+3.3,R+1.65,97.85),rr(L+5.3,W+5.3,R+2.65,98.85,1.35))
        for d in [1,-1]:
            for x in [-3.3,2.7]:cup=cup.cut(box(x,outer_y-1.6 if d>0 else -outer_y-1.2,86,.6,2.8,14.2))
            # Both lower and upper bump faces slope; no horizontal underside.
            hook=prism_yz([(outer_y,91),(outer_y+1,94),(outer_y+1,95.5),(outer_y,96.5)],-2.7,5.4)
            # Roof recedes1.3mm over1.3mm, avoiding a flat ceiling.
            receiver=prism_yz([(outer_y-.05,90),(outer_y+1.4,90),
                               (outer_y+1.4,95.4),(outer_y-.05,96.85)],-3.6,7.2)
            if d<0:hook=hook.mirror('XZ');receiver=receiver.mirror('XZ')
            cup=cup.fuse(hook);seat=seat.fuse(receiver)
        name=f'{label}_{kind}_TPU_liner'
        assert cup.isValid() and len(cup.Solids())==1,name
        soft[name]=cup.translate((cx,cy,0));seats.append(seat.translate((cx,cy,0)))
        print_shapes[name]=cup.translate((0,0,-floor))
        print('Support-conscious liner',name,flush=True)

for name,p in list(rigid.items()):
    for seat in seats:
        a,b=p.BoundingBox(),seat.BoundingBox()
        if min(a.xmax,b.xmax)>max(a.xmin,b.xmin)+1e-6 and min(a.ymax,b.ymax)>max(a.ymin,b.ymin)+1e-6:
            p=p.cut(seat,tol=1e-4)
    assert p.isValid() and len(p.Solids())==1,name
    rigid[name]=p;b=p.BoundingBox();print_shapes['Rigid_'+name]=p.translate((-b.xmin,-b.ymin,-b.zmin))
    print('Full rigid section',name,'valid',flush=True)

assembly=cq.Assembly(name='FULL_TPU_SUPPORT_CONSCIOUS_CAD_REVIEW')
arrays={}
for family,shapes in [('rigid',rigid),('TPU',soft)]:
    for name,p in shapes.items():
        assert p.isValid() and len(p.Solids())==1,name
        assembly.add(p,name=family+'_'+name,color=cq.Color(1,.52,.12) if family=='TPU' else cq.Color(.56,.63,.67))
        v,f=p.tessellate(.045,.08)
        arrays[family+'__'+name]=np.array([q.toTuple() for q in v])[np.array(f)]
        p.exportBrep(str(OUT/(family+'_'+name+'.brep')))
assembly.save(str(OUT/'Apache_4800_Full_TPU_Support_Conscious_REVIEW_ONLY.step'))
np.savez_compressed(OUT/'cad_triangles.npz',**arrays)

for name,p in print_shapes.items():
    v,f=p.tessellate(.025,.07)
    a=np.array([q.toTuple() for q in v])[np.array(f)]
    normals=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0])
    area=np.linalg.norm(normals,axis=1)/2
    normals/=np.maximum(2*area,1e-14)[:,None]
    #46deg tolerance allows tessellation error around exact45deg surfaces.
    bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
    steep=(normals[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
    report['geometry_audit'][name]={'downward_faces_beyond_46deg_area_mm2':float(area[steep].sum()),
        'triangle_count':len(a),'bottom_on_bed':bool(abs(a[:,:,2].min())<1e-5),
        'bounds_mm':np.ptp(a.reshape(-1,3),axis=0).tolist()}
    if steep.any():
        np.savez_compressed(OUT/(name+'_overhang_candidates.npz'),triangles=a[steep],normals=normals[steep])
    p.exportBrep(str(OUT/('PRINT_ORIENTATION_'+name+'.brep')))
report.update({'stage':'Complete CAD review; no slicer or physical-print verification',
 'TPU_contact_face_proud_of_adjacent_rigid_mm':.35,
 'dovetail_front_contact_width_mm':60,'dovetail_rear_width_mm':64,
 'upward_pad_lock':'Friction fit still requires printed coupon; no hook',
 'valve_roof_apex_z_mm':apex,'valve_clearance_circle_radius_mm':rad,
 'snap_roof_slope_deg':45,'TPU_lip_underside_slope_deg':45,
 'orientation':{'rigid':'Bottom-down','cups':'Upright on floor','Voltra_pads':'Flat contact face on bed'},
 'pending':['Slicer verification for actual printer/material',
 'Printed retention fit and wall strength','Pad lift resistance and TPU creep','Physical loaded-case clearance']})
(OUT/'geometry_audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2),flush=True)
