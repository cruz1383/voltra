APACHE4800 — COMPLETE TPU CAD, SUPPORT-CONSCIOUS REVISION (REVIEW ONLY)

CONTENTS AND STATUS
The complete colored assembly now integrates four rigid sections, ten
Voltra TPU pads, two charger liners and two cord-stopper liners. The new
lip and snap geometry is integrated into the actual insert rather than
shown only on isolated coupons. This is a CAD review revision, NOT a
slicer-verified or physically tested print release. No G-code or ready-to-
print STL is supplied. STEP files can be inspected in CAD or a compatible
slicer; do not print the assembled STEP as a single merged part.

SUPPORT-CONSCIOUS CHANGES
Accessory lip undersides grow outward1mm over1mm height (45 degrees).
Snap-recess roofs slope45 degrees rather than forming flat ceilings.
Lower snap ramps grow1mm over3mm height. The upper retaining faces slope
as well. The pads use continuous hook-free dovetail rails, with no small
cantilever latch. The valve recess roof is now a45-degree peak, tangent
outside the prior clearance circle, opening continuously to the underside.
All faces are part of real CAD; no support structures are added.

REQUIRED PRINT ORIENTATIONS
Rigid sections: original flat bottom on bed, pockets upward.
Accessory TPU liners: upright on their flat floor;2mm mat remains below.
Voltra TPU pads: lay the flat contact face on the bed. They print only
2.5mm high, with their back-side flex channels open upward. Each side pad
has a60mm front contact width and64mm rear width; end pads are50/54mm.
The2mm dovetail growth occurs over2.5mm height in this orientation.
Changing orientation can introduce unsupported surfaces. See the supplied
Required_Print_Orientations.png. An optional brim is not a support.

GEOMETRY AUDIT AND CHECKS
All18 components are valid single CAD solids. In the specified print
orientations, triangle-normal analysis found zero off-bed downward surface
area beyond the46-degree overhang threshold; the extra1degree allows
tessellation tolerance around the intended45-degree slopes. The audit uses
fine CAD tessellation and excludes bottom faces resting on the bed. It
does NOT model layer paths, extrusion width, sagging, bridging, material
cooling or printed surface quality. No compatible slicer was installed in
this workspace, so a printer-profile slicing check was not executed.

Seated rigid/TPU components have no volumetric interference. Rigid pairwise
overlap and sampled vertical assembly motion checks passed. Sampled prior
pin envelopes (4.12mm diameter/1.36mm projection, +/-1.5mm lateral offsets)
and valve envelopes passed clearance checks. See geometry_audit.json and
assembly_validation.json. These establish geometry, not physical force.
Rigid sections remain within the X1C256mm bed footprint including the
previous5mm brim allowance by bounding dimensions.

PRESERVED / CLARIFIED
Original case footprint, bare carabiner slots, widened pin-channel stations,
closed-ended62.97 x43.27 stopper openings and removed finger scallops remain.
Pin channels stay8mm wide, with10mm flared entrances. Their3mm recess depth
is referenced to the original TPU contact datum. The surrounding hard
device walls now stand0.35mm behind that datum, so the TPU contacts first.
Thus the recess extends2.65mm beyond the adjacent relieved hard-wall face.
The original nominal1mm case-wall gap is used for the valve clearance.
The new valve-roof apex isZ56.7663, compared with insert topZ100 flush to
the case rim. It contains the prior R3.54mm valve-clearance circle.

The charger contact floor remainsZ32 (rigid floorZ30 plus2mm mat), and
stopper contact floorZ57. Mats cover the existing charger logos. The larger
modeled charger/cable bundle still has1.14mm nominal top clearance.
Voltras rest on the retained original bottom foam; no device floors added.
Rigid parts assemble first; install the pads and cups afterward.

REMAINING PHYSICAL / PRINT CHECKS
Support-free printing is the design intent, NOT a printer-specific guarantee.
Confirm in your actual X1C /0.4mm nozzle slicer profile before a large print.
TPU95A is the starting material. Pad-track offset is a trial0.15mm clearance,
not a proven friction fit. Dovetail lips capture sideways, but upward pad
retention still depends on testing snugness, wear and TPU creep. Cups use
sloped snap detents that also need insertion and removal force testing.
Remaining local wall strength, pin sleeve projection, loaded-case lid
clearance and actual accessory steadiness are not established by CAD.
No strength or drop-protection rating is claimed.

FILES
Apache_4800_Full_TPU_Support_Conscious_REVIEW_ONLY.step: full colored CAD.
Component_STEP/: individual parts in assembly coordinates.
Print_Orientation_STEP/: individual parts in audited print orientations.
Three PNG views, audit reports, source scripts and SHA256SUMS.txt.
Python dependencies: CadQuery2.6.1, NumPy, Pillow, Matplotlib. Base source
references the earlier V4 and valve-relief workspace directories; these
prior source designs remain separate repository downloads.
