from pathlib import Path
import os
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-support-cache')
from cad_render import render,text,Image,ImageDraw,OUT,np
import cadquery as cq
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def arrays(name,shapes):
    result={}
    for label,p in shapes.items():
        v,f=p.tessellate(.02,.07)
        result[label]=np.array([a.toTuple() for a in v])[np.array(f)]
    np.savez_compressed(OUT/(name+'.npz'),**result)
rigid={n:cq.Shape.importBrep(str(OUT/f'rigid_{n}.brep')) for n in ['BL','BR','TL','TR']}
cup=cq.Shape.importBrep(str(OUT/'TPU_Upper_stopper_TPU_liner.brep'))
clip=box(-150,15,85,12,14,15)
arrays('liner_detail',{'rigid':rigid['TL'].intersect(clip),'TPU':cup.intersect(clip)})
clip=box(-11,-160.3,43,22,11,20)
arrays('valve_detail',{'rigid_BL':rigid['BL'].intersect(clip),'rigid_BR':rigid['BR'].intersect(clip)})
for name in ['Upper_Voltra_side_pad_1','Upper_stopper_TPU_liner','Rigid_BL']:
    p=cq.Shape.importBrep(str(OUT/f'PRINT_ORIENTATION_{name}.brep'))
    arrays(name,{'rigid' if name.startswith('Rigid') else 'TPU':p})

im=Image.new('RGB',(2200,1620),'#f9f9f9')
pic,_=render('cad_triangles.npz',[.18,-.42,1.65],2200,1250)
im.paste(pic,(0,170));d=ImageDraw.Draw(im)
text(d,'Complete TPU insert — revised for printing without supports',1100,25,40)
text(d,'4 rigid sections + 14 TPU pieces | Orange: TPU | Gray: rigid | Actual CAD',1100,95,29)
text(d,'Hook-free dovetails | Beveled accessory lips | Sloped snap-pocket roofs | Peaked valve recess',1100,1430,26)
text(d,'TPU contact faces stand 0.35 mm ahead of adjacent hard walls. Finger scallops remain removed.',1100,1480,26)
text(d,'Geometry audit passed in specified orientations. Slicer and physical-print verification are still pending.',1100,1540,25)
im.save(OUT/'Full_Support_Conscious_CAD.png')

im=Image.new('RGB',(2200,1430),'#f9f9f9')
pic,_=render('liner_detail.npz',[-1,-.7,.8],1100,970);im.paste(pic,(0,195))
pic,_=render('valve_detail.npz',[.25,-1,.65],1100,970);im.paste(pic,(1100,195))
d=ImageDraw.Draw(im)
text(d,'Revised undersides — actual CAD cutaways',1100,25,42)
text(d,'Accessory lip + snap-pocket roof',550,130,31)
text(d,'Valve relief with peaked roof',1650,130,31)
text(d,'45° growth below lip; sloped receiving ledge',550,1190,26)
text(d,'45° roof preserves the valve clearance envelope',1650,1190,26)
text(d,'These slopes replace the previous horizontal lip undersides, flat snap roofs and rounded valve roof.',1100,1280,25)
text(d,'No supports are modeled. These are geometric design checks, not a slicer or print guarantee.',1100,1340,26)
im.save(OUT/'Support_Conscious_Retention_And_Valve_Details.png')

im=Image.new('RGB',(2400,1460),'#f9f9f9')
for i,(name,view) in enumerate([('Rigid_BL',[.3,-.5,1.2]),('Upper_stopper_TPU_liner',[.4,-1,.8]),('Upper_Voltra_side_pad_1',[.2,-.5,1.8])]):
    pic,_=render(name+'.npz',view,800,1010);im.paste(pic,(i*800,215))
d=ImageDraw.Draw(im)
text(d,'Required print orientations',1200,25,46)
text(d,'Rigid sections: bottom-down',400,150,29)
text(d,'TPU cups: floor-down, upright',1200,150,29)
text(d,'TPU pads: contact face on bed',2000,150,28)
text(d,'Pads print flat, only 2.5 mm tall; their rear flex grooves open upward.',1200,1275,29)
text(d,'Use the specified orientation when assessing support requirements. Layer height and material still matter.',1200,1340,27)
text(d,'Review CAD only: retention fit, local strength and printer-specific slicing remain to verify.',1200,1400,26)
im.save(OUT/'Required_Print_Orientations.png')
print('Rendered complete assembly, revised features and print orientations')
