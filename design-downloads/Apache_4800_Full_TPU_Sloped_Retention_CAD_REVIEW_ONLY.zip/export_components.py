from pathlib import Path
import os
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-support-cache')
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review'
for folder in ['Component_STEP','Print_Orientation_STEP']:(OUT/folder).mkdir(exist_ok=True)
sources=list(OUT.glob('rigid_*.brep'))+list(OUT.glob('TPU_*.brep'))
assert len(sources)==18
for path in sources:
    p=cq.Shape.importBrep(str(path))
    cq.exporters.export(p,str(OUT/'Component_STEP'/(path.stem+'.step')))
for path in OUT.glob('PRINT_ORIENTATION_*.brep'):
    p=cq.Shape.importBrep(str(path))
    # The generic unmeshed box can overestimate trimmed spline surfaces.
    # AddOptimal computes the trimmed geometry bounds instead.
    b=Bnd_Box();BRepBndLib.AddOptimal_s(p.wrapped,b,False,False)
    xmin,ymin,zmin,xmax,ymax,zmax=b.Get()
    assert abs(zmin)<1e-5
    assert xmax-xmin+10<=256 and ymax-ymin+10<=256
    cq.exporters.export(p,str(OUT/'Print_Orientation_STEP'/(path.stem.removeprefix('PRINT_ORIENTATION_')+'.step')))
assert len(list((OUT/'Print_Orientation_STEP').glob('*.step')))==18
print('Exported18 assembly-coordinate and18 print-oriented component STEP files')
