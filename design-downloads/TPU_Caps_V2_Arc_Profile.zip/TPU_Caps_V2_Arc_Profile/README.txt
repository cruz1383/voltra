VOLTRA TPU PRESS CAPS V2 — DISTINCT HEXALOBULAR ARC PROFILE
Supersedes earlier shallow sinusoidal cap profile. Millimetres.

CORRECTION
The earlier r=1.78+0.09*cos(6theta) profile reproduces3.74 opposing tips and3.38 opposing valleys, but its valleys are too shallow to resemble the kit's clearly lobed stem. V2 replaces that profile with12 mathematically tangent circular arcs:6 convex lobes and6 concave valleys. These are exact circular arcs in STEP, finely tessellated in STL. No tip taper or tip fillet was added to blur the lobes.

REFERENCE AND LIMITS
Reference dimensions are the T20 RECESS row A3.95,B2.85,convex radius0.307 from bd_warehouse's ISO10664 parameter table. Its proportions and tangent-circle construction were scaled to the desired plug tip diameter. This is a T20-reference hexalobular cosmetic plug, NOT a certified standard T20 driver, tolerance gauge, or exact reverse-engineered copy of the kit cap. Recess dimensions are not a driver manufacturing specification. Source links appear inSOURCES.md.
The old3.38 valley span is intentionally replaced, not preserved. It is inconsistent with the deeper T20-reference proportions at3.74 tips. Keeping it would keep the shallow definition the user rejected. An oblique photo and two caliper spans cannot uniquely recover the kit's exact profile; physical retention remains a trial.

VARIANTS (choose one)
Baseline_3p74: opposing tips3.740; opposing valleys2.69848.
Tighter_3p79: opposing tips3.790; opposing valleys2.73456.
Tighter_3p84: opposing tips3.840; opposing valleys2.77063.
Tighter variants uniformly scale only the stem section, maintaining arc proportions. Names specify overall tip span, not radius or per-side increase.
Head on all variants:10.22 diameter x2.43 thick.
Stem on all variants:6.30 from head underside; total height8.73.
Head and stem lengths retained. Head outer face is atZ0 on the print bed, stem points up. Each is a single piece. STEP and STL included for each variant.

FIT TRIAL
Start with baseline; use the tighter variants only if retention is insufficient. Cosmetic retention plug, not a driver. Desired thumb-pressure retention is the objective, not verified performance. The deeper valleys remove material from V1 and can change compliance/contact even with the same tip span. Judge fit using the actual screw and TPU; do not infer retention from CAD alone. Stop if the cap needs excessive force.
Original measured cover-surface-to-recess-bottom depth6.51–6.81 gives only0.21–0.51 nominal axial margin for6.30 stem. Verify full seating without bottoming. Print distortion and actual screw position can consume that margin.

PRINTING
Use an appropriate TPU profile for Creality CR-TPU black; Shore hardness is unknown. Dry filament according to its own instructions. All PRINT_ files have the circular head down and stem up; no supports expected. For the X1 Carbon with a standard0.4 nozzle,0.12–0.16 layers and a calibrated slow TPU profile are reasonable trials. Keep speeds/flow low enough to retain these small details and allow each stem to cool. A calibrated narrower outer line (for example0.35mm with0.4 nozzle, if your profile supports it) may help tiny lobes, but should be checked in sliced toolpaths. Do not assume a0.4 nozzle reproduces every small-radius feature perfectly. Print several separated caps if needed for cooling; inspect for stringing and molten/rounded tips.
Layer height affects vertical texture; the corrected lobes come from the new XY profile. If definition is still lost, share the TPU Bambu Studio project so extrusion widths, seam, volumetric flow and cooling can be inspected rather than rounding the CAD further.

PROOF AND VALIDATION
Profile_Comparison.png compares old and new at equal scale and overlays the3.74 tip spans. Baseline_Profile_Proof.svg is a sampled display proof; STEP retains exact arcs. Build source included.
All3 parts: valid single solids, correct8.73 height andZ0 bed placement. Profile has12 circular arcs, external tangent-circle distances verified analytically, sampled tip/valley extrema checked. All STLs watertight, consistent winding and positive volume. Source/output validation reports included.
Physical fit, printed detail, thumb pressure and retention UNTESTED.
