from pathlib import Path
import math,json,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import cadquery as c
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path('/workspace/designs/output/TPU_Caps_V2_Arc_Profile');O.mkdir(exist_ok=True)
# Reference dimensions: bd_warehouse iso10664def.csv T20 RECESS row.
# Scale reference proportions to user's measured plug tip span; not a certified driver.
A0,B0,R0=3.95,2.85,.307
report={};profiles={}
def vec(a):return c.Vector(float(a[0]),float(a[1]),0)
def unit(theta):return np.array([math.cos(theta),math.sin(theta)])
for label,A in [('Baseline_3p74',3.74),('Tighter_3p79',3.79),('Tighter_3p84',3.84)]:
 scale=A/A0;B=B0*scale;Re=R0*scale;h=A/2-Re;b=B/2;co=math.cos(math.pi/6)
 # External tangency: |(b+Ri)u30 - h*u0| = Ri+Re.
 Ri=(Re*Re-b*b-h*h+2*h*b*co)/(2*b-2*h*co-2*Re)
 assert Ri>0 and Re>0
 centers=[h*unit(k*math.pi/3) for k in range(6)]
 valleys=[(b+Ri)*unit(k*math.pi/3+math.pi/6) for k in range(6)]
 P=[];Q=[]
 for k in range(6):
  C=centers[k];D=valleys[k];Cnext=centers[(k+1)%6]
  assert abs(np.linalg.norm(D-C)-(Ri+Re))<1e-9
  p=C+Re*(D-C)/(Re+Ri);q=Cnext+Re*(D-Cnext)/(Re+Ri)
  P.append(p);Q.append(q)
 edges=[];sampled=[]
 def sample_arc(center,start,middle,end,n=60):
  a=math.atan2(*(start-center)[::-1]);m=math.atan2(*(middle-center)[::-1]);e=math.atan2(*(end-center)[::-1])
  total=(e-a)%(2*math.pi);mid=(m-a)%(2*math.pi)
  if mid>total:total-=2*math.pi
  rr=np.linalg.norm(start-center)
  return [center+rr*unit(t) for t in np.linspace(a,a+total,n,endpoint=False)]
 for k in range(6):
  tip=A/2*unit(k*math.pi/3);valley=b*unit(k*math.pi/3+math.pi/6)
  edges.append(c.Edge.makeThreePointArc(vec(Q[(k-1)%6]),vec(tip),vec(P[k])))
  edges.append(c.Edge.makeThreePointArc(vec(P[k]),vec(valley),vec(Q[k])))
  sampled+=sample_arc(centers[k],Q[(k-1)%6],tip,P[k])
  sampled+=sample_arc(valleys[k],P[k],valley,Q[k])
 wire=c.Wire.assembleEdges(edges);assert wire.IsClosed() and wire.isValid()
 assert len(wire.Edges())==12 and all(e.geomType()=='CIRCLE' for e in wire.Edges())
 face=c.Face.makeFromWires(wire);assert face.isValid()
 stem=c.Solid.extrudeLinear(wire,[],c.Vector(0,0,6.30)).translate((0,0,2.43))
 head=c.Solid.makeCylinder(10.22/2,2.43)
 part=head.fuse(stem).clean();assert part.isValid() and len(part.Solids())==1
 bb=part.BoundingBox();assert abs(bb.zmin)<1e-7 and abs(bb.zmax-8.73)<1e-7
 radii=np.linalg.norm(np.array(sampled),axis=1)
 assert abs(radii.max()-A/2)<.0001 and abs(radii.min()-B/2)<.0001
 name='TPU_Cap_V2_'+label
 c.exporters.export(part,str(O/(name+'.step')))
 assert part.exportStl(str(O/('PRINT_'+name+'.stl')),tolerance=.002,angularTolerance=.035,relative=False)
 profiles[label]=np.array(sampled)
 report[label]={'valid':True,'solids':1,'tip_diameter_mm':A,'valley_diameter_mm':B,'convex_lobe_radius_mm':Re,'concave_valley_radius_mm':Ri,'exact_circular_arcs_in_section':12,'tangent_arc_junctions':12,'head_diameter_mm':10.22,'head_thickness_mm':2.43,'stem_from_head_underside_mm':6.30,'total_height_mm':8.73,'volume_mm3':part.Volume(),'on_bed':True,'reference':'ISO10664 recess proportions from bd_warehouse T20 row,scaled to plug dimensions;not a certified driver or exact kit reproduction','physical_fit':'UNTESTED'}
 print(label,'12 tangent circular arcs;valid solid; exported',flush=True)
# Cross-section proof: same physical scale and preserved3.74 tip span.
a=np.linspace(0,2*math.pi,1200);r=1.78+.09*np.cos(6*a);old=np.column_stack([r*np.cos(a),r*np.sin(a)])
new=profiles['Baseline_3p74']
fig,axes=plt.subplots(1,3,figsize=(12,4.7))
for ax,pts,title,col in [(axes[0],old,'Previous V1: shallow six-wave profile','#c16a55'),(axes[1],new,'V2: tangent circular-arc profile','#207c99')]:
 ax.fill(pts[:,0],pts[:,1],color=col,alpha=.8);ax.set_title(title,fontsize=11)
axes[2].plot(*np.vstack([old,old[0]]).T,color='#c16a55',label='V1');axes[2].plot(*np.vstack([new,new[0]]).T,color='#207c99',label='V2');axes[2].set_title('Overlay — same3.74mm tip span',fontsize=11);axes[2].legend()
for ax in axes:
 ax.set_xlim(-2.1,2.1);ax.set_ylim(-2.1,2.1);ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('mm');ax.set_ylabel('mm')
axes[0].text(0,-2.7,'Tips3.74mm / valleys3.38mm',ha='center',fontsize=10);axes[1].text(0,-2.7,f'Tips3.74mm / valleys{B0*3.74/A0:.3f}mm',ha='center',fontsize=10)
fig.suptitle('Voltra TPU cap — cross-section correction (not a certified T20 driver)',fontsize=13);fig.tight_layout(rect=[0,.03,1,.94]);fig.savefig(O/'Profile_Comparison.png',dpi=160)
# Flat standalone SVG proof; exact analytic arc edges retained in STEP.
pts=new;d='M '+' L '.join(f'{x:.6f},{-y:.6f}' for x,y in pts)+' Z'
(O/'Baseline_Profile_Proof.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="60mm" height="60mm" viewBox="-2.1 -2.1 4.2 4.2"><rect x="-2.1" y="-2.1" width="4.2" height="4.2" fill="white"/><path d="{d}" fill="#207c99"/></svg>')
(O/'CAD_validation.json').write_text(json.dumps(report,indent=2))
