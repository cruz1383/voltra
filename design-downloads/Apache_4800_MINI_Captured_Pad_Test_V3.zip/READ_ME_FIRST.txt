MINI CAPTURED TPU PAD TEST — PRINT ONLY TWO PIECES

PRINT_MINI_RIGID_Holder_Flat.stl: approximately36 x25 x7.65mm in its
supplied flat-on-back print orientation. Print once in your rigid filament.
PRINT_MINI_TPU_Pad_Flat.stl: approximately28 x18.7 x3.65mm. Print once in
your TPU, on its flat contact face as supplied.

No full-height parts, extra fit variants or external stabilizing feet.
Import as millimeters at100%. Preserve supplied flat orientations.

WHAT THIS TESTS
Same dovetail bevel,3.65mm TPU thickness,1.5mm protrusion,+0.15mm profile
allowance,45degree top stop and0.3mm top clearance as the proposed V3.
Only width and height have been reduced for a quick functionality test.
There are fixed top and bottom stops; no thin hooks or separate keeper.
Flex the TPU into the captured opening, seat both ends under the stops,
and ensure the dovetail sides are engaged. Check insertion, deliberate
removal, protrusion/feel and resistance to rubbing/pulling upward, as
would occur when the sleeved Voltra is removed.

Both parts passed valid-single-solid CAD checks, zero seated overlap,
rigid-body capture checks and watertight / winding / volume / bed checks
on their exported STLs. The geometric46degree overhang audit passed in
the supplied flat orientations. No slicer or physical print is claimed.

The small coupon checks the mechanism economically; it cannot establish
full-pad bending stiffness, wear or final holding force. Full insert and
older testers have not been changed. No need to print those for this test.
The reference STEP is an assembly for viewing, not a merged print file.
