from pathlib import Path
from collections import Counter
import os,json,struct,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-mini-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'release';OUT.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def prism_yz(points):
    v=[cq.Vector(-20,y,z) for y,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(v+[v[0]]),[],cq.Vector(40,0,0))
points=[(-12,0),(12,0),(12,1.15),(14,3.65),(-14,3.65),(-12,1.15)]
def profile():return cq.Workplane('XY').polyline(points).close()
channel=profile().offset2D(.15).extrude(22.2).val().translate((0,0,3))
roof=prism_yz([(-.5,3),(9.5,3),(9.5,14),(1.5,22),(-.5,22)])
holder=box(-18,1.5,0,36,7.65,25).cut(channel.intersect(roof))
pad=profile().extrude(22).val().translate((0,0,3))
limit=prism_yz([(-.5,3),(9.5,3),(9.5,13.7),(1.5,21.7),(-.5,21.7)])
pad=pad.intersect(limit)
for x in [-6,0,6]:pad=pad.cut(box(x-1.5,1.2,6,3,2.45,10))
for p in [holder,pad]:assert p.isValid() and len(p.Solids())==1
assert holder.intersect(pad).Volume()<1e-5
assert holder.intersect(pad.translate((0,0,.2))).Volume()<1e-5
assert holder.intersect(pad.translate((0,0,.6))).Volume()>1e-5
assert holder.intersect(pad.translate((0,0,-.5))).Volume()>1e-5
assert holder.intersect(pad.translate((0,-1,0))).Volume()>1e-5
# Exactly two print files, both laid flat as requested. No support feet.
shapes={'PRINT_MINI_RIGID_Holder_Flat.stl':holder.rotate((0,0,0),(1,0,0),-90).translate((18,0,9.15)),
        'PRINT_MINI_TPU_Pad_Flat.stl':pad.rotate((0,0,0),(1,0,0),90).translate((14,21.7,0))}
dtype=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')])
report={}
for name,p in shapes.items():
    assert p.exportStl(str(OUT/name),tolerance=.015,angularTolerance=.05,relative=False)
    data=(OUT/name).read_bytes();n=struct.unpack_from('<I',data,80)[0]
    assert len(data)==84+50*n and n>0
    a=np.frombuffer(data,dtype=dtype,offset=84,count=n)['points'].astype(float)
    assert np.isfinite(a).all()
    ids={};edges=Counter();orientation=Counter()
    for tri in a:
        vi=[ids.setdefault(tuple(np.round(v,5)),len(ids)) for v in tri]
        assert len(set(vi))==3
        for u,v in zip(vi,vi[1:]+vi[:1]):
            key=tuple(sorted((u,v)));edges[key]+=1;orientation[key]+=1 if u<v else -1
    assert all(x==2 for x in edges.values()) and all(x==0 for x in orientation.values())
    volume=np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6
    assert volume>0
    norm=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(norm,axis=1)/2
    assert (area>1e-10).all()
    norm/=2*area[:,None];bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
    bad=(norm[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
    assert not bad.any(),name
    assert abs(a[:,:,2].min())<1e-5
    report[name]={'triangles':n,'watertight':True,'consistent_winding':True,
        'volume_mm3':float(volume),'print_bounds_mm':np.ptp(a.reshape(-1,3),axis=0).tolist(),
        'on_bed':True,'overhang_check_passed':True,'slicer_verified':False,'physical_fit_verified':False}
assembly=cq.Assembly(name='MINI_FLEX_IN_CAPTURED_PAD_TEST')
assembly.add(holder,name='Rigid_holder',color=cq.Color(.56,.63,.67))
assembly.add(pad,name='TPU_pad',color=cq.Color(1,.52,.12))
assembly.save(str(OUT/'REFERENCE_Mini_Assembly.step'))
(OUT/'validation.json').write_text(json.dumps({'mesh_checks':report,
 'rigid_holder_assembled_mm':[36,7.65,25],'TPU_front_contact_width_mm':24,
 'TPU_rear_width_mm':28,'TPU_front_height_mm':18.7,'TPU_thickness_mm':3.65,
 'protrusion_mm':1.5,'profile_offset_mm':.15,'top_roof_angle_deg':45,
 'top_vertical_clearance_mm':.3,'fixed_top_and_bottom_stops':True,
 'seated_interference_mm3':0,'up_down_and_normal_capture_tests_passed':True,
 'scope':'Small mechanism tester only; previous full-size files unchanged',
 'limitation':'Preserves retention cross-section, not full-pad flex stiffness or holding force.'},indent=2))
print(json.dumps(report,indent=2))
