RACK JIG V2.1 — REPLACES V2 HALVES AND CLIP TOGETHER
Units: mm. FIT PROTOTYPE, physical fit untested.

CORRECTION
The V2 tongue extended from Z2 toZ10 while the main plate ended atZ8. That extension was on the outward/front face, not the steel-contact face, but it prevented the broad plate face from lying on the bed in the supplied print orientation. The V2 clip also extended outward toZ12.2. Earlier chat wording incorrectly described the outward projection as a steel-side projection.
V2.1 tongue now spansZ2..6. Clip spansZ0.2..7.8. Main plate remainsZ0..8. Neither tongue nor clip crosses the rack-facingZ0 plane or protrudes beyond the outwardZ8 face. Both halve STLs now place the broad front face directly on the bed (approx3508.54mm2 contact per half), with the rack-side boss and cheeks pointing upward.
Use all three V2.1 files together. The V2 clip does NOT fit the revised tongue correctly. Old V1/V2 files are superseded.

STEEL CONTACT
Rack-facing reference plane isZ0. Main plate contacts steel directly. Boss extends2.5 into the existing16.86 hole; cheeks extend15 along sides, outside the75.58 upright width. Magnet pockets open toward steel. Clip rear face is0.2 forward of steel, giving positive nominal clearance. Full upright box including existing hole has zero CAD intersection with each assembled part. A physical fit trial is still required, especially magnet/tape protrusion and available drill clearance.

UNCHANGED FIT DIMENSIONS
Upright75.58; contact-pad span76.08, nominal0.25 per side. Cheek depth15. Corner-relief span80.08 over first10 depth; contact pads at10..15 depth, beyond measured8.85 corner reach.
Boss16.75 diameter x2.5 projection; existing hole16.86.
New center49.53 above original hole, X=0 centered across upright.
Cutter opening16.175 around nominal15.875 cutter.
Seam pegs4.40 diameter x4 engagement; sockets4.64 x4.30.
Tapered tongue width24..26 over10 height; revised thickness4. Clip cavity has0.2 nominal rear/front clearance and approximately0.24..0.30 total transverse clearance. Roof/back walls are1.6 thick. Retention and strength not physically tested; this is a close-clearance sliding cap, not a guaranteed preloaded clamp.
Magnet pockets20.40 diameter x4.45 depth for magnets20.01x3.04 plus supplied pads20.03xapproximately1.29 with liners. The liner-free stack and compression are unknown. Dry-fit stack so magnets do not protrude or make the jig rock; adhesive thickness may need adjustment.

REMOVAL
Cutter remains stationary. Pull clip downward until free (25 travel sampled). Keeping halves joined, pull forward at least15.5 to clear15-deep cheeks. Then separate sideways to disengage seam pins and clear cutter. CAD sampling checks zero cutter intersection through forward travel15.5 and sideways50 per half around an ideal15.875 cylinder. Actual flutes, pilot, shank shoulders, housing, mag base footprint and available travel are not supplied or modeled. Verify stationary removal physically. REMOVE BEFORE CUTTER ROTATION. Mag base sits directly on steel; jig is not a bearing or drill restraint.

PRINT
PRINT_ files are already on bed. Halves: broad outward plate face down; boss and cheeks upward. The recessed tongue starts2 above the bed and needs LOCAL SUPPORT UNDER THAT TAB. Inspect and support seam pegs as needed. Do not auto-drop the part onto the tongue or rotate onto the rack side. Main plate must show a broad first-layer footprint. Clip remains printed on its upper edge; inspect channel/bridging in slicer and add local support if required.
Starting trial0.16–0.20 layers,4walls,25–35% infill. Calibrate printer dimensional compensation. Do not infer required clip pressure or final locating fit from CAD clearances alone.

VALIDATION
All3 CAD parts valid single solids. No assembled mutual penetration. All3 parts clear upright material in assembled position. Forward/sideways and clip-down removal checks pass at sampled positions. All3 STL meshes checked watertight with consistent winding and positive volume, and Z=0 bed placement. Explicit broad-face bed contact check added, rather than relying only on minimumZ=0.
Geometry validated. Printing, flush steel seating, clip retention, magnet retention and physical fit remain UNTESTED.
