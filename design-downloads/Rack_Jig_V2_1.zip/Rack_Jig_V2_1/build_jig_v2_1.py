import cadquery as c, math, json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
OUT=Path('/workspace/designs/output'); J=OUT/'Rack_Jig_V2_1'; T=OUT/'TPU_Caps'
J.mkdir(exist_ok=True);T.mkdir(exist_ok=True)
def box(x,y,z,dx,dy,dz):return c.Solid.makeBox(dx,dy,dz,c.Vector(x,y,z))
def cyl(r,h,x,y,z,axis=(0,0,1)):return c.Solid.makeCylinder(r,h,c.Vector(x,y,z),c.Vector(*axis))
def poly(points,z,h):return c.Workplane('XY').polyline(points).close().extrude(h).val().translate((0,0,z))
def export(s,path,print_shape=None):
 assert s.isValid() and len(s.Solids())==1,str(path)
 c.exporters.export(s,str(path.with_suffix('.step')))
 q=print_shape if print_shape is not None else s
 b=q.BoundingBox();q=q.translate((-b.xmin,-b.ymin,-b.zmin))
 c.exporters.export(q,str(path.parent/('PRINT_'+path.name+'.stl')),tolerance=.015,angularTolerance=.08)
 return {'valid':s.isValid(),'solids':len(s.Solids()),'volume_mm3':s.Volume()}
# Coordinates: X across upright, Y up, Z outward from steel front.
b=box(-44.04,-14,0,88.08,82,8)
b=b.fuse(poly([(-12,-24),(12,-24),(13,-14),(-13,-14)],2,4))
b=b.fuse(cyl(16.75/2,2.5,0,0,-2.5)).cut(cyl(16.175/2,12,0,49.53,-1))
for x in [-25,25]:b=b.cut(cyl(10.2,4.45,x,25,0))
# Corner relief: 80.08 span for first 10mm; pads give 76.08 span at 10..15mm.
for sign in [-1,1]:
 x=40.04 if sign==1 else -44.04
 pad=38.04 if sign==1 else -40.04
 b=b.fuse(box(x,5,-15,4,48,15)).fuse(box(pad,5,-15,2,48,5))
left=b.intersect(box(-70,-40,-20,70,120,40))
right=b.intersect(box(0,-40,-20,70,120,40))
for y in [15,61]:
 left=left.fuse(cyl(2.2,4,0,y,4,(1,0,0)))
 right=right.cut(cyl(2.32,4.3,0,y,4,(1,0,0)))
# Downward removable tapered cap; rear surface stays outside steel (Z >= 0).
clip=poly([(-15,-27),(15,-27),(16.15,-14),(-16.15,-14)],.2,7.6)
clip=clip.cut(poly([(-12.12,-24.2),(12.12,-24.2),(13.17,-13.8),(-13.17,-13.8)],1.8,4.4))
clip=clip.fuse(box(-7,-34,.2,14,7,7.6))
parts={'Left':left.clean(),'Right':right.clean(),'Bottom_Clip':clip.clean()}
report={}
for name,s in parts.items():
 assert s.BoundingBox().zmax<=8.000001,(name,'projects beyond front plane')
 if name=='Bottom_Clip':assert s.BoundingBox().zmin>=.199999
# Body must genuinely contact the bed on its broad front face, not merely its lowest feature.
for name,s in [('Left',left),('Right',right)]:
 contact=s.intersect(box(-100,-100,7.999,200,200,.001)).Volume()/.001
 assert contact>3000,(name,contact)
 report[name+'_front_bed_contact_mm2']=contact
for name,s in parts.items():
 q=s.rotate((0,0,0),(1,0,0),180) if name!='Bottom_Clip' else s.rotate((0,0,0),(1,0,0),90)
 report[name]=export(s,J/('Rack_Jig_V2_1_'+name),q)
assembly=c.Compound.makeCompound(list(parts.values()));c.exporters.export(assembly,str(J/'Assembly_Preview.step'))
# Interference checks and ideal-cylinder removal sweep. Real drill body is not supplied.
for a,bn in [('Left','Right'),('Left','Bottom_Clip'),('Right','Bottom_Clip')]:
 overlap=parts[a].intersect(parts[bn]).Volume();assert overlap<1e-6,(a,bn,overlap)
steel=box(-75.58/2,-60,-40,75.58,180,40).cut(cyl(16.86/2,45,0,0,-40))
cutter=cyl(15.875/2,100,0,49.53,-30)
assert all(s.intersect(steel).Volume()<1e-6 for s in parts.values())
for z in [0,2.5,5,10,15,15.5]:
 for s in [left,right]:assert s.translate((0,0,z)).intersect(cutter).Volume()<1e-6
for dx in [0,.1,.5,1,2,4,8,12,20,30,50]:
 for s,sign in [(left,-1),(right,1)]:
  q=s.translate((sign*dx,0,15.5));assert q.intersect(cutter).Volume()<1e-6
  assert q.intersect(steel).Volume()<1e-6
for dy in [0,-.1,-1,-3,-6,-10,-15,-25]:
 q=clip.translate((0,dy,0))
 for s in [left,right]:assert q.intersect(s).Volume()<1e-6
report['removal']='Sampled forward 15.5mm, then each half sideways 50mm around ideal stationary 15.875mm cylinder; clip downward 25mm; zero interference. Actual cutter shoulders, pilot, drill housing and available travel unverified.'
fig=plt.figure(figsize=(10,9));ax=fig.add_subplot(projection='3d')
for s,col in zip(parts.values(),['#58b5d0','#e9b74f','#728599']):
 v,f=s.tessellate(.15);ax.add_collection3d(Poly3DCollection([[(v[i].x,v[i].y,v[i].z) for i in t] for t in f],facecolor=col,edgecolor='none'))
ax.set_xlim(-50,50);ax.set_ylim(-38,73);ax.set_zlim(-18,15);ax.set_box_aspect((100,111,33));ax.view_init(57,-65);ax.set_axis_off();fig.suptitle('Rack jig V2.1 — split halves and downward-release clip');fig.savefig(J/'Assembly_Preview.png',dpi=180);plt.close(fig)

report['front_plane_max_z_mm']=8
report['tongue_z_interval_mm']=[2,6]
report['clip_z_interval_mm']=[.2,7.8]
report['steel_contact']='No plate/tongue/clip penetration into upright; indexing boss occupies measured hole; cheeks remain outside sides.'
(J/'CAD_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
