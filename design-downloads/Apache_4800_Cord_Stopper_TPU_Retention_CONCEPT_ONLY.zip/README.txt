CORD STOPPER — TPU LINER RETENTION DETAIL (REVIEW ONLY)

The removable rounded TPU cup has a flush locating lip and two flexible
wall snaps, matching the accessory-retention approach discussed. There is
no finger-relief notch. The stopper remains retrievable by its own loop.
The snaps retain the TPU liner, not the stopper. They do not clamp the
stopper or establish its steadiness inside the liner.

Actual cavity62.97 x43.27mm, matching the established main cradle opening.
Measured stopper length61.08mm gives1.89mm total nominal length allowance.
Sides1.5mm, floor mat2mm. Original rigid floorZ55; TPU contact floorZ57.
Lip is recessed to sit flush atZ100. Two snap shoulders atZ96 engage
receiving ledges atZ96.3. The rigid seat has an illustrative0.2mm offset.

Orange is TPU; gray is a representative rigid support coupon. The STEP is
a real separate CAD detail, NOT integrated into the complete Apache insert.
The support shown is not one of the four production sections; full joint
and seam integration still needs engineering. Other accepted concepts
(hook-free Voltra dovetails, enlarged pin channels and valve relief) are
unchanged and remain separate downloads.

Two valid single CAD solids; no seated overlap. A modeled1mm lift catches
the snap shoulders. These are rigid-body geometric checks, not a simulation
of TPU deformation. Insertion / release force, allowable strain, print
tolerances, wear, access and actual stopper fit require a physical sample.
Flex the liner walls inward to disengage the snaps before lifting out.
No printable STL or force/drop rating is supplied at this concept stage.

Files: colored STEP, two PNG renders, validation.json, source and hashes.
Images are rendered from actual CAD geometry. No stopper replica is
invented from the single length measurement.
Python dependencies: CadQuery2.6.1, NumPy, Pillow, Matplotlib.
