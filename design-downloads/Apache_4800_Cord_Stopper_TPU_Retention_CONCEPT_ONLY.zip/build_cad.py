"""Actual-size cord-stopper TPU liner retention detail, review only."""
from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-stopper-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,z,h):return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,0,z))
def prism_yz(points,x,length):
    vs=[cq.Vector(x,y,z) for y,z in points]
    wire=cq.Wire.makePolygon(vs+[vs[0]])
    return cq.Solid.extrudeLinear(wire,[],cq.Vector(length,0,0))
# Keep established capsule opening and2mm floor mat. Real stopper is not
# modeled from a guessed shape; it remains a measured length reference.
L,W,R=62.97,43.27,21.625
cup=rr(L+3,W+3,R+1.5,55,45).cut(rr(L,W,R,57,44))
# Locating flange sits in a shallow top counterbore: top remainsZ100.
lip=rr(L+5,W+5,R+2.5,99,1).cut(rr(L,W,R,98.9,1.2))
cup=cup.fuse(lip)
# The short straight flats at the sides admit narrow flexible tongues.
# Two mirrored snaps capture the LINER, not the cord stopper.
outer_y=W/2+1.5
for side in [1,-1]:
    for x in [-3.3,2.7]:
        cup=cup.cut(box(x,outer_y-1.6 if side>0 else -outer_y-.1,86,.6,1.8,12))
    hook=prism_yz([(outer_y,91),(outer_y+1,94),(outer_y+1,96),(outer_y,96)],-2.7,5.4)
    if side<0:hook=hook.mirror('XZ')
    cup=cup.fuse(hook)
support=rr(L+15,W+15,R+7.5,50,50)
support=support.cut(rr(L+3.4,W+3.4,R+1.7,55,46))
support=support.cut(rr(L+5.4,W+5.4,R+2.7,98.8,2))
for side in [1,-1]:
    support=support.cut(box(-3.6,outer_y+.1 if side>0 else -outer_y-1.4,90,7.2,1.3,6.3))
assert cup.isValid() and len(cup.Solids())==1
assert support.isValid() and len(support.Solids())==1
assert cup.intersect(support).Volume()<1e-5
assert cup.translate((0,0,1)).intersect(support).Volume()>0
assembly=cq.Assembly(name='CORD_STOPPER_TPU_LINER_RETENTION_DETAIL')
assembly.add(support,name='Rigid_stopper_cradle_reference_support',color=cq.Color(.56,.63,.67))
assembly.add(cup,name='TPU_cup_with_flush_lip_and_wall_snaps',color=cq.Color(1,.52,.12))
assembly.save(str(OUT/'Cord_Stopper_TPU_Liner_Retention_CONCEPT_ONLY.step'))
def arrays(name,shapes):
    result={}
    for label,p in shapes.items():
        v,f=p.tessellate(.025,.08)
        result[label]=np.array([q.toTuple() for q in v])[np.array(f)]
    np.savez_compressed(OUT/(name+'.npz'),**result)
arrays('assembled',{'rigid':support,'TPU':cup})
arrays('exploded',{'rigid':support,'TPU':cup.translate((0,0,55))})
# Front half retained; X0 cut face exposes one complete snap tongue.
half=box(0,-40,49,45,80,60)
arrays('cutaway',{'rigid':support.intersect(half),'TPU':cup.intersect(half)})
detail=box(-.1,outer_y-3,84,9,9,17)
arrays('snap_detail',{'rigid':support.intersect(detail),'TPU':cup.intersect(detail)})
(OUT/'validation.json').write_text(json.dumps({
 'stage':'Separate stopper-liner retention detail; not integrated into full insert',
 'valid_single_solid_components':2,'seated_overlap_mm3':0,
 'cavity_length_width_mm':[L,W],'measured_stopper_length_mm':61.08,
 'nominal_total_length_clearance_mm':1.89,
 'side_liner_thickness_mm':1.5,'floor_mat_thickness_mm':2,
 'original_rigid_floor_z_mm':55,'TPU_floor_surface_z_mm':57,
 'flush_locating_lip_top_z_mm':100,'finger_relief_present':False,
 'wall_snap_count':2,'nominal_profile_offset_for_rigid_seat_mm':.2,
 'receiver_roof_z_mm':96.3,'TPU_snap_shoulder_z_mm':96,
 'one_mm_lift_catches_receiving_shoulders':True,
 'retains':'TPU cup; not a positive latch on the stopper',
 'pending':['TPU strain, insertion and release force','Printed fit and wear',
 'Release access with stopper in place','Full-insert joint / seam integration',
 'Actual stopper steadiness and lid packing'],
 'note':'The measured stopper is not reconstructed or shown as an invented 3D replica.'},indent=2))
print('Saved valid stopper retention CAD; no seated overlap; snap shoulders catch1mm lift')
