RACK-HOLE LOCATOR V2 — FIT PROTOTYPE; MILLIMETRES
Purpose: position a stationary 5/8-inch annular cutter. Remove the entire jig before rotation. Mag-drill base contacts steel directly; this jig is not a drill restraint or bearing.

Changes from supplied V1:
- Upright measured width 75.58; contact-pad inside span 76.08: deliberate 0.50 total / 0.25 per-side nominal clearance. Printed fit is untested.
- Cheeks extend 15 behind front face. First 10 depth has 80.08 inside span for corner relief; side-contact pads occupy depths 10–15 at 76.08 span. Measured corner reach 8.85 leaves 1.15 nominal depth margin to pads.
- Locating boss diameter 16.75, projection 2.50, split across seam. Existing hole 16.86 gives 0.11 nominal diametral clearance. Previous print undersizing is not assumed repeatable.
- Target center X=0, Y=49.53 above old hole. Cutter opening diameter 16.175 gives 0.30 diametral nominal clearance around 15.875 cutter.
- Two seam pegs diameter 4.40, engagement 4.00; sockets diameter 4.64, depth 4.30. Deliberate 0.24 diametral / 0.30 axial clearance.
- Bottom tongue tapers from width24 to26 over10 height. Downward-removable cap has roughly0.24–0.30 total transverse clearance and0.20 face clearances. Taper releases progressively downward. Larger cap walls and full front/back capture resist seam opening and forward shifting. This is a close-clearance slide fit, not a guaranteed preload or calibrated snap fit; retention must be tried physically. No force should be required to seat it.
- Clip rear remains at Z=0 (steel surface), avoiding V1 clip's projection behind the rack contact plane.
- Magnet pockets diameter20.40, depth4.45, for magnets20.01x3.04 and pads20.03x~1.29 with liners. Nominal total4.33 leaves0.12 recess BEFORE liners are removed; real pad stack/compression remains unknown. Dry fit, measure liner-free stack, and use appropriate adhesive thickness so magnets neither protrude nor lose useful holding force. Pocket depth is fixed in these trials; adjust the source parameter for later fit trials if needed.

REMOVAL
1. With cutter stationary and fully supported by the drill, slide bottom clip down until free (25mm travel checked).
2. Keep halves joined; pull jig straight forward at least15.5mm to clear15mm cheeks and2.5mm boss.
3. Move halves sideways away from seam;4mm pegs disengage.50mm lateral travel per half checked around ideal cutter cylinder.
CAD tests: no assembled part penetration; no penetration with rectangular75.58-wide steel model including16.86 hole; sampled removal positions clear ideal15.875 cylindrical cutter. These checks do not model real flutes, pilot pin, shank shoulders, drill housing, steel coatings or nearby obstructions. Actual available forward/lateral travel and clearance need a stationary physical dry run. Small front-face plate footprint must also clear actual magnetic base; no base dimensions were supplied.

PRINT
Separate PRINT_ STL files are in bed orientation; STEP files retain assembly coordinates. Left/right fronts are on bed, rack-facing cheeks/boss point upward. Clip is on its top edge. Inspect seam pegs, elevated tongue and clip channel in slicer; local support or printer-specific bridging settings may be needed. Starting trial:0.16–0.20 layers,4walls,25–35% infill, dimensional compensation calibrated to your printer. Do not sand away the intended locator dimension without checking fit.

All CAD parts pass single-solid validity. All STLs pass watertight edge, winding, positive-volume and Z=0 bed checks. Geometry validated; printing, magnet retention, clip retention and physical fit UNTESTED.
