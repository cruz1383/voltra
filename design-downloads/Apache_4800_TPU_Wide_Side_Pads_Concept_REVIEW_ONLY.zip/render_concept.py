"""Render tessellated CAD using an orthographic CPU depth buffer."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/voltra-tpu-mpl')
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from matplotlib.font_manager import findfont
OUT=Path(__file__).resolve().parent/'review'
FONT=findfont('DejaVu Sans')
def text(d,s,x,y,size=30,anchor='mt',fill='#253d48'):
    d.text((x,y),s,font=ImageFont.truetype(FONT,size),fill=fill,anchor=anchor)
def render(file,view,width,height):
    arrays=np.load(OUT/file)
    triangles=[];base=[]
    for name in arrays.files:
        tri=arrays[name];triangles.append(tri)
        col=(1.,.52,.12) if name.startswith('TPU') else (.56,.63,.67)
        base.extend([col]*len(tri))
    a=np.concatenate(triangles);base=np.array(base)
    normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0])
    normal/=np.maximum(np.linalg.norm(normal,axis=1),1e-12)[:,None]
    view=np.array(view,dtype=float);view/=np.linalg.norm(view)
    right=np.cross([0,0,1],view)
    if np.linalg.norm(right)<1e-8:right=np.array([1.,0,0])
    right/=np.linalg.norm(right);up=np.cross(view,right)
    light=np.array([-.3,-.5,1.]);light/=np.linalg.norm(light)
    shade=.50+.50*np.maximum(normal@light,0)
    # Tonal distinction on recessed rigid floors makes bare carabiner slots
    # readable in the orthographic top view; this is not a material change.
    recessed=(np.max(np.abs(a[:,:,2]-65),axis=1)<1e-4)&(base[:,0]<.9)
    shade[recessed]*=.60
    rgb=np.clip(base*shade[:,None]*255,0,255).astype(np.uint8)
    proj=np.stack([a@right,a@up,a@view],axis=-1)
    lo=proj[:,:,:2].reshape(-1,2).min(axis=0)
    hi=proj[:,:,:2].reshape(-1,2).max(axis=0)
    scale=min((width-120)/(hi[0]-lo[0]),(height-100)/(hi[1]-lo[1]))
    center=(lo+hi)/2
    proj[:,:,0]=(proj[:,:,0]-center[0])*scale+width/2
    proj[:,:,1]=height/2-(proj[:,:,1]-center[1])*scale
    canvas=np.full((height,width,3),249,np.uint8)
    zb=np.full((height,width),-np.inf)
    for i,t in enumerate(proj):
        if normal[i]@view<=0:continue
        x0=max(0,int(np.floor(t[:,0].min())));x1=min(width-1,int(np.ceil(t[:,0].max())))
        y0=max(0,int(np.floor(t[:,1].min())));y1=min(height-1,int(np.ceil(t[:,1].max())))
        if x1<x0 or y1<y0:continue
        xs=np.arange(x0,x1+1)[None,:]+.5;ys=np.arange(y0,y1+1)[:,None]+.5
        den=(t[1,1]-t[2,1])*(t[0,0]-t[2,0])+(t[2,0]-t[1,0])*(t[0,1]-t[2,1])
        if abs(den)<1e-12:continue
        w0=((t[1,1]-t[2,1])*(xs-t[2,0])+(t[2,0]-t[1,0])*(ys-t[2,1]))/den
        w1=((t[2,1]-t[0,1])*(xs-t[2,0])+(t[0,0]-t[2,0])*(ys-t[2,1]))/den
        w2=1-w0-w1;depth=w0*t[0,2]+w1*t[1,2]+w2*t[2,2]
        local=zb[y0:y1+1,x0:x1+1]
        mask=(w0>=-1e-7)&(w1>=-1e-7)&(w2>=-1e-7)&(depth>local)
        local[mask]=depth[mask]
        canvas[y0:y1+1,x0:x1+1][mask]=rgb[i]
    def project(p):
        p=np.array(p)
        return ((p@right-center[0])*scale+width/2,
                height/2-(p@up-center[1])*scale)
    return Image.fromarray(canvas),project

im=Image.new('RGB',(2200,1600),'#f9f9f9')
pic,project=render('cad_triangles.npz',[.18,-.42,1.65],2200,1250)
im.paste(pic,(0,170));d=ImageDraw.Draw(im)
text(d,'Wider TPU side pads — Apache 4800 / Voltra',1100,32,43)
text(d,'Actual CAD geometry | Orange: TPU | Gray: rigid insert | Review model only',1100,100,29)
text(d,'Voltra side pads: 60 mm wide (previously 25 mm) | End pads unchanged',1100,1430,30)
text(d,'Chargers + stoppers: side liners and 2 mm mats | Carabiner slots: bare rigid walls',1100,1480,29)
text(d,'Valve relief retained. Pad retention, local wall thickness and print fit are not finalized.',1100,1535,27)
im.save(OUT/'TPU_Concept_Assembly.png')

im=Image.new('RGB',(2200,1640),'#f9f9f9')
pic,project=render('cad_triangles.npz',[0,0,1],1900,1300)
im.paste(pic,(150,160));d=ImageDraw.Draw(im)
text(d,'Wider side pads — 60 mm each',1100,30,45)
text(d,'Top view of actual concept CAD; openings remain visible for review',1100,95,30)
def callout(s,point,x,y,anchor='mt'):
    px,py=project(point);px+=150;py+=160
    d.line([(x,y+32),(px,py)],fill='#304e5c',width=3)
    d.ellipse((px-6,py-6,px+6,py+6),fill='#304e5c')
    # White backing keeps labels readable over the model.
    f=ImageFont.truetype(FONT,27)
    bb=d.textbbox((x,y),s,font=f,anchor=anchor)
    d.rectangle((bb[0]-9,bb[1]-5,bb[2]+9,bb[3]+5),fill='#ffffff')
    d.text((x,y),s,font=f,anchor=anchor,fill='#253d48')
callout('Bare metal-carabiner slots',(177,135.25,100),1740,170)
callout('Charger liner + floor mat',(177.5,61.5,32),1830,530)
callout('Stopper liner + floor mat',(-150,0,57),420,790)
callout('Wider 60 mm side pads',(-147,136,100),480,190)
text(d,'No TPU floor below either Voltra — retained case foam supports the devices',1100,1475,30)
text(d,'Removable accessory mats cover the existing logos and raise their floors by 2 mm.',1100,1530,28)
text(d,'TPU 95A is the starting material; cushioning and retention need a physical coupon test.',1100,1580,27)
im.save(OUT/'TPU_Concept_Top_View.png')

im=Image.new('RGB',(1600,1450),'#f9f9f9')
pic,_=render('detail_triangles.npz',[-.7,1,.7],1600,1090)
im.paste(pic,(0,170));d=ImageDraw.Draw(im)
text(d,'Voltra pad seat — enlarged CAD cutaway',800,30,40)
text(d,'Orange TPU sits in a shallow gray rigid-wall pocket',800,95,29)
text(d,'2.5 mm seat = 1.2 mm contact skin + 1.3 mm back relief',800,1270,29)
text(d,'Back relief leaves room to flex; the device-side face stays at the tested opening.',800,1320,26)
text(d,'Illustrative coupon section. Final slide-in retention / lip is still to be designed.',800,1370,26)
im.save(OUT/'TPU_Pad_Seat_Cutaway.png')
print('Saved assembly, top view and actual CAD cutaway',flush=True)
