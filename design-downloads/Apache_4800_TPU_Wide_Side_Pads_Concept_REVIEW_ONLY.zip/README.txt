APACHE 4800 / VOLTRA — WIDER TPU SIDE PADS, CAD REVIEW ONLY

CHANGE FROM THE PREVIOUS CONCEPT
The four long-side pads around each Voltra are widened from 25 to 60 mm,
keeping their previous centers. There are eight widened pads total. Each
remains 90 mm high in a 2.5 mm seat. Back relief extends across the wider
pad to retain the same 1.2 mm contact skin / 1.3 mm flex-space concept.
The end pad for each Voltra remains 50 mm wide and is unchanged.
Charger liners, stopper liners, 2 mm floor mats, bare carabiner slots,
and the previous air-valve relief are unchanged.

Orange = TPU; gray = rigid supports. All images are renders of actual CAD.
The STEP assembly retains separate colored rigid and TPU components.
Open TPU_Concept_Assembly.png and TPU_Concept_Top_View.png for the new
layout. TPU_Pad_Seat_Cutaway.png illustrates the same pad seat cross-section.

This remains a placement concept, NOT a printable release. The surrounding
hard walls need a setback or a controlled TPU proud offset so TPU contacts
first; the displayed pad surfaces use the established opening datum.
Retention features, fit tolerances, remaining wall strength and cushioning
have not been finalized or physically tested. No printable STLs are supplied.

Voltras remain supported by the retained bottom foam, with open-bottom
device cavities. Accessory mats still cover the charger-floor logos and
raise accessory floors by 2 mm. The larger nominal charger/cable bundle
has 1.14 mm spare height; physical packing and lid clearance need checking.

The review includes valid single-solid CAD components and geometry-based
renders, not a drop-protection rating. TPU 95A remains a starting material.
See concept_notes.json and comparison_validation.json for the change scope
and which checks completed. Keep the previously released valve-relief print
files until a finished TPU-compatible release is developed.
