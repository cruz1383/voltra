from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-tpu-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent
old=np.load(ROOT.parent/'tpu-concept/review/cad_triangles.npz')
new=np.load(ROOT/'review/cad_triangles.npz')
unchanged=[]
for name in old.files:
    if name.startswith('TPU') and (not 'Voltra_pad_' in name or name.endswith('pad_5')):
        assert np.array_equal(old[name],new[name]),name
        unchanged.append(name)
widths={}
for row in ['Upper','Lower']:
    for n in range(1,5):
        name=f'TPU__{row}_Voltra_pad_{n}'
        before=old[name][:,:,0].max()-old[name][:,:,0].min()
        after=new[name][:,:,0].max()-new[name][:,:,0].min()
        assert abs(before-25)<1e-6 and abs(after-60)<1e-6
        oldc=(old[name][:,:,0].max()+old[name][:,:,0].min())/2
        newc=(new[name][:,:,0].max()+new[name][:,:,0].min())/2
        assert abs(oldc-newc)<1e-6
        widths[name]={'before_mm':float(before),'after_mm':float(after),'center_unchanged':True}
        # Check actual revised pad is a valid BREP single solid.
        shape=cq.Shape.importBrep(str(ROOT/'review'/f'{row}_Voltra_pad_{n}.brep'))
        assert shape.isValid() and len(shape.Solids())==1
report={'widened_side_pads':widths,
        'unchanged_components_exact_tessellation_match':unchanged,
        'stage':'Concept review; no physical fit or print validation'}
(ROOT/'review/comparison_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
