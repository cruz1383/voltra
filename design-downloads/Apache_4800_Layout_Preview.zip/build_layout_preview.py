"""Measured plan-view layout for review, not a full-height printable insert."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/jig-mpl')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/jig-cache')
import json
import math
import shutil
import cadquery as cq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, PathPatch
from matplotlib.path import Path as MPath

OUT = Path('/workspace/designs/output/Apache_4800_Layout_Preview')
OUT.mkdir(exist_ok=True, parents=True)
L, W, R = 452.025, 320.2625, 20.0
BODY_L, BODY_W, OVERALL_L = 291.04, 107.72, 329.0
OPEN_L, OPEN_W = 333.0, 108.22
ROW = 81.0
CAR_L, CAR_W, CAR_T = 75.78, 39.81, 8.91
STOP_L, STOP_W = 60.97, 41.27

def rr(l, w, r, x=0, y=0, h=3):
    return (cq.Workplane('XY').box(l, w, h, centered=(True, True, False))
            .edges('|Z').fillet(r).val().translate((x, y, 0)))

def disk(r, x, y, h=3):
    return cq.Solid.makeCylinder(r, h, cq.Vector(x, y, 0))

outer = rr(L, W, R)
pockets, equipment, pins = {}, {}, {}
for name, side in [('Red', 1), ('Green', -1)]:
    yc = side * ROW
    # Red screen end at left; green is rotated 180 degrees in plan view.
    red_min = -L/2 + 24
    red_max = red_min + BODY_L
    body_center = side * (red_min + BODY_L/2)
    overall_center = side * (red_min + OVERALL_L/2)
    pocket = rr(OPEN_L, OPEN_W, .5, overall_center, yc)
    # Only a station and plan-view wall relief: installed pin side is provisional.
    pin_x = side * (red_max - 100.79)
    pin_y = yc - side * OPEN_W/2
    pin = cq.Solid.makeBox(5.2, 2.01, 3, cq.Vector(pin_x-2.6,
                           pin_y-2 if side == 1 else pin_y-.01, 0))
    pocket = pocket.fuse(pin).clean()
    pins[name] = {'x_mm': pin_x, 'y_mm': pin_y,
                  'station_from_cover_handle_end_mm': 100.79,
                  'relief_width_mm': 5.2, 'relief_depth_mm': 2.0,
                  'side_status': 'Shown on inward-facing wall for preview; verify installed pin side before full CAD'}
    pockets[name+' device'] = pocket
    # Conservative rectangular envelope, not a fabricated equipment replica.
    body = cq.Solid.makeBox(BODY_L, BODY_W, 3,
                           cq.Vector(body_center-BODY_L/2, yc-BODY_W/2, 0))
    handle_center = side * (red_max + (OVERALL_L-BODY_L)/2)
    equipment[name] = {'side': side, 'body_center': body_center,
                       'overall_center': overall_center, 'handle_center': handle_center,
                       'y': yc, 'body': body}
    # Finger scallop on the outer long side, kept clear of the pin channel.
    finger_x = side * -65
    pocket = pocket.fuse(disk(10, finger_x, yc+side*(OPEN_W/2-2))).clean()
    pockets[name+' device'] = pocket
    assert pocket.intersect(body).Volume() > body.Volume()-1e-5

for name, side in [('Red', 1), ('Green', -1)]:
    # These small slots occupy the same end areas as the original foam layout.
    cx, cy = side*177, side*ROW
    cp = rr(CAR_L+2, CAR_W+2, (CAR_W+2)/2-.01, cx, cy)
    cp = cp.fuse(disk(7, cx, cy-side*(CAR_W+2)/2)).clean()
    pockets[name+' carabiner'] = cp
    # Stopper: measured overall envelope, not a claim about its exact molded shape.
    sx = -side*150
    sp = rr(STOP_L+2, STOP_W+2, (STOP_W+2)/2-.01, sx, 0)
    sp = sp.fuse(disk(8, sx-side*(STOP_L+2)/2, 0)).clean()
    pockets[name+' stopper'] = sp

validation = {'stage': 'Dimensioned layout preview; not a printable full-height insert',
              'outside_mm': [L, W], 'outside_radius_mm': R,
              'device_opening_mm': [OPEN_L, OPEN_W],
              'row_centers_y_mm': [ROW, -ROW],
              'stopper_cradle_envelope_mm': [STOP_L+2, STOP_W+2],
              'carabiner_slot_envelope_mm': [CAR_L+2, CAR_W+2],
              'accessory_clearance_per_side_mm': 1,
              'pins': pins, 'pairwise_pocket_spacing_mm': {},
              'physical_fit_confirmed': ['Perimeter V2 at cushion level', '108.22 mm Voltra test opening'],
              'physical_fit_not_confirmed': ['Accessory pockets', '100 mm tall assembly', 'Final retention joints', 'Case taper at top height'],
              'cable_channel': {'provisional_width_mm': 6, 'depth': 'Not finalized',
                                'routing': 'Open grooves between equipment side exits and stopper cradles; cable above cover shown separately'},
              'equipment_features': 'Body and handle envelopes measured; screens, outlets, cables and molded accessory shapes schematic'}
names = list(pockets)
for i, name in enumerate(names):
    p = pockets[name]
    assert p.isValid() and len(p.Solids()) == 1, name
    assert abs(p.intersect(outer).Volume()-p.Volume()) < 1e-5, name
    for other in names[i+1:]:
        q = pockets[other]
        assert p.intersect(q).Volume() < 1e-6, (name, other)
        d = p.distance(q)
        validation['pairwise_pocket_spacing_mm'][name+' / '+other] = d
        assert d >= 5-1e-6, (name, other, d)

# Test against an inset outer envelope rather than a bounding rectangle at corners.
inset = rr(L-10, W-10, R-5)
for name, p in pockets.items():
    assert abs(p.intersect(inset).Volume()-p.Volume()) < 1e-5, name
validation['minimum_uninterrupted_wall_mm'] = 5
layout = outer
for p in pockets.values():
    layout = layout.cut(p)
layout = layout.clean()
assert layout.isValid() and len(layout.Solids()) == 1
cq.exporters.export(layout, str(OUT/'REFERENCE_ONLY_3mm_Layout_Slice.step'))
# Budget the existing perimeter-test keys; final wall joints are not yet implemented.
validation['four_section_footprint_budget_mm'] = [230.3125, 164.43125]
validation['with_5mm_brim_budget_mm'] = [240.3125, 174.43125]
assert all(v <= 256 for v in validation['with_5mm_brim_budget_mm'])

fig, ax = plt.subplots(figsize=(15, 11))
fig.patch.set_facecolor('#fafaf7')
ax.set_facecolor('#fafaf7')

def rounded_patch(l, w, r, x, y, **kw):
    p = FancyBboxPatch((x-l/2, y-w/2), l, w,
                       boxstyle=f'round,pad=0,rounding_size={r}', **kw)
    ax.add_patch(p)
    return p

def outline(shape, color='#293743', lw=1.2):
    # Draw the actual CAD edges at z=0, including finger scallops and pin reliefs.
    for edge in shape.Edges():
        points, _ = edge.sample(30 if edge.geomType() != 'LINE' else 2)
        if all(abs(p.z)<1e-6 for p in points):
            ax.plot([p.x for p in points], [p.y for p in points], color=color, lw=lw, zorder=3)

rounded_patch(L, W, R, 0, 0, facecolor='#ccd3d5', edgecolor='#24333b', lw=2)
for name, p in pockets.items():
    if 'device' in name:
        e=equipment[name.split()[0]]
        rounded_patch(OPEN_L, OPEN_W, .5, e['overall_center'], e['y'],
                      facecolor='#ebe9e1', edgecolor='none')
    elif 'carabiner' in name:
        side = 1 if name.startswith('Red') else -1
        rounded_patch(CAR_L+2, CAR_W+2, (CAR_W+2)/2-.01, side*177, side*ROW,
                      facecolor='#f2f0e6', edgecolor='none')
        ax.add_patch(Circle((side*177, side*(ROW-(CAR_W+2)/2)),7,
                            facecolor='#f2f0e6',edgecolor='none'))
    else:
        side=1 if name.startswith('Red') else -1
        rounded_patch(STOP_L+2, STOP_W+2, (STOP_W+2)/2-.01, -side*150, 0,
                      facecolor='#f2f0e6', edgecolor='none')
        ax.add_patch(Circle((-side*(150+(STOP_L+2)/2),0),8,
                            facecolor='#f2f0e6',edgecolor='none'))
    outline(p)

for name, e in equipment.items():
    side, x, y = e['side'], e['body_center'], e['y']
    color = '#b94740' if side==1 else '#7c9067'
    rounded_patch(BODY_L, BODY_W, 3, x, y, facecolor=color, edgecolor='#35404a', lw=1)
    screen_x = x-side*97
    rounded_patch(68, 78, 3, screen_x, y, facecolor='#222d35', edgecolor='#b7bec4',lw=1.5)
    ax.text(screen_x,y,'SCREEN',color='#e4eaec',ha='center',va='center',fontsize=8)
    outlet_x = -side*45
    ax.add_patch(Circle((outlet_x,y),22,facecolor='#555a5d',edgecolor='#f49d39',lw=2))
    ax.add_patch(Circle((outlet_x,y),15,facecolor='#172028',edgecolor='#a4b1b8',lw=1))
    # Gray U is only a handle envelope illustration, not an invented cover recess.
    hx=e['handle_center']
    inner_x = hx-side*15
    outer_x = hx+side*15
    ax.plot([inner_x,outer_x,outer_x,inner_x],[y-40,y-40,y+40,y+40],
             color='#899398',lw=6,solid_capstyle='round',solid_joinstyle='round')
    ax.text(x+side*75,y,name+' Voltra\ncovered body',ha='center',va='center',
             color='white',fontsize=9,weight='bold')
    # Carabiner shown flat within the small dedicated fitted slot.
    cx,cy=side*177,y
    rounded_patch(CAR_L,CAR_W,CAR_W/2-.01,cx,cy,fill=False,edgecolor='#7b858c',lw=4)
    ax.text(cx,cy,'CLIP',ha='center',va='center',fontsize=7,color='#26323b')
    # Stopper body with its projecting loop, positioned outside the Voltra.
    sx=-side*150
    body_sx=sx-side*9
    ax.add_patch(Circle((body_sx,0),STOP_W/2,facecolor='#d7d5c6',edgecolor='#6c746f',lw=1))
    rounded_patch(31.59,25,12,sx+side*13,0,fill=False,edgecolor='#9c9f94',lw=4)
    ax.text(body_sx,0,'STOP',ha='center',va='center',fontsize=7,color='#35413c')
    # Cable on the actual cover: dashed because its outlet placement is schematic.
    ax.plot([outlet_x,outlet_x],[y,side*(ROW-OPEN_W/2)],
             color='#475c67',lw=2,ls='--',zorder=8)
    # Smooth route is a proposed shallow open groove, not a hole through the device.
    verts=[(outlet_x,side*(ROW-OPEN_W/2)),(-side*48,side*9),
           (-side*78,0),(-side*120,0)]
    path=MPath(verts,[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4])
    ax.add_patch(PathPatch(path,fill=False,edgecolor='#72b7d0',lw=6,zorder=6,capstyle='round'))
    ax.add_patch(PathPatch(path,fill=False,edgecolor='#304f61',lw=1,zorder=7))
    pin=pins[name]
    ax.plot([pin['x_mm']-2.6,pin['x_mm']+2.6],[pin['y_mm']]*2,
             color='#b82b88',lw=4,zorder=10)

# Planned four-way split, clipped to the CAD outer boundary.
ax.plot([-L/2,L/2],[0,0],color='#354e5c',ls=(0,(4,5)),lw=.85,alpha=.65,zorder=12)
ax.plot([0,0],[-W/2,W/2],color='#354e5c',ls=(0,(4,5)),lw=.85,alpha=.65,zorder=12)
for label,x,y in [('TL',-210,145),('TR',210,145),('BL',-210,-145),('BR',210,-145)]:
    ax.text(x,y,label,fontsize=8,ha='center',color='#314550',weight='bold')

def hdim(x1,x2,y,text):
    ax.annotate('',xy=(x1,y),xytext=(x2,y),arrowprops={'arrowstyle':'<->','lw':.9,'color':'#334a57'})
    ax.text((x1+x2)/2,y-4,text,ha='center',va='top',fontsize=9,color='#273d49')

hdim(-L/2,L/2,-W/2-15,'452.025 mm — tested perimeter')
ax.annotate('',xy=(L/2+12,-W/2),xytext=(L/2+12,W/2),arrowprops={'arrowstyle':'<->','lw':.9})
ax.text(L/2+18,0,'320.2625 mm — tested perimeter',rotation=90,ha='center',va='center',fontsize=9)
ax.annotate('',xy=(-L/2-10,ROW-OPEN_W/2),xytext=(-L/2-10,ROW+OPEN_W/2),arrowprops={'arrowstyle':'<->','lw':.9})
ax.text(-L/2-16,ROW,'108.22 mm\ntested opening',ha='center',va='center',rotation=90,fontsize=8)
ax.text(-150,29,'STOPPER CRADLE\n62.97 × 43.27 mm',ha='center',va='bottom',fontsize=7,
         bbox={'facecolor':'#fafaf7','alpha':.95,'edgecolor':'none','pad':2},zorder=15)
ax.text(150,-29,'STOPPER CRADLE\n62.97 × 43.27 mm',ha='center',va='top',fontsize=7,
         bbox={'facecolor':'#fafaf7','alpha':.95,'edgecolor':'none','pad':2},zorder=15)
ax.text(177,115,'CARABINER SLOT\n77.78 × 41.81 mm',ha='center',va='bottom',fontsize=7)
ax.text(-177,-115,'CARABINER SLOT\n77.78 × 41.81 mm',ha='center',va='top',fontsize=7)
ax.text(0,13,'Open cable grooves\n6 mm wide, provisional',ha='center',va='bottom',fontsize=8,
         bbox={'facecolor':'#fafaf7','alpha':.94,'edgecolor':'none','pad':2},zorder=15)
ax.text(0,-13,'Magenta: shim-pin relief stations\n100.79 mm from cover handle end',ha='center',va='top',fontsize=7,
         bbox={'facecolor':'#fafaf7','alpha':.94,'edgecolor':'none','pad':2},zorder=15)
ax.set_aspect('equal');ax.set_xlim(-L/2-33,L/2+36);ax.set_ylim(-W/2-40,W/2+10)
ax.axis('off')
fig.suptitle('Apache 4800 • measured layout preview',fontsize=19,weight='bold',y=.97)
fig.text(.5,.925,'Both upper foam layers replaced by four PETG sections • solid bottom cushion and lid foam retained',
         ha='center',fontsize=11)
fig.text(.5,.89,'Equipment sits on bottom foam. Cables remain outside the covers; blue marks proposed organizer grooves.',
         ha='center',fontsize=10,color='#314550')
fig.text(.5,.055,'Layout for review, not a final printable model. Equipment features and accessory outlines are schematic.\n'
         'Accessory pocket depths, cable routing and full-height fit still need validation. Dashed center lines mark four planned sections.',
         ha='center',fontsize=9,color='#4b5a61',linespacing=1.7)
fig.subplots_adjust(left=.04,right=.96,top=.865,bottom=.12)
fig.savefig(OUT/'Apache_4800_Layout_Preview.png',dpi=170)
fig.savefig(OUT/'Apache_4800_Layout_Preview.pdf')
fig.savefig(OUT/'Apache_4800_Layout_Preview.svg')
(OUT/'layout_validation.json').write_text(json.dumps(validation,indent=2))
(OUT/'README.txt').write_text(
    'APACHE 4800 MEASURED LAYOUT PREVIEW\n\n'
    'Open the PNG or PDF for the dimensioned top view. This is a CAD-driven plan view, not a generated product photo. '
    'REFERENCE_ONLY_3mm_Layout_Slice.step is a 3 mm planar review slice, NOT the final 100 mm insert and NOT a print file. '
    'No new printable STL is supplied at this layout-review stage.\n\n'
    'User-tested perimeter: 452.025 x 320.2625 mm, outer R20. Tested device opening width 108.22 mm. '
    'Overall opening length 333 mm unchanged from the tested band. Covered body length 291.04 mm; '
    'width 107.72 mm; overall with handle approximately 329 mm.\n\n'
    'Two matching stopper cradles: conservative capsule envelopes 62.97 x 43.27 mm; '
    'two matching carabiner slots: 77.78 x 41.81 mm, both with 1 mm clearance per side plus local finger scallops. '
    'These are envelope-fit pockets, not exact traces of the molded objects. The stopper overall length includes its loop. '
    'Carabiner thickness 8.91 mm, loop thickness 9.10 mm and outside loop width 31.59 mm are retained as design inputs. '
    'No large general-purpose pockets beside handles.\n\n'
    'Cables are shown crossing only their own covers from the outlets to open organizer grooves in the middle space; '
    'screens remain clear. There are no modeled equipment recesses for cable storage. Blue routes and 6 mm groove width '
    'are provisional because cable diameter, preferred bend and available slack have not been measured. '
    'Cable grooves and accessory depth are not yet cut into the reference slice. Pin cutouts are shown on inward-facing '
    'pocket walls, subject to checking which way each installed cover pin faces. Their longitudinal station is confirmed '
    'at 100.79 mm from the cover handle end (102.85 mm to far edge minus half 4.12 mm diameter); plan clearance 5.2 x 2 mm.\n\n'
    'All six CAD pockets are valid, inside the tested perimeter with at least 5 mm boundary clearance and pairwise '
    '5 mm spacing, excluding future intentionally connected cable grooves. Four-section footprint budget including '
    'the prior test keys is 230.3125 x 164.43125 mm; a 5 mm brim gives 240.3125 x 174.43125 mm. '
    'Final full-height joints have not been designed or checked. Four final sections will replace the two upper foam '
    'layers at about 100 mm height. Keep the solid bottom cushion and lid foam. Device pockets will remain open-bottom; '
    'accessory cradles will need elevated floors. Full-height fit, case taper, accessory fit and lid clearance remain untested.\n')
shutil.copy(__file__,OUT/'build_layout_preview.py')
print(json.dumps({'output':str(OUT),'valid':layout.isValid(),
                  'minimum_pocket_spacing_mm':min(validation['pairwise_pocket_spacing_mm'].values())},indent=2))
