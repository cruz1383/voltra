"""Thin formed handle facing; divider unchanged; connecting tongues are a concept."""
from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-handle-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
SOURCE=ROOT.parent/'tpu-full-v3p1/review'
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def prism_xz(points,y,width):
    vs=[cq.Vector(x,y,z) for x,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(vs+[vs[0]]),[],cq.Vector(0,width,0))
cx=-452.025/2+24+329/2;yc=81
base=(cq.Workplane('XY').box(333,108.22,1,centered=(True,True,False)).translate((cx,yc,0))
      .edges('|Z and >X').fillet(15).edges('|Z and <X').fillet(2).val())
wire=next(f for f in base.Faces() if f.normalAt().z<-.99).outerWire()
def pocket(offset):return cq.Workplane('XY').add(wire).toPending().offset2D(offset).extrude(90).val().translate((0,0,10))
formed=pocket(1.5).cut(pocket(.5)).intersect(box(108,0,10,40,160,90))
assert formed.isValid() and len(formed.Solids())==1
front=129.4875;hard_face=130.4875
neutral_length=78.22+math.pi*16+2*(113.9875-108)
blank=box(front,81-neutral_length/2,10,1,neutral_length,90)
cup=cq.Shape.importBrep(str(SOURCE/'TPU_Upper_charger_TPU_liner.brep'))
tabs=[]
for y in [50,78]:
    # Flat-printable tongue: all outward growth is45deg or vertical when
    # the facing's flat contact surface is on the bed. It straddles the
    # existing top surface rather than recessing the thin rigid divider.
    tongue=prism_xz([(front,100),(131.8,100),(133,98.8),(134,98.8),
                     (134,101),(front+1,101)],y,10)
    formed=formed.fuse(tongue);blank=blank.fuse(tongue);tabs.append(tongue)
    recess=prism_xz([(131.65,100.2),(131.65,99.9),(132.85,98.65),
                     (134.15,98.65),(134.15,100.2)],y-.15,10.3)
    cup=cup.cut(recess)
assert formed.isValid() and len(formed.Solids())==1
assert blank.isValid() and len(blank.Solids())==1
assert cup.isValid() and len(cup.Solids())==1
rigid={n:cq.Shape.importBrep(str(SOURCE/f'rigid_{n}.brep')) for n in ['BL','BR','TL','TR']}
for n,p in rigid.items():
    assert p.intersect(formed).Volume()<1e-5,(n,'facing intersects rigid wall')
    assert p.intersect(cup).Volume()<1e-5,(n,'revised liner intersects wall')
assert formed.intersect(cup).Volume()<1e-5
for name,p in [('Upper_Handle_Facing',formed),('Upper_Charger_Liner',cup)]:
    cq.exporters.export(p,str(OUT/(name+'_CONCEPT.step')))
    cq.exporters.export(p.rotate((0,0,0),(0,0,1),180),str(OUT/(name.replace('Upper','Lower')+'_CONCEPT.step')))
# Approximate neutral-axis flat development: the thin web is bent on fitting.
# The top tongues lie in the unchanged straight middle section.
flat=blank.rotate((0,0,0),(0,1,0),-90).translate((101,0,-front))
cq.exporters.export(flat,str(OUT/'Handle_Facing_Flat_Pattern_CONCEPT.step'))
def mesh(p):
    v,f=p.tessellate(.025,.07)
    return np.array([q.toTuple() for q in v])[np.array(f)]
def arrays(name,parts):np.savez_compressed(OUT/(name+'.npz'),**{k:mesh(v) for k,v in parts.items()})
all_parts={'rigid_'+n:p for n,p in rigid.items()}
for path in SOURCE.glob('TPU_*.brep'):
    name=path.stem
    if name in ['TPU_Upper_charger_TPU_liner','TPU_Lower_charger_TPU_liner']:continue
    all_parts[name]=cq.Shape.importBrep(str(path))
all_parts.update({'TPU_Upper_charger_liner_revised':cup,'TPU_Lower_charger_liner_revised':cup.rotate((0,0,0),(0,0,1),180),
 'TPU_Upper_handle_facing':formed,'TPU_Lower_handle_facing':formed.rotate((0,0,0),(0,0,1),180)})
assembly=cq.Assembly(name='THIN_HANDLE_FACING_CONCEPT_NO_RIGID_CUTS')
for name,p in all_parts.items():assembly.add(p,name=name,color=cq.Color(1,.52,.12) if name.startswith('TPU') else cq.Color(.56,.63,.67))
assembly.save(str(OUT/'Handle_Facing_Full_Assembly_CONCEPT.step'))
arrays('full_assembly',all_parts)
clip=box(100,20,8,125,122,96)
arrays('handle_context',{'rigid':rigid['TR'].intersect(clip),'TPU_facing':formed,'TPU_cup':cup})
arrays('separated',{'rigid':rigid['TR'].intersect(clip),'TPU_facing':formed.translate((-20,0,20)),'TPU_cup':cup.translate((0,0,25))})
# Exact through-divider section: show that the thin rigid web remains.
clip=box(126,55,80,13,10,23)
arrays('divider_detail',{'rigid':rigid['TR'].intersect(clip),'TPU_facing':formed.intersect(clip),'TPU_cup':cup.intersect(clip)})
arrays('flat_pattern',{'TPU':flat})
audit={}
for n,p in [('facing_flat',flat),('charger_cup_upright',cup.translate((-177.5,-61.5,-30)))]:
    a=mesh(p);normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(normal,axis=1)/2
    normal/=np.maximum(2*area,1e-14)[:,None]
    bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
    bad=(normal[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
    audit[n]={'off_bed_downward_area_beyond_46deg_mm2':float(area[bad].sum()),'bottom_z_mm':float(a[:,:,2].min())}
report={'stage':'Handle facing concept only; no main print-file revisions',
 'rigid_parts_changed':False,'facing_thickness_mm':1,'contact_offset_beyond_original_opening_mm':.5,
 'facing_start_z_mm':10,'facing_end_z_mm':100,'top_connection_max_z_mm':101,
 'top_connection_additional_rim_height_mm':1,'formed_neutral_radius_mm':16,
 'approximate_developed_neutral_width_mm':neutral_length,
 'divider_web_preserved_mm':{'body':1.8625,'upper_lip':.8625},
 'cup_and_facing_valid_single_solids':True,'seated_overlaps_mm3':0,
 'connection':'Two broad TPU locating/press-fit tongues; final positive retention not established',
 'print_strategy':'Separate flat flexible facing and upright charger liner; form facing on assembly',
 'geometry_audit':audit,'pending':['Tongue retention and printer tolerances','Lid clearance for added1mm',
 'Actual handle shape/clearance','Forming and installation','Physical print validation'],
 'note':'The old rigid divider is not cut or thickened; only charger TPU rim recesses change.'}
(OUT/'concept_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
