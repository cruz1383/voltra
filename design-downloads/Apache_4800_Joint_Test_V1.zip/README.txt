FULL-HEIGHT JOINT TEST ONLY

Print both STL files at100percent scale, flat foot on bed. PETG,0.20mm layers,4 walls,12percent gyroid infill. Use a5-10mm brim for these100mm tall narrow tests.

Slide the female track down over the male part until both feet sit on the same flat surface. It should move by hand without forcing, spreading or cracking. Tracks use the exact same0.20mm socket offset and male pad/ramp geometry as Full Insert V1.

This tests print fit of the new full-height joint before printing the large sections. It does not test case taper, equipment or accessory fit. If too tight, report it; do not scale the main insert.
