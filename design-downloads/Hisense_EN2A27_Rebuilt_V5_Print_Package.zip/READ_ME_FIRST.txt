HISENSE EN2A27 — CLEAN CAD REBUILD V5 / FIRST FIT PRINT

V5 CORRECTION:retaining teeth point INWARD toward the cover center.
Both rails remain continuous and their top edges remain smooth. The
pointed triangle has been replaced by a broader, flat-ended wedge with
rounded corners. No additional height is added above the rail.

Confirmed combined rail/tooth section:2.16 mm.
Confirmed shoulder-to-tooth station:16.07 mm.
The current modeled rail starts at X=-27; tooth station is X=-10.93.
Rail width remains an estimated0.85 mm, so the inward projection is1.31 mm.
The revised profile has a5.0 mm base,1.8 mm flat nose and0.20 mm corner
radii. These profile details are implementation estimates, not additional
caliper measurements. Overall cover width returns to39.02 mm because the
teeth now project inward. Body, end tabs and catch remain unchanged.
Earlier V1-V4 rail revisions are superseded by this V5 correction.

This replaces the earlier patched scan candidate. The new model is clean
CAD using supplied caliper measurements and photographs, with scan-guided
surface curvature. It is not merely a conversion or smoothed scan.

CALIPER MEASUREMENTS
Body length excluding tabs:76.02 mm.
Body width:39.02 mm.
Nominal shell thickness:2.20 mm.
Overall length including reconstructed tabs:79.02 mm.
The side rails, two insert tabs, and rounded-end catch are reconstructed
from scan/photo evidence; their dimensions were NOT independently measured.
See validation.json for those estimated feature dimensions. Scan markers,
embossed text, and scan roughness are omitted. The outside is smooth.

FIT STATUS
This is a first fit print, not a confirmed working replacement. Main body
size follows calipers. Tab engagement, side-rail clearance, battery clearance,
and catch/release function require a physical fit check. The catch frame
approximates visible geometry; the original release flexure is not verified.
Do not force a binding cover. It is not appropriate to call the attachment
features an exact reproduction solely from these perspective photographs.

PRINTING
Import STL in millimeters,100% scale. Do not auto-scale it.
The STL is oriented broad face horizontal, inner features upward, bottom
at Z0. The curved exterior does not sit flat over its entire area:inspect
and enable supports beneath raised curved portions and tab overhangs as
needed. This is NOT a verified support-free design or pre-sliced project.
PETG is a reasonable starting material for functional clips. Use your known
PETG printer profile; a0.16 mm layer and3-4 walls are reasonable starting
settings for a0.4 mm nozzle. Check thin tab slot toolpaths. PLA can be used
for a dimensional trial but is more brittle at small engagement features.
Printer-specific toolpaths, bridging and support removal are untested.

CHECKS
Valid single CAD solid. STL:one watertight connected body, consistent winding,
positive volume, no detected self-intersecting faces. Nine main-shell
thickness probes confirm2.20 mm. These are geometric checks, not physical fit.

FILES
Hisense_EN2A27_Rebuilt_V5.stl:print geometry.
Hisense_EN2A27_Rebuilt_V5.step:editable CAD reference.
Hisense_EN2A27_Rebuilt_V5_CAD.png:four CAD views.
validation.json:dimensions, estimated features, mesh/thickness checks.

ADDITIONAL V5 FILES
Hisense_EN2A27_V5_Rail_Closeup.png:inward wedge with broad flat nose.
rail_change_validation.json:rail continuity, smooth top, inward tip checks.
