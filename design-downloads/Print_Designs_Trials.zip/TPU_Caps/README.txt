VOLTRA CABLE-COVER SCREW CAPS — CR-TPU BLACK FIT TRIALS
Units mm. Cosmetic plugs only; not drivers.
All variants: circular head diameter10.22, thickness2.43. Stem length6.30 measured from head underside, total height8.73. STL orientation has head outer face on bed and stem upright. Supports normally unnecessary; inspect slicer. Use your established CR-TPU profile; hardness and printer compensation are unknown.

Variant                 opposing tips   opposing valleys
Baseline                     3.74             3.38
Tighter_005                   3.79             3.43
Tighter_010                   3.84             3.48
Tighter suffixes indicate TOTAL diameter increase, not per-side increase.

PROFILE LIMITATION
The two supplied cross-sectional measurements do not uniquely define a standard T20/Torx profile. These are explicit smooth six-lobed approximations: polar radius r(theta)=1.78+delta/2+0.09*cos(6theta), sampled360 points and extruded. They are NOT certified standard Torx geometry and do not reproduce an unknown original profile between measured tips/valleys. No reduction was made to baseline measured diameters; tighter variants intentionally add interference for thumb-pressure retention trials. Actual pressure and retention cannot be predicted from these dimensions and unknown TPU hardness.

Start with baseline. Try tighter variants only if needed; press with thumb pressure, do not drive or hammer. Nominal6.30 stem versus6.51–6.81 cover-surface-to-bottom depth leaves only0.21–0.51 axial margin when head underside is seated on cover. First-layer distortion, debris and actual seating surface can consume that margin; check head seating and bottoming gently. If bottoming occurs, stop and shorten a future trial rather than increase force.

All parts valid single solids; STLs watertight, consistent winding, positive volume and bed placement checked. Physical fit, thumb pressure and retention UNTESTED.
