from pathlib import Path
import xml.etree.ElementTree as ET
import json, re, math, os
os.environ.setdefault('MPLCONFIGDIR','/tmp/badge-matplotlib')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/badge-cache')
import cadquery as cq
import numpy as np
from PIL import Image,ImageDraw
O=Path('/workspace/designs/output/Beyond_Power_Badge');O.mkdir(exist_ok=True)
P=Path('/workspace/designs/output/Badge_Logo_Proof/Beyond_Power_Outline_Proof.svg')
W,H,T,R=119.50,59.92,1.90,8.0
DEPTH=.60
# Read the actual approved SVG contour polygons, without re-tracing or using fonts.
root=ET.parse(P).getroot();glyphs=[]
for el in root:
 if el.tag.split('}')[-1]!='path':continue
 loops=[]
 for sub in el.attrib['d'].split('Z'):
  nums=list(map(float,re.findall(r'-?\d+(?:\.\d+)?',sub)))
  if nums:loops.append(np.array(nums).reshape(-1,2))
 glyphs.append((el.attrib['id'],loops))
allpts=np.concatenate([p for _,ps in glyphs for p in ps]);low=allpts.min(0);high=allpts.max(0);center=(low+high)/2
scale=min((W-10)/(high[0]-low[0]),(H-10)/(high[1]-low[1]))
def coords(p):
 q=(p-center)*scale;q[:,1]*=-1
 return q
base=cq.Workplane('XY').box(W,H,T,centered=(True,True,False)).edges('|Z').fillet(R).val()
cutters=[]
for name,loops in glyphs:
 def prism(p):
  return cq.Workplane('XY').polyline([tuple(v) for v in coords(p)]).close().extrude(DEPTH+.2).val().translate((0,0,T-DEPTH))
 tool=prism(loops[0])
 for p in loops[1:]:tool=tool.cut(prism(p))
 tool=tool.clean();assert tool.isValid(),name
 cutters.append(tool)
badge=base.cut(*cutters).clean();assert badge.isValid() and len(badge.Solids())==1
coupon=base.intersect(cq.Solid.makeBox(22,22,T,cq.Vector(W/2-22,H/2-22,0))).clean()
for name,s in [('Beyond_Power_Badge_R8_1p90mm',badge),('Corner_Fit_Coupon_R8',coupon)]:
 assert s.isValid() and len(s.Solids())==1
 cq.exporters.export(s,str(O/(name+'.step')))
 b=s.BoundingBox();q=s.translate((-b.xmin,-b.ymin,-b.zmin))
 cq.exporters.export(q,str(O/('PRINT_'+name+'.stl')),tolerance=.012,angularTolerance=.08)
# Expected material removed must equal sum of engraving footprints *0.60.
expected=sum(s.Volume()/(DEPTH+.2)*DEPTH for s in cutters)
actual=base.Volume()-badge.Volume();assert abs(expected-actual)<.01,(expected,actual)
b=badge.BoundingBox();assert abs(b.xlen-W)<1e-5 and abs(b.ylen-H)<1e-5 and abs(b.zlen-T)<1e-5
report={'badge_valid':badge.isValid(),'badge_solids':len(badge.Solids()),'width_mm':W,'height_mm':H,'thickness_mm':T,'corner_radius_mm':R,'corner_radius_status':'Provisional, actual recess radius unknown','perimeter_clearance_per_side_mm':.25,'recess_depth_mm':1.92,'nominal_glue_allowance_mm':.02,'engraving_depth_mm':DEPTH,'remaining_floor_mm':T-DEPTH,'engraved_glyphs':len(glyphs),'approved_svg_source':P.name,'engraving_volume_expected_mm3':expected,'engraving_volume_actual_mm3':actual,'physical_fit':'UNTESTED'}
(O/'CAD_validation.json').write_text(json.dumps(report,indent=2))
# Flat manufacturing proof: grayscale indicates recessed logo in single black material.
S=12;pad=5;im=Image.new('RGB',(round((W+2*pad)*S),round((H+2*pad)*S)),'white');dr=ImageDraw.Draw(im)
def px(x,y):return ((x+W/2+pad)*S,(H/2-y+pad)*S)
dr.rounded_rectangle([px(-W/2,H/2),px(W/2,-H/2)],radius=R*S,fill='#414141')
for _,loops in glyphs:
 for j,p in enumerate(loops):dr.polygon([px(x,y) for x,y in coords(p)],fill='#151515' if j==0 else '#414141')
im.save(O/'Badge_Flat_Preview.png')
# Orthographic top view from actual BREP triangles. Horizontal faces reveal engraving depth.
v,f=badge.tessellate(.04);v=np.array([[a.x,a.y,a.z] for a in v]);tri=v[np.array(f)]
preview=Image.new('RGB',im.size,'white');draw=ImageDraw.Draw(preview)
for face in sorted(tri,key=lambda a:a[:,2].mean()):
 height=face[:,2].mean()
 col='#444444' if height>T-.01 else '#171717'
 draw.polygon([px(x,y) for x,y,z in face],fill=col)
preview.save(O/'Badge_CAD_Preview.png')
print(json.dumps(report,indent=2))
