BEYOND POWER BADGE — APACHE 4800 — R8 FIT TRIAL
All dimensions millimetres.

User-confirmed recess:120.00 x60.42 x1.92 deep.
User-selected badge thickness:1.90. Nominal space remaining for glue:0.02. This is a nominal geometry difference, not a guarantee of a flush glued result; printed thickness and actual glue film determine final seating.
Badge outline:119.50 x59.92, leaving0.25 per side at straight edges.
Corner radius:R8.00, provisional because actual recess corner radius is unknown. Larger corner cutbacks help clear a smaller-radius recess; no unknown corner fit can be guaranteed. Print the small upper-right22x22 corner coupon first, place it against both recess edges, and confirm it seats flat. Rotate it to test the other corners. The coupon tests local corner clearance and thickness, not full length/width or case-wall irregularity.
If coupon does not seat, report where it touches or send a close-up with a ruler before printing the full badge. If the coupon seats but corner gaps are visually too large, measure/photo the recess corner for a closer outline.

Artwork: the user-approved photo-traced SVG contours are used directly. No fonts, retracing or generative logo substitution. Both lines are scaled uniformly together, preserving approved layout/proportions. Flat proof includes estimated deskew from the photograph; the reference is not a calibrated orthographic source.
Logo is recessed0.60 from top surface. Remaining solid floor1.30. Counter islands are supported by that floor. Single-color black throughout; previews use shading to show recesses, not a second filament or paint. There are no raised letters.

FILES
PRINT_Beyond_Power_Badge_R8_1p90mm.stl: final-outline trial badge, flat back atZ=0, logo upward.
PRINT_Corner_Fit_Coupon_R8.stl: upper-right corner fit coupon, flat back atZ=0.
STEP files preserve CAD coordinates.
Badge_Flat_Preview.png: flat face proof of actual positioned contours.
Badge_CAD_Preview.png: tessellated CAD preview.
CAD_validation.json and mesh_validation.json: geometry checks.
Approved_Logo_Proof.svg: unchanged approved source.
build_badge.py: reproducible CadQuery source. By default reads approved SVG from/workspace/designs/output/Badge_Logo_Proof and writes/workspace/designs/output/Beyond_Power_Badge. Requires CadQuery2.7, NumPy, Pillow and Matplotlib already available in the current workspace. No application repository changes needed.

PRINT
Print back down with logo upward. Choose a first layer and layer schedule that totals1.90, with the engraving floor at1.30. For example0.20 first layer plus17 layers at0.10 reaches1.90, with floor and engraving levels aligned to layers. Avoid raft/support under the flat back. Inspect sliced small counters and lettering. Keep XY/hole compensation consistent with the fit trial. Black filament as requested; material choice remains user's preference. For shallow recess detail, a small layer height and calibrated first layer help. Do not assume slicer scaling repairs fit; scaling also changes approved logo and thickness.

VALIDATION
Closed valid single-solid badge and coupon; dimensions and engraving volume checked. STL watertightness, consistent winding, positive volume and on-bed placement checked separately. No physical print, glue test or recess fitting has been performed. Corner fit is explicitly provisional.
