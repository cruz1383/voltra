VOLTRA TPU CAP —4.00 TIP SPAN

Millimetres. Opposing tips4.00;stem6.35 from head underside;head10.22 diameter x2.43 thick;total8.78. Same uniformly scaled12 tangent-arc hexalobular proportions. Cosmetic TPU plug, not certified driver geometry.

PRINT_ STL is head face down atZ0, stem upright. Matching STEP included. Keep material drying and printer settings consistent with your CR-TPU fit tests. Previous available depth6.51–6.81 gives0.16–0.46 nominal axial margin.

Valid single CAD solid;profile/tangency/dimensions checked;STL watertight, consistently wound, positive volume and at intended bed/height. Physical fit and retention remain UNTESTED.
