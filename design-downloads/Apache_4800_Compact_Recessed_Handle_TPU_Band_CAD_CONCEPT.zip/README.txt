Compact recessed handle TPU band — CAD CONCEPT

This supersedes the rejected full-height handle facing concept. Not a print release.
Existing V3.1 printable downloads remain unchanged. No STL included.

Measurements: insert rim Z=100 mm; handle top 28.70 mm below rim (Z71.30),
handle Z thickness 28.11 mm; bottom Z43.19. Concept TPU contact band spans
Z41.50–73.70 (32.20 mm tall), allowing 1.69 mm below and 2.40 mm above.
TPU thickness 1.65 mm, buried 0.85 mm, projecting 0.80 mm from adjacent rigid
face. Fixed top/bottom capture with closed curved ends, no top tabs or rim bridge.
Uses existing tested cavity profile, not a reconstructed model of the handle.

Charger inner opening changes 87x65 to 86x67 mm. Handle-side wall moves
1 mm away from handle; pocket grows 2 mm toward carabiner side. Far outer
X edge stays fixed. Nominal backing behind recess: 1.8625 mm. Other shared
wall: 2.8625 mm; upper lip: 1.8625 mm. Insert height stays 100 mm.
Changes affect BL/TR rigid sections, both charger liners, and add two bands.

Measured charger and cable box envelopes fit CAD. Larger 85.5 mm cable bundle
has only 0.5 mm total length clearance: actual packing must be checked.
Seated band/charger geometric overlaps and band capture translations checked;
CAD solids valid. Geometry overhang audit passed at 46 degrees; not sliced.
Physical handle transport contact, band insertion/retention, wall strength,
and printed fit remain unverified. Coverage depends on actual handle movement.

Included: complete assembly STEP, four individual TPU STEP files, two rendered
CAD views, validation report, source scripts. Scripts refer to local V3.1
baseline cache and require that baseline to regenerate the entire assembly.
