HISENSE EN2A27 — CLEAN CAD REBUILD V3 / FIRST FIT PRINT

V3 corrects the rail shape: the rails are continuous with smooth tops.
A triangular projection comes off the OUTSIDE of each rail. There is no
extra rail-top height. The triangle projects0.30 mm outward from the rail
and is2.5 mm long, centered at the former gap location. These dimensions
are photo-guided estimates; the projection stays within the measured
39.02 mm body width. V1 gaps and V2 top bulges are superseded.
Body, end tabs and catch generation geometry remain unchanged.

This replaces the earlier patched scan candidate. The new model is clean
CAD using supplied caliper measurements and photographs, with scan-guided
surface curvature. It is not merely a conversion or smoothed scan.

CALIPER MEASUREMENTS
Body length excluding tabs:76.02 mm.
Body width:39.02 mm.
Nominal shell thickness:2.20 mm.
Overall length including reconstructed tabs:79.02 mm.
The side rails, two insert tabs, and rounded-end catch are reconstructed
from scan/photo evidence; their dimensions were NOT independently measured.
See validation.json for those estimated feature dimensions. Scan markers,
embossed text, and scan roughness are omitted. The outside is smooth.

FIT STATUS
This is a first fit print, not a confirmed working replacement. Main body
size follows calipers. Tab engagement, side-rail clearance, battery clearance,
and catch/release function require a physical fit check. The catch frame
approximates visible geometry; the original release flexure is not verified.
Do not force a binding cover. It is not appropriate to call the attachment
features an exact reproduction solely from these perspective photographs.

PRINTING
Import STL in millimeters,100% scale. Do not auto-scale it.
The STL is oriented broad face horizontal, inner features upward, bottom
at Z0. The curved exterior does not sit flat over its entire area:inspect
and enable supports beneath raised curved portions and tab overhangs as
needed. This is NOT a verified support-free design or pre-sliced project.
PETG is a reasonable starting material for functional clips. Use your known
PETG printer profile; a0.16 mm layer and3-4 walls are reasonable starting
settings for a0.4 mm nozzle. Check thin tab slot toolpaths. PLA can be used
for a dimensional trial but is more brittle at small engagement features.
Printer-specific toolpaths, bridging and support removal are untested.

CHECKS
Valid single CAD solid. STL:one watertight connected body, consistent winding,
positive volume, no detected self-intersecting faces. Nine main-shell
thickness probes confirm2.20 mm. These are geometric checks, not physical fit.

FILES
Hisense_EN2A27_Rebuilt_V3.stl:print geometry.
Hisense_EN2A27_Rebuilt_V3.step:editable CAD reference.
Hisense_EN2A27_Rebuilt_V3_CAD.png:four CAD views.
validation.json:dimensions, estimated features, mesh/thickness checks.

ADDITIONAL V3 FILES
Hisense_EN2A27_V3_Rail_Closeup.png:outside angle and top view of triangle.
rail_change_validation.json:continuous rail, no top bulge, outward tip checks.
