V2 NO-FEET UPDATE

Only the three OPTIONAL full-height rigid tracks changed: external
stabilizing feet are removed. The other five STLs are byte-for-byte
identical to the previous V2 kit. Internal bottom stops, fit offsets,
1.5mm protrusion and both TPU pads are unchanged. Short tracks already
had no added stabilizing feet.

Files retain their previous supplied print orientation. Geometric
overhang checks cover that orientation, not an independently verified
alternate flat orientation. No slicing or physical print is claimed.

V2 VOLTRA PAD TESTER — 1.50mm PROTRUSION (BOTH PARTS REVISED)

WHAT CHANGED
TPU protrusion above the surrounding hard face increases0.35 ->1.50mm.
The TPU contact surface stays at the same datum, so this does not tighten
the eventual Voltra opening. TPU thickness increases2.50 ->3.65mm, with
the additional1.15mm placed behind the contact face. The rigid face moves
back1.15mm and its track matches the deeper pad. The rear of the holder
also moves back1.15mm, retaining the original bulk wall thickness.

Both V2 TPU and V2 rigid parts are required. The old2.5mm pad is not the
right pad for this holder. Simply moving the hard face with the old pad
would reduce nominal capture to about0.61mm per edge at+0.15 clearance.
V2 retains the previous2.15mm buried depth and approximately1.53mm of
geometric capture per edge at that same clearance. It has no thin hook.

Front contact width60mm and rear dovetail width64mm are retained. The
contact skin remains1.2mm; the rear flex channels deepen1.30 ->2.45mm.
This preserves the thin contact skin while allowing more room to flex.
Actual softness, holding force, creep and fit still require this test.

PRINT FIRST: SHORT PAIR
Print TEST_V2_TPU_Pad_30mm_Protrusion_1p50mm.stl plus one short rigid
track. Choose the offset that fitted best in your previous test:
  CURRENT_plus_015 = current full-size V1 clearance, +0.15mm.
  LINE_TO_LINE_000 = zero CAD profile offset.
  INTERFERENCE_minus_010 = intentionally0.10mm interfering fit.
If unsure, start with CURRENT_plus_015. If too loose, try the tighter
tracks. Reuse the same V2 short TPU pad for all three trials. Keep tracks
identified externally; there are no embossed labels. Use hand force only.

ORIENTATION / MATERIAL
All STLs are millimeters and already oriented. Use100% scale and the same
rigid filament and TPU you intend for the full insert. Print the pad on
its flat contact face: it is3.65mm tall, with rear channels open upward.
Print rigid tracks bottom-down. Preserve orientation; arrange by moving
parts rather than auto-rotating. An optional brim is not a support.

CHECK
Slide the pad to its bottom stop. It should now stand1.5mm clear of the
rigid face, allowing noticeably more travel before hard contact. Check
the feel by pressing, then assess lift resistance by rubbing/pulling the
face upward. The track should slide by hand and remain deliberately
removable. There is no positive upward lock; friction must be tested.
Do not force a binding fit or globally scale the parts.

OPTIONAL: FULL-HEIGHT CONFIRMATION
The OPTIONAL_V2_TPU_Full_Height_Pad.stl has90mm engagement. Pair it with
the OPTIONAL_V2_RIGID_Full_Height_Track having your preferred offset.
External stabilizing feet have been removed from these tall tracks.
The internal bottom stops remain unchanged.
Only print the one matching track needed. Full-height friction can differ
substantially from the short30mm test.

SCOPE / VALIDATION
This update changes TESTERS ONLY. The existing full-insert STL and CAD
packages remain unchanged until protrusion and fit are confirmed. Do not
mix this deeper pad into the V1 full insert: its seats are not revised.
Before applying V2 to the complete insert, remaining wall/joint/pin-channel
clearances will need checks. Charger/stopper liners are not changed here.

All8 STLs passed watertight edges, consistent winding, positive volume,
bed placement, footprint and46degree geometric-overhang checks. Nominal
seating and sampled sliding clearances passed. Negative-offset trials
deliberately interfere and rely on TPU compression. Slicer toolpaths,
physical fit, softness and strength have not been verified for V2.
Reference STEP and CAD image show the+0.15mm short pair assembled.

Tell me which offset you used, whether the1.5mm protrusion feels right,
and whether the pad resists lifting before proceeding to full-insert V2.
