from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-protrusion-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
# Keep contact face atV0. Move the previous beveled rear engagement1.15mm
# rearward, retaining its geometry relative to the newly recessed hard face.
points=[(-30,0),(30,0),(30,1.15),(32,3.65),(-32,3.65),(-30,1.15)]
def profile():return cq.Workplane('XY').polyline(points).close()
def pad(height):
    p=profile().extrude(height).val()
    for x in np.arange(-22,25,8):p=p.cut(box(float(x)-2,1.2,5,4,2.45,height-10))
    return p
def holder(offset,height,stop):
    seat=profile().offset2D(offset).extrude(height-stop+.2).val().translate((0,0,stop))
    return box(-38,1.5,0,76,7.65,height).cut(seat)
def mesh_array(p):
    v,f=p.tessellate(.015,.05)
    return np.array([a.toTuple() for a in v])[np.array(f)]
def export(p,name):
    assert p.isValid() and len(p.Solids())==1,name
    assert p.exportStl(str(OUT/name),tolerance=.015,angularTolerance=.05,relative=False)
    a=mesh_array(p);norm=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(norm,axis=1)/2
    norm/=np.maximum(2*area,1e-14)[:,None]
    bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
    assert not ((norm[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)).any(),name
    assert abs(a[:,:,2].min())<1e-5
    print('Exported',name,flush=True)
p=pad(30)
export(p.rotate((0,0,0),(1,0,0),90).translate((32,30,0)), 'TEST_V2_TPU_Pad_30mm_Protrusion_1p50mm.stl')
for label,offset in [('CURRENT_plus_015',.15),('LINE_TO_LINE_000',0),('INTERFERENCE_minus_010',-.1)]:
    h=holder(offset,35,5)
    v=h.intersect(p.translate((0,0,5))).Volume()
    assert (v<1e-5 if offset>=0 else v>0),label
    export(h.translate((38,0,0)),f'TEST_V2_RIGID_Short_Track_{label}.stl')
fullpad=pad(90)
export(fullpad.rotate((0,0,0),(1,0,0),90).translate((32,90,0)), 'OPTIONAL_V2_TPU_Full_Height_Pad.stl')
for label,offset in [('CURRENT_plus_015',.15),('LINE_TO_LINE_000',0),('INTERFERENCE_minus_010',-.1)]:
    fullholder=holder(offset,100,10)
    if offset>=0:assert fullholder.intersect(fullpad.translate((0,0,10))).Volume()<1e-5
    export(fullholder.translate((38,0,0)), f'OPTIONAL_V2_RIGID_Full_Height_Track_{label}.stl')
support=holder(.15,35,5);seated=p.translate((0,0,5))
for dz in [0,1,10,35.2]:assert support.intersect(seated.translate((0,0,dz))).Volume()<1e-5
assert support.intersect(seated.translate((0,-1,0))).Volume()>0
assert support.intersect(seated.translate((0,0,-1))).Volume()>0
assembly=cq.Assembly(name='V2_1p5mm_protrusion_tester')
assembly.add(support,name='V2_rigid_holder',color=cq.Color(.56,.63,.67))
assembly.add(seated,name='V2_TPU_pad',color=cq.Color(1,.52,.12))
assembly.save(str(OUT/'V2_Protrusion_Tester_Reference.step'))
cut=box(-40,-1,18,80,13,6)
arrays={'rigid':mesh_array(support.intersect(cut)),'TPU':mesh_array(seated.intersect(cut))}
np.savez_compressed(OUT/'cross_section.npz',**arrays)
np.savez_compressed(OUT/'assembled.npz',rigid=mesh_array(support),TPU=mesh_array(seated))
np.savez_compressed(OUT/'exploded.npz',rigid=mesh_array(support),TPU=mesh_array(seated.translate((0,0,40))))
# Exact right dovetail edge in cross section, not a drawn approximation.
cut=box(26,-.1,18,12,9.5,6)
np.savez_compressed(OUT/'edge_detail.npz',rigid=mesh_array(support.intersect(cut)),TPU=mesh_array(seated.intersect(cut)))
capture_old_at_035=32-(30+.8*.35+.15*math.sqrt(1+.8**2))
capture_old_at_150=32-(30+.8*1.5+.15*math.sqrt(1+.8**2))
capture_v2=32-(30+.8*(1.5-1.15)+.15*math.sqrt(1+.8**2))
assert abs(capture_v2-capture_old_at_035)<1e-9
report={'scope':'V2 testers with stabilizing feet removed; internal stops unchanged; full insert unchanged',
 'protrusion_before_mm':.35,'protrusion_after_mm':1.5,
 'TPU_thickness_before_mm':2.5,'TPU_thickness_after_mm':3.65,
 'unchanged_contact_face_datum':0,'contact_width_mm':60,'rear_width_mm':64,
 'contact_skin_thickness_mm':1.2,'back_relief_depth_before_mm':1.3,'back_relief_depth_after_mm':2.45,
 'buried_depth_before_and_after_mm':2.15,
 'nominal_capture_per_edge_at_current_offset_mm':capture_v2,
 'capture_if_old_pad_were_reused_mm':capture_old_at_150,
 'profiles_tested_mm':[.15,0,-.1],
 'valid_single_solid_and_overhang_check':'Passed for all8 STLs',
 'nominal_seated_overlap_mm3':0,'sampled_vertical_motion_clear':True,
 'normal_pullout_blocked':True,'bottom_stop_blocks_downward_motion':True,
 'upward_lock':'None; friction/creep must be physically tested',
 'slicer_verified':False,'physical_fit_verified':False,
 'compatibility':'Both V2 rigid holder and V2 TPU pad required; not a drop-in V1 replacement'}
(OUT/'cad_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
