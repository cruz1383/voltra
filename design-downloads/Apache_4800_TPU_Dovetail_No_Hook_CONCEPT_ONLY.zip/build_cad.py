"""Hook-free dovetail pad detail for review, not a verified interference fit."""
from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-dovetail-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
# Broad continuous bevels: rear width64, front width60, thickness2.5.
# No cantilever, hook, clip or projecting release tab.
points=[(-30,0),(30,0),(32,2.5),(-32,2.5)]
def profile():return cq.Workplane('XY').polyline(points).close()
pad=profile().extrude(90).val().translate((0,0,5))
# Leave solid5mm borders so rear flex channels do not weaken the rails.
for x in [-20,-12,-4,4,12,20]:
    pad=pad.cut(box(x-2,1.2,10,4,1.3,80))
# Positive running clearance here illustrates geometry only. Interference /
# friction needed for upward retention must be established on a printed sample.
track=profile().offset2D(.15).extrude(96).val().translate((0,0,5))
support=box(-38,0,0,76,8,100).cut(track)
assert pad.isValid() and len(pad.Solids())==1
assert support.isValid() and len(support.Solids())==1
assert pad.intersect(support).Volume()<1e-5
for dz in [0,1,5,20,50,90,101]:
    assert pad.translate((0,0,dz)).intersect(support).Volume()<1e-5
assert pad.translate((0,0,-1)).intersect(support).Volume()>0
assert pad.translate((0,-1,0)).intersect(support).Volume()>0
assembly=cq.Assembly(name='NO_HOOK_DOVETAIL_PAD_CONCEPT')
assembly.add(support,name='Rigid_dovetail_track_with_bottom_stop',color=cq.Color(.56,.63,.67))
assembly.add(pad,name='TPU_pad_no_hook',color=cq.Color(1,.52,.12))
assembly.save(str(OUT/'Voltra_TPU_Dovetail_No_Hook_CONCEPT_ONLY.step'))
def arrays(name,shapes):
    result={}
    for label,p in shapes.items():
        v,f=p.tessellate(.02,.08)
        result[label]=np.array([a.toTuple() for a in v])[np.array(f)]
    np.savez_compressed(OUT/(name+'.npz'),**result)
arrays('assembled',{'rigid':support,'TPU':pad})
arrays('exploded',{'rigid':support,'TPU':pad.translate((0,0,110))})
cut=box(-40,-1,44,80,11,7)
arrays('cross_section',{'rigid':support.intersect(cut),'TPU':pad.intersect(cut)})
# Enlarged actual right-side rail, showing the broad bevel under the lip.
cut=box(25,-1,44,14,10,9)
arrays('rail_detail',{'rigid':support.intersect(cut),'TPU':pad.intersect(cut)})
(OUT/'validation.json').write_text(json.dumps({
 'stage':'Separate hook-free pad/track concept; not integrated into full insert',
 'valid_single_solid_components':2,'hook_or_snap_tab_present':False,
 'pad_rear_width_mm':64,'pad_front_width_mm':60,'thickness_mm':2.5,
 'pad_height_mm':90,'bottom_stop_height_mm':5,
 'illustrative_positive_profile_offset_mm':.15,
 'assembled_overlap_mm3':0,'sampled_vertical_sliding_clear':True,
 'bottom_stop_blocks_downward_motion':True,'dovetail_blocks_normal_pullout':True,
 'upward_positive_lock':False,
 'upward_retention':'Requires tested friction/interference; positive illustrative clearance does not establish a snug fit',
 'pending':['Printed track-fit coupon','Insertion and removal force','Wear and TPU creep',
 'Integration with first-contact setback, walls, joints and pin channels'],
 'accessory_retention':'Unchanged; previous accessory lip and wall-snap concept retained'},indent=2))
print('Saved hook-free CAD; sliding, stop and transverse-capture checks passed')
