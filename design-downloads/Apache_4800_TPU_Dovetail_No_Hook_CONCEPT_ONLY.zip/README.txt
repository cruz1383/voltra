VOLTRA TPU PAD — BROAD DOVETAILS, NO HOOK (CAD CONCEPT ONLY)

The previous small cantilever latch is removed entirely. The pad has broad,
continuous dovetail edges on both sides and slides down from an open top.
A5mm bottom stop establishes seating height. Nominal pad dimensions:
64mm rear width,60mm front width,2.5mm thickness,90mm height. Back relief
retains1.2mm contact skin with1.3mm flex space and solid rail borders.

The dovetails capture the pad against pulling away from the rigid wall.
They do NOT positively lock upward motion. Upward retention is intended
to use a snug TPU fit, which requires a printed fit sample to determine
interference, insertion force, lifting resistance and wear. This geometry
uses a positive0.15mm profile offset for clear illustration; it does not
demonstrate a friction fit or establish that lifting the Voltra leaves the
pad in place. A separate keeper would be needed if a tested fit cannot
provide sufficient upward retention.

This is a separate pad/track detail, NOT integrated into the complete
Apache insert and NOT a printable release. The accessory liner locating
lip and flexible wall snaps are unchanged from the previous concept.
Existing downloads are preserved; this does not supersede complete-insert
files. Final integration must check first-contact setback, local wall
thickness, joints, pin-channel clearances and removal access.

CHECKS
Both components are valid single CAD solids with zero seated overlap.
Vertical sliding is clear at sampled offsets. The bottom stop blocks
downward motion; both dovetail lips block transverse pullout in rigid-body
CAD checks. TPU strain, fatigue, creep and holding force are untested.

FILES
Colored STEP, two PNG CAD views, validation.json and Python source.
Images are rendered from actual CAD geometry, not generated illustrations.
Dependencies: CadQuery2.6.1, NumPy, Pillow, Matplotlib.
No printable STL is supplied at this concept-review stage.
