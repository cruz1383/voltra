APACHE 4800 / VOLTRA — TPU CONTACT CONCEPT, REVIEW ONLY

Orange = separate TPU pieces. Gray = revised rigid supports.
Open TPU_Concept_Assembly.png, TPU_Concept_Top_View.png and
TPU_Pad_Seat_Cutaway.png. Images are renders of actual CAD, not generated
product illustrations. STEP assemblies retain separate colored components.

CONCEPT
Five replaceable pads around each Voltra: four long-wall contact areas and
one screen-end area, with 2.5 mm seats and back-side relief for flexibility.
The pads avoid the shim-pin channels and finger-access scallops. Voltras
still rest on the retained original bottom cushion, with no TPU or rigid
floor added under either device.

Both charger compartments and both stopper cradles receive 1.5 mm side
liners recessed outward into the rigid walls, plus 2 mm floor mats placed
on the existing floors. The removable charger mats cover the existing
recessed logos; logos are not replaced in this concept. Carabiner slots
remain rigid and unlined. The revised outside air-valve relief is retained.

FIT AND TRADEOFFS
Voltra-pad faces show the existing tested opening datum. This placement
study uses flush nominal interfaces. Before a printable release, the
surrounding hard walls need a small setback or pads need a controlled
proud offset, with the seats adjusted to preserve clearance, so that the
TPU contacts first. As shown, flush pads alone do not guarantee isolation
from all adjacent rigid surfaces. Final pad retention and printer-fit
clearances have not been designed. No clips or interference fit are proven.

Accessory mats raise the charger floor from Z30 to Z32 and stopper floor
from Z55 to Z57. The larger previously modeled charger/cable stack has only
1.14 mm nominal remaining top clearance instead of 3.14 mm. Packing and lid
clearance need a physical test; the floor thickness can be revised.

TPU 95A is a starting material, not a measured cushioning specification.
1.2 mm contact skin and 1.3 mm relieved backing are shown in device pads.
The cutaway illustrates room for flex; actual softness depends on material,
print orientation, walls, geometry and the final retention arrangement.

VALIDATION SCOPE
All four rigid sections and all fourteen TPU components are valid single
CAD solids. This is a concept, not a print-ready replacement. Remaining
local wall/web thickness, joint clearance, accessory packing, pad retention,
equipment contact, cushioning and physical fit require further checks.
There are deliberately no printable STLs in this review package. Keep using
the earlier valve-relief files until a finished TPU-compatible release is
developed and tested. No drop-protection rating is established.

CONTENTS
Colored STEP assembly, enlarged pad-seat STEP detail, three PNG CAD views,
concept_notes.json and Python generation/render source for traceability.
Generators use Python 3.12 / CadQuery 2.6.1, NumPy, Pillow and Matplotlib,
and reference the prior V4/valve-relief workspace directories. Those source
designs remain available as separate downloads in the same repository.
