"""Recessed handle-contact band; charger-space tradeoff concept, not print release."""
from pathlib import Path
import os,json,math
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-handle-band-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
SRC=ROOT.parent/'tpu-full-v3p1/review'
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,z,h):return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((0,0,z))
def wire_rr(l,w,r):return next(f for f in rr(l,w,r,0,1).Faces() if f.normalAt().z<-.99).outerWire()
def flare(l,w,r,z):return cq.Solid.makeLoft([wire_rr(l,w,r).translate((0,0,z)),wire_rr(l+2,w+2,r+1).translate((0,0,z+1))],True)
def prism_yz(points,x,length):
    v=[cq.Vector(x,y,z) for y,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(v+[v[0]]),[],cq.Vector(length,0,0))
rigid={n:cq.Shape.importBrep(str(SRC/f'rigid_{n}.brep')) for n in ['BL','BR','TL','TR']}
old_TR=rigid['TR']
# Fill only the old charger-seat region, not any device opening, joint or slot.
# This rectangular region is within the original case envelope and ends below
# the lowest carabiner slot. The floor artwork belowZ30 is retained.
filler=box(131,25,30,94,76,70)
tr=old_TR.fuse(filler,tol=1e-4)
print('Old charger region restored for new wall position',flush=True)
L,W,R,floor,cx,cy=87.,73.,4.,30.,178.25,68.5
outer_y=W/2+1.5
outer=rr(L+3,W+3,R+1.5,30,70).fuse(flare(L+3,W+3,R+1.5,98),rr(L+5,W+5,R+2.5,99,1))
cup=outer.cut(rr(L,W,R,32,71))
seat=rr(L+3.3,W+3.3,R+1.65,30,70.2).fuse(flare(L+3.3,W+3.3,R+1.65,97.85),rr(L+5.3,W+5.3,R+2.65,98.85,1.35))
for d in [1,-1]:
    for x in [-3.3,2.7]:cup=cup.cut(box(x,outer_y-1.6 if d>0 else -outer_y-1.2,86,.6,2.8,14.2))
    hook=prism_yz([(outer_y,91),(outer_y+1,94),(outer_y+1,95.5),(outer_y,96.5)],-2.7,5.4)
    receiver=prism_yz([(outer_y-.05,90),(outer_y+1.4,90),(outer_y+1.4,95.4),(outer_y-.05,96.85)],-3.6,7.2)
    if d<0:hook=hook.mirror('XZ');receiver=receiver.mirror('XZ')
    cup=cup.fuse(hook);seat=seat.fuse(receiver)
cup=cup.translate((cx,cy,0));seat=seat.translate((cx,cy,0))
tr=tr.cut(seat,tol=1e-4)
# Model the contact band from the actual handle-end cavity profile, not a
# guessed handle replica. Contact follows original profile+0.7mm, giving
#0.8mm protrusion from the existing1.5mm hard-face setback.
base=(cq.Workplane('XY').box(333,108.22,1,centered=(True,True,False))
      .translate((-452.025/2+24+329/2,81,0)).edges('|Z and >X').fillet(15).edges('|Z and <X').fillet(2).val())
wire=next(f for f in base.Faces() if f.normalAt().z<-.99).outerWire()
def profile(offset):return cq.Workplane('XY').add(wire).toPending().offset2D(offset).val()
def region(offset,z,h):
    return cq.Workplane('XY').add(wire).toPending().offset2D(offset).extrude(h).val().translate((0,0,z))
def taper(a,b,z0,z1):return cq.Solid.makeLoft([profile(a).translate((0,0,z0)),profile(b).translate((0,0,z1))],True)
# Straight 74 mm contact pad entirely within the flat handle-end wall.
# Rounded YZ outline; front X129.6875, rear X131.3375.
def yzpad(x,depth,z=41.5,h=32.2,length=74,radius=3):
    def outline(l,at):
        shape=cq.Workplane('YZ').box(l,h,1,centered=(True,True,False))
        if radius:shape=shape.edges('|X').fillet(radius)
        shape=shape.val()
        return next(f for f in shape.Faces() if f.normalAt().x<-.99).outerWire().translate((at,81,z+h/2))
    return cq.Solid.makeLoft([outline(length-3,x),outline(length,x+depth)],True)
band=yzpad(129.6875,1.65)
# 45 degree rear top bevel, matching the fixed sloped capture roof.
wedge=prism_yz([(0,72.85),(0,74),(160,74),(160,72.85)],131.3375,1)
# Bevel with XZ triangle extruded along Y.
def wedge_xz(points,y,length):
    v=[cq.Vector(x,y,z) for x,z in points]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(v+[v[0]]),[],cq.Vector(0,length,0))
band=band.cut(wedge_xz([(130.4875,73.7),(131.3375,72.85),(131.3375,74.5),(130.4875,74.5)],0,160))
recess=yzpad(129.6875,1.8,z=41.5,h=32.5,length=74.7,radius=0)
recess=recess.cut(wedge_xz([(130.4875,74),(131.4875,73),(131.4875,75),(130.4875,75)],0,160))
tr=tr.cut(recess,tol=1e-4)
for name,p in [('TR',tr),('new_liner',cup),('handle_band',band)]:
    assert p.isValid() and len(p.Solids())==1,name
assert tr.intersect(cup).Volume()<1e-5
assert tr.intersect(band).Volume()<1e-5
assert cup.intersect(band).Volume()<1e-5
assert tr.intersect(band.translate((0,0,.2))).Volume()<1e-5
assert tr.intersect(band.translate((0,0,.6))).Volume()>1e-5
assert tr.intersect(band.translate((0,0,-.5))).Volume()>1e-5
assert tr.intersect(band.translate((-.5,0,0))).Volume()>1e-5
print('Compact band seats and is geometrically captured',flush=True)
# Mirror only the CHANGE into BL. Other BL details (including valve/joints)
# remain untouched, since only this isolated corner region is re-cut.
f2=filler.rotate((0,0,0),(0,0,1),180)
s2=seat.rotate((0,0,0),(0,0,1),180);r2=recess.rotate((0,0,0),(0,0,1),180)
bl=rigid['BL'].fuse(f2,tol=1e-4).cut(s2,tol=1e-4).cut(r2,tol=1e-4)
assert bl.isValid() and len(bl.Solids())==1
rigid['TR']=tr;rigid['BL']=bl
for p in rigid.values():
    assert p.intersect(band).Volume()<1e-5
    assert p.intersect(band.rotate((0,0,0),(0,0,1),180)).Volume()<1e-5
for name,p in [('Upper_Handle_Band',band),('Lower_Handle_Band',band.rotate((0,0,0),(0,0,1),180)),
               ('Upper_Charger_Liner',cup),('Lower_Charger_Liner',cup.rotate((0,0,0),(0,0,1),180))]:
    cq.exporters.export(p,str(OUT/(name+'_CONCEPT.step')))
parts={'rigid_'+n:p for n,p in rigid.items()}
for path in SRC.glob('TPU_*.brep'):
    if 'charger_TPU_liner' in path.name:continue
    parts[path.stem]=cq.Shape.importBrep(str(path))
parts.update({'TPU_upper_band':band,'TPU_lower_band':band.rotate((0,0,0),(0,0,1),180),
 'TPU_upper_charger':cup,'TPU_lower_charger':cup.rotate((0,0,0),(0,0,1),180)})
assembly=cq.Assembly(name='COMPACT_RECESSED_HANDLE_BAND_CONCEPT')
for n,p in parts.items():assembly.add(p,name=n,color=cq.Color(1,.52,.12) if n.startswith('TPU') else cq.Color(.56,.63,.67))
assembly.save(str(OUT/'Expanded_Charger_Straight_Pad_Assembly_CONCEPT.step'))
def mesh(p):
    v,f=p.tessellate(.02,.06)
    return np.array([a.toTuple() for a in v])[np.array(f)]
def arrays(name,ps):np.savez_compressed(OUT/(name+'.npz'),**{n:mesh(p) for n,p in ps.items()})
context=box(100,20,10,125,123,91)
arrays('context',{'rigid':tr.intersect(context),'TPU_band':band,'TPU_cup':cup})
arrays('exploded',{'rigid':tr.intersect(context),'TPU_band':band.translate((-15,0,0)),'TPU_cup':cup.translate((0,0,18))})
cut=box(126,55,39,12,10,37)
arrays('band_section',{'rigid':tr.intersect(cut),'TPU_band':band.intersect(cut),'TPU_cup':cup.intersect(cut)})
arrays('top_view',{'rigid':tr.intersect(context),'TPU_band':band,'TPU_cup':cup})
# Check the prior measured charger and both cable envelopes against the new
# opening, using the revised center. The larger bundle retains1.14mm top gap.
void=rr(L,W,R,32,68).translate((cx,cy,0))
for name,l,w,h,z in [('charger',75.91,60.12,28.86,32),('current_bundle',85.47,40.92,11.15,63.86),('larger_bundle',85.5,57,35,63.86)]:
    obj=box(cx-l/2,cy-w/2,z,l,w,h)
    assert obj.cut(void).Volume()<1e-5,name
print('Charger and recorded cable envelopes fit expanded87x73 opening',flush=True)
audit={}
for n,p in [('rigid_TR',tr),('rigid_BL',bl),('TPU_pad_contact_face_down',band.rotate((0,0,0),(0,1,0),-90).translate((0,0,-129.6875))),('TPU_cup_upright',cup.translate((0,0,-30)))]:
    a=mesh(p);normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);area=np.linalg.norm(normal,axis=1)/2
    normal/=np.maximum(2*area,1e-14)[:,None]
    bed=np.max(np.abs(a[:,:,2]),axis=1)<1e-4
    bad=(normal[:,2]<-math.sin(math.radians(46)))&(~bed)&(area>1e-7)
    value=float(area[bad].sum());assert value<1e-4,(n,value)
    audit[n]={'overhang_area_beyond_46deg_mm2':value}
report={'stage':'CAD concept only; existing print downloads unchanged',
 'handle_measurements':{'top_below_rim_mm':28.7,'Z_thickness_mm':28.11,'bottom_below_rim_mm':56.81},
 'handle_band':{'Z_min_mm':41.5,'Z_front_top_mm':73.7,'front_height_mm':32.2,
 'contact_Z_band_below_rim_mm':[26.3,58.5],'front_length_mm':71,'rear_length_mm':74,'thickness_mm':1.65,'projection_mm':.8,
 'buried_depth_mm':.85,'roof_clearance_mm':.3,'top_roof_slope_deg':45,
 'retention':'Wider rear dovetail ends and fixed top/bottom recess stops; no tabs or rim bridge'},
 'charger_opening_before_mm':[87,65],'charger_opening_after_mm':[87,73],
 'charger_shift_away_from_handle_mm':.75,'charger_extension_toward_carabiners_from_previous_concept_mm':8,
 'charger_outer_X_edge_unchanged':False,'top_of_parts_Z_max_mm':100,
 'remaining_shared_wall_mm':{'behind_band':1.6125,'outside_band_body':2.6125,'top_lip':1.6125,'outer_case_wall_at_lip':1.6125,'carabiner_divider_at_lip':5.35},
 'recorded_charger_and_cable_envelopes_fit':True,'larger_bundle_length_clearance_total_mm':1.5,
 'larger_bundle_top_clearance_mm':1.14,'no_seated_overlaps_mm3':0,
 'geometric_up_down_front_capture_checks_passed':True,'geometry_overhang_audit':audit,
 'physical_handle_fit_verified':False,'slicer_verified':False,
 'pending':['Exact handle contact during transport','Straight pad insertion/removal force and retention',
 'Actual cable packing in enlarged cavity','Full-size wall strength','Print verification']}
(OUT/'validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
