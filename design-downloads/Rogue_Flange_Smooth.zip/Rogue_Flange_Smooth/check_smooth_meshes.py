from pathlib import Path
import struct,json,numpy as np
O=Path('/workspace/designs/output/Rogue_Flange_Smooth')
reports={}
for p in sorted(O.glob('PRINT_SMOOTH*.stl')):
 raw=p.read_bytes();n=struct.unpack_from('<I',raw,80)[0];assert len(raw)==84+50*n
 dt=np.dtype([('norm','<f4',(3,)),('v','<f4',(3,3)),('attr','<u2')]);a=np.frombuffer(raw,dt,count=n,offset=84)['v'].astype(np.float64)
 pts,inv=np.unique(np.round(a.reshape(-1,3),5),axis=0,return_inverse=True);ids=inv.reshape(-1,3)
 assert np.all(ids[:,0]!=ids[:,1]) and np.all(ids[:,1]!=ids[:,2]) and np.all(ids[:,0]!=ids[:,2]),('degenerate after welding',p.name)
 edges=np.concatenate([ids[:,[0,1]],ids[:,[1,2]],ids[:,[2,0]]]);sort=np.sort(edges,axis=1)
 unique,indices,counts=np.unique(sort,axis=0,return_inverse=True,return_counts=True)
 assert np.all(counts==2),(p.name,'open/nonmanifold edges',int(np.sum(counts!=2)))
 signs=np.where(edges[:,0]<edges[:,1],1,-1);balance=np.bincount(indices,weights=signs)
 assert np.all(balance==0),(p.name,'winding')
 vol=float(np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])).sum()/6);assert vol>0
 assert abs(a[:,:,2].min())<1e-5 and abs(a[:,:,2].max()-32)<1e-5
 r=np.linalg.norm(a[:,:,:2],axis=2);mask=(a[:,:,2].mean(1)>20)&(a[:,:,2].mean(1)<29)&(r.min(1)>25)
 angles=np.unwrap(np.arctan2(a[mask,:,1],a[mask,:,0]),axis=1);w=np.ptp(angles,axis=1)*180/np.pi
 reports[p.name]={'triangles':n,'watertight':True,'consistent_winding':True,'volume_mm3':vol,'base_z_mm':float(a[:,:,2].min()),'top_z_mm':float(a[:,:,2].max()),'slope_facet_angular_width_median_degrees':float(np.median(w)),'slope_facet_angular_width_max_degrees':float(w.max())}
 print(p.name,reports[p.name],flush=True)
(O/'mesh_validation.json').write_text(json.dumps(reports,indent=2))
