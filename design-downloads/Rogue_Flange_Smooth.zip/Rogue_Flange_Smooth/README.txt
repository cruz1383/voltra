ROGUE FLANGE — SMOOTH MESH EXPORTS FOR X1 CARBON
These are the same revised CAD flanges with45.14,45.64 and46.10 straight fitting sockets. Only STL tessellation changes; no overall scaling or dimensional redesign. Physical fit and print finish remain untested.

WHY
The original uploaded STL has angular spans up to approximately11.25 degrees in individual sloped-surface triangles, with a median near5.625 degrees. The previous revised STL still had spans near5.625 degrees. This can produce visible polygon bands on a conical surface.
The previous CadQuery exporter used size-relative tessellation, allowing larger edges to be coarsely approximated. These files use absolute linear deflection0.005mm, angular deflection0.02rad, relative=False. Actual mesh measurements are recorded separately. This improves the mesh approximation; it does not guarantee elimination of all physical ripple, seam, extrusion or motion artifacts.

FILES
PRINT_SMOOTH_Rogue_Flange_Socket_45p14.stl: primary close-fit trial for44.74 handle,0.40 nominal diametral clearance.
45p64 and46p10: matching looser alternatives.
Small fit rings are included here. Detailed dimensional notes and the original modification source are also supplied inRogue_Flange_Handle_Fit.zip. Continue to print test rings before choosing the full flange. Revised STEP files are included here and in that package and can also be imported directly into Bambu Studio if supported by your version.
These are alternatives to the previous PRINT_Rogue_Flange files, not extra components. Print only one selected flange. Flat base down, socket up.

X1 CARBON STARTING CHECKS
Assuming standard0.4 nozzle: start with Bambu Studio's matching printer/nozzle profile and0.16mm High Quality process. Use the correct material profile. User filament: Kexcelled3D Cherry Red PLA. Start with Generic PLA (not Bambu PLA Basic unless you have calibrated it for this filament), and keep temperature within the spool manufacturer's range. Use Normal speed mode for this comparison. Ventilate the chamber by opening the door or lid if it becomes warm during PLA printing; do not enclose PLA in a hot chamber merely to chase surface finish.
Set seam position to Aligned rather than Random, and paint a single less-visible seam location if practical. This localizes starts/stops; it does not remove them. A cluster of rough marks inside holes may be seam/pressure behavior, but a photo alone cannot prove the cause.
Run applicable flow dynamics/flow rate calibration for the actual filament and use those results. Do not invent a K factor or change flow percentage from a photo. Check that the correct nozzle and filament are selected and use a clean, unobstructed nozzle. Start at the profile's normal speed; if periodic bands remain in a new print, compare outer-wall speeds with a short test rather than assuming slower is always better on a CoreXY printer.
Ordinary horizontal layer lines remain visible with FDM. Finer mesh addresses geometric faceting; lower layer height addresses vertical stair stepping; seam calibration addresses starts/stops. These are separate effects.

VALIDATION
Each source CAD shape is a valid single solid. STL meshes checked for manifold edges, consistent winding, positive volume, baseZ0, height32. Slope facet angular spans measured against previous STL. See mesh and export reports.
No physical print has been made from these files. Neither smoothness nor final socket fit has been verified on the X1 Carbon.
