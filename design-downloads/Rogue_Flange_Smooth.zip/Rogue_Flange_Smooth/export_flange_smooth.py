from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import os, json, time
os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
ROOT=Path(__file__).resolve().parent
if not (ROOT/'Rogue_Flange_Socket_45p14.step').exists():ROOT=Path('/workspace/designs/output/Rogue_Flange_Handle_Fit')
OUT=Path('/workspace/designs/output/Rogue_Flange_Smooth');OUT.mkdir(exist_ok=True)
def export_one(tag):
 import cadquery as c
 started=time.time();s=c.importers.importStep(str(ROOT/('Rogue_Flange_Socket_'+tag+'.step'))).val()
 assert s.isValid() and len(s.Solids())==1
 path=OUT/('PRINT_SMOOTH_Rogue_Flange_Socket_'+tag+'.stl')
 ok=s.exportStl(str(path),tolerance=.005,angularTolerance=.02,relative=False,parallel=False)
 assert ok and path.exists()
 return {'socket':tag,'seconds':time.time()-started,'bytes':path.stat().st_size,'absolute_deflection_mm':.005,'angular_tolerance_rad':.02,'relative':False}
if __name__=='__main__':
 with ProcessPoolExecutor(max_workers=2) as pool:
  results=[]
  for r in pool.map(export_one,['45p14','45p64','46p10']):
   results.append(r);print(r,flush=True)
 (OUT/'export_settings.json').write_text(json.dumps(results,indent=2))
