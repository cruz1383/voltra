APACHE4800 — FULL V3 PRINT PACKAGE, CAPTURED TPU PADS /1.5mm PROTRUSION

THIS IS THE FULL-SIZE REVISION USING THE SUCCESSFUL MINI V3 MECHANISM.
No additional testers or alternative fit variants are included.
There are8 UNIQUE STL files. Print the quantities below for18 total parts.
The miniature mechanism was physically tested by the user. The complete
full-size assembly has geometric validation but has not been physically
printed/loaded or sliced in a printer-specific profile in this workspace.

PRINT QUANTITIES
Rigid/PRINT_BL.stl:1
Rigid/PRINT_BR.stl:1
Rigid/PRINT_TL.stl:1
Rigid/PRINT_TR.stl:1
TPU/PRINT_Side_Pad_60mm_QTY8.stl:8
TPU/PRINT_End_Pad_50mm_QTY2.stl:2
TPU/PRINT_Charger_Liner_QTY2.stl:2
TPU/PRINT_Stopper_Liner_QTY2.stl:2
Each repeated TPU group is byte-identical in the validated source STLs.
Do not print just one of each file and assume the assembly is complete.
The accessory liners are unchanged from the preceding full TPU STL kit;
you may reuse successful existing charger/stopper TPU liners of that design.

MATERIAL / ORIENTATION
Use the rigid filament and TPU settings that produced your successful
test, or account for fit differences if changing filament. TPU95A was the
starting recommendation. Units are millimeters; import at100% scale.
Parts are already oriented: rigid sections bottom-down, liners upright
on their floors, and Voltra pads flat on their contact faces. Translate /
arrange them on the bed without auto-orienting. Do not scale for clearance.
Pads print3.65mm tall with the rear flex grooves upward; their beveled
top end must remain intact. Full rigid footprints fit the256mm X1C bed
with5mm brim allowance by dimensions. Check exclusion/calibration zones.

The geometry is designed to print without supports in these orientations:
fixed pad top-stop undersides and accessory lip/pocket roofs slope45deg,
dovetails grow2mm over2.5mm, and the valve recess has a peaked roof.
All18 exported component meshes passed the46degree overhang audit
(small tessellation tolerance around45deg). Mesh checks do not establish
actual material sag or slicer toolpaths. Check your own slice preview.
No G-code or material/printer profile is supplied.

PRINT ORDER TO AVOID A WHOLE-BATCH FIT LOSS
Start with BL plus2 side pads and1 charger liner. Confirm the larger pad
flexes in, is captured by both stops, and can be deliberately removed.
Then print the remaining3 rigid sections and remaining TPU quantities.
This is a first full-size part, not another miniature tester.

RIGID ASSEMBLY
Use all four new V3 rigid sections; previous rigid versions do not have
these matching closed tracks and deeper pad seats. Layout:
 TL | TR
 ---+---
 BL | BR
Assemble BL,then BR,then TL,then TR using the existing vertical joints.
Retain original bottom cushion and lid foam. Install TPU after the rigid
frame is together. Stopper liners span the horizontal seam.

V3 PAD INSTALLATION
The pad contact face stands1.5mm ahead of adjacent hard material; thickness
is3.65mm and contact skin1.2mm. The bottom is flat; the TOP END IS BEVELED.
Put the beveled end under the fixed sloped top stop and flex the pad into
the dovetail sides and bottom stop, as you did with the successful mini.
Make sure both ends and both side edges are seated. Do not attempt to slide
the pad rigidly through the now-closed top. Removal requires deliberate
flexing; there are no thin hooks, screws, removable keepers or support feet.
Pad front height86.7mm, bottomZ10, topZ96.7:3.3mm below the insert rim.
The top bevel has0.3mm vertical roof clearance and the same+0.15mm profile
allowance as the successful mini. Full-size flex force can differ from
the small coupon. Stops/geometry, not friction alone, now retain the pads.

PAD / LINER POSITIONS
All8 side pads are identical and all2 end pads are identical. The contact
face is smooth; rear relief grooves face into the rigid track. Orient the
top bevel upward in every location. Refer to the assembled CAD image.
TL:2 side pads and1 end pad. TR:2 side pads and1 charger liner.
BL:2 side pads and1 charger liner. BR:2 side pads and1 end pad.
One stopper liner at each side of the horizontal center seam.
Accessory liners use the existing beveled locating lips and sloped wall
detents. Their floors are2mm thick; flex walls inward for deliberate release.

PRESERVED FEATURES / PRACTICAL CHECKS
Case footprint, joints, bare carabiner slots, removed finger scallops,
enlarged8mm pin channels with10mm top entries, and valve clearance remain.
Pin depth3mm is referenced to the TPU contact datum; hard walls are now
set back1.5mm from that datum. Confirm the sleeved pins pass without taking
device weight. Voltras should rest on the original bottom foam.
Stopper opening remains62.97 x43.27mm. Accessory mats cover the charger
logos and raise floors2mm; larger modeled cable packing has1.14mm spare
height. Check real packing and lid closure gently.

The shared stopper/device wall is nominally2.105mm through its straight
body and locally1.105mm beside the upper locating-lip recess. These values
are recorded for review; local wall strength is not physically validated.
Do not force a binding cup or device. The full-size assembly's retention
force, creep, fatigue, loaded-case fit and drop protection are untested.

VALIDATION / CONTENTS
All18 CAD solids valid, no seated rigid/TPU overlap, no rigid overlap;
all10 pads hit their top/bottom stops in rigid-body movement checks.
Sampled rigid assembly motion, sleeved-pin and valve envelopes clear.
All18 source STLs watertight, consistently wound, positive volume, on-bed,
and within bed footprint; overhang geometry audit passed.
Reference/ contains the full colored STEP and CAD/print-orientation images.
Do not print the assembled reference STEP as a merged object.
Reports, quantities, source mapping, source scripts and hashes are included.
The STEP preserves all18 assembly instances; STLs are deduplicated to8 files.
