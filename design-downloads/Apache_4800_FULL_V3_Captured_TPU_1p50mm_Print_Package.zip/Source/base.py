"""Review-only TPU contact concept built on the valve-relieved V4 CAD."""
from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-tpu-cache')
os.environ.setdefault('MPLCONFIGDIR','/tmp/voltra-tpu-mpl')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
SOURCE=ROOT.parent/'valve-clearance/source-v4'
VALVE=ROOT.parent/'valve-clearance/revised'
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,x,y,z,h):
    return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((x,y,z))
rigid={}
for name in ['BL','BR','TL','TR']:
    path=VALVE/f'Insert_{name}_Valve_Relief.step' if name in ['BL','BR'] else SOURCE/f'Insert_{name}.step'
    rigid[name]=cq.importers.importStep(str(path)).val()
# Restore only the two obsolete stopper finger notches. Maintain the original
# 0.30 mm section seam and original capsule opening at Z55-100.
for side in [1,-1]:
    sx=-side*150
    capsule=rr(62.97,43.27,21.625,sx,0,55,45)
    # Overlap the old cut by .25 mm inside existing rigid material to avoid
    # coincident cylindrical faces in the union. Exterior result is identical.
    notch=cq.Solid.makeCylinder(8.25,45.1,cq.Vector(sx-side*62.97/2,0,54.9))
    fill=notch
    for name in (['BL','TL'] if side>0 else ['BR','TR']):
        sy=-1 if name.startswith('B') else 1
        clip=box(-230,-165 if sy<0 else .15,54.9,460,164.85,45.1)
        patch=fill.intersect(clip)
        print('Restoring notch',name,flush=True)
        rigid[name]=rigid[name].fuse(patch,tol=1e-4)
        print('Fused',name,flush=True)
        rigid[name]=rigid[name].cut(capsule,tol=1e-4)
        print('Re-cut capsule',name,flush=True)
        # Keep valid split faces; OCC face unification stalls on this STEP.
        print('Notch restored',name,flush=True)
        assert rigid[name].isValid() and len(rigid[name].Solids())==1
print('Imported V4 and removed only the stopper finger reliefs',flush=True)
# Remove the two unused Voltra finger scallops with overlapping restoration
# stock, then re-cut the exact R15/R2 device opening and larger pin channels.
channel_tools=[]
channel_locations=[]
for side in [1,-1]:
    cx=side*(-452.025/2+24+329/2); yc=side*81
    wp=cq.Workplane('XY').box(333,108.22,100,centered=(True,True,False)).translate((cx,yc,0))
    handle='|Z and >X' if side>0 else '|Z and <X'
    screen='|Z and <X' if side>0 else '|Z and >X'
    opening=wp.edges(handle).fillet(15).edges(screen).fillet(2).val()
    owner='TL' if side>0 else 'BR'
    finger=cq.Solid.makeCylinder(10.25,100,cq.Vector(side*-65,side*133.11,0))
    rigid[owner]=rigid[owner].fuse(finger,tol=1e-4).cut(opening,tol=1e-4)
    assert rigid[owner].isValid() and len(rigid[owner].Solids())==1
    print('Voltra finger relief removed',owner,flush=True)
    px=side*(-452.025/2+24+291.04-100.79)
    for py in [yc-108.22/2,yc+108.22/2]:
        direction=-1 if py<yc else 1
        straight=box(px-4,py-.1 if direction>0 else py-3,-.1,8,3.1,100.2)
        # Entrance tapers from 10 x 4 to 8 x 3 over the top 6 mm.
        flare=(cq.Workplane('XY').workplane(offset=94)
               .center(px,py+direction*1.45).rect(8,3.1)
               .workplane(offset=6).center(0,direction*.5).rect(10,4.1)
               .loft(combine=True).val())
        tool=straight.fuse(flare)
        channel_tools.append(tool)
        channel_locations.append((px,py,direction))
        for name,p in list(rigid.items()):
            if p.intersect(straight).Volume()>1e-6:
                rigid[name]=p.cut(tool,tol=1e-4)
    print('Pin channels widened',side,flush=True)

