from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-support-cache')
import cadquery as cq
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review'
rigid={n:cq.Shape.importBrep(str(OUT/f'rigid_{n}.brep')) for n in ['BL','BR','TL','TR']}
soft={p.stem[4:]:cq.Shape.importBrep(str(p)) for p in OUT.glob('TPU_*.brep')}
assert len(soft)==14
checks=[]
for name,p in soft.items():
    for other,q in rigid.items():
        a,b=p.BoundingBox(),q.BoundingBox()
        if min(a.xmax,b.xmax)<max(a.xmin,b.xmin) or min(a.ymax,b.ymax)<max(a.ymin,b.ymin):continue
        v=p.intersect(q).Volume()
        assert v<1e-4,(name,other,v)
        checks.append({'TPU':name,'rigid':other,'intersection_mm3':v})
print('Rigid/TPU seating clear',flush=True)
# At each station, local padZ is common: +0.6 hits the fixed top stop,
# -0.5 hits the bottom stop. Use owner quadrants for a meaningful capture test.
owners={'Upper_Voltra_side_pad_1':'TL','Upper_Voltra_side_pad_2':'TR',
'Upper_Voltra_side_pad_3':'TL','Upper_Voltra_side_pad_4':'TR','Upper_Voltra_end_pad':'TL',
'Lower_Voltra_side_pad_1':'BR','Lower_Voltra_side_pad_2':'BL',
'Lower_Voltra_side_pad_3':'BR','Lower_Voltra_side_pad_4':'BL','Lower_Voltra_end_pad':'BR'}
for n,owner in owners.items():
    assert rigid[owner].intersect(soft[n].translate((0,0,.2))).Volume()<1e-4,(n,'roof clearance')
    assert rigid[owner].intersect(soft[n].translate((0,0,.6))).Volume()>1e-5,(n,'top capture')
    assert rigid[owner].intersect(soft[n].translate((0,0,-.5))).Volume()>1e-5,(n,'bottom capture')
print('All10 fixed top and bottom capture checks passed',flush=True)

for i,a in enumerate(rigid):
    for b in list(rigid)[i+1:]:assert rigid[a].intersect(rigid[b]).Volume()<1e-4,(a,b)
placed=['BL']
for name in ['BR','TL','TR']:
    for dz in [1,20,66,90,100.2]:
        for other in placed:assert rigid[name].translate((0,0,dz)).intersect(rigid[other]).Volume()<1e-4,(name,other,dz)
    placed.append(name)
print('Sampled rigid assembly motion clear',flush=True)
# A pin is not a bearing or support. Use prior measured envelope at several
# heights, conservatively from original tested wall datums.
for side in [1,-1]:
    px=side*(-452.025/2+24+291.04-100.79);yc=side*81
    for py in [yc-54.11,yc+54.11]:
        d=-1 if py<yc else 1
        for dx in [-1.5,0,1.5]:
            for z in [5,50,97]:
                pin=cq.Solid.makeCylinder(2.06,1.36,cq.Vector(px+dx,py,z),cq.Vector(0,d,0))
                for p in rigid.values():assert p.intersect(pin).Volume()<1e-4,(side,py,dx,z)
print('Sampled pin clearances retained',flush=True)
for dz in [0,10,30,50,80,100]:
    valve=cq.Solid.makeCylinder(3.04,6.59,cq.Vector(0,-161.13125,51.76-dz),cq.Vector(0,1,0))
    for p in rigid.values():assert p.intersect(valve).Volume()<1e-4,dz
report={'valid_rigid_parts':4,'valid_TPU_parts':14,'seating_checks':checks,
 'all_10_top_and_bottom_capture_tests_passed':True,'no_rigid_overlap':True,'sampled_vertical_assembly_clear':True,
 'pin_clearance_samples_passed':True,'valve_clearance_samples_passed':True,
 'install_order':'Assemble rigid sections first, then install TPU pads and cups',
 'not_tested':['Full-size physical fit and force','TPU flex/creep','Slicer support generation','Drop protection']}
(OUT/'assembly_validation.json').write_text(json.dumps(report,indent=2))
print('Assembly, pin and valve geometric checks passed',flush=True)
