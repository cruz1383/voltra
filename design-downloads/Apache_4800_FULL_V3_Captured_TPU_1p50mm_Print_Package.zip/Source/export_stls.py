from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-full-v3-cache')
import cadquery as cq
ROOT=Path(__file__).resolve().parent;CAD=ROOT/'review';OUT=ROOT/'stl_full';OUT.mkdir(exist_ok=True)
files=sorted(CAD.glob('PRINT_ORIENTATION_*.brep'));assert len(files)==18
manifest={'full':[]}
for path in files:
    name=path.stem.removeprefix('PRINT_ORIENTATION_')
    p=cq.Shape.importBrep(str(path));assert p.isValid() and len(p.Solids())==1
    filename=f'PRINT_{name}.stl'
    assert p.exportStl(str(OUT/filename),tolerance=.015,angularTolerance=.05,relative=False)
    manifest['full'].append({'file':filename,'material':'Rigid' if name.startswith('Rigid') else 'TPU'})
    print('Exported',filename,flush=True)
(ROOT/'stl_manifest.json').write_text(json.dumps(manifest,indent=2))
