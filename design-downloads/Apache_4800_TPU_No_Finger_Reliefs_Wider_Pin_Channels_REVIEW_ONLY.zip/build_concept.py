"""Review-only TPU contact concept built on the valve-relieved V4 CAD."""
from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-tpu-cache')
os.environ.setdefault('MPLCONFIGDIR','/tmp/voltra-tpu-mpl')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
SOURCE=ROOT.parent/'valve-clearance/source-v4'
VALVE=ROOT.parent/'valve-clearance/revised'
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
def rr(l,w,r,x,y,z,h):
    return cq.Workplane('XY').box(l,w,h,centered=(True,True,False)).edges('|Z').fillet(r).val().translate((x,y,z))
rigid={}
for name in ['BL','BR','TL','TR']:
    path=VALVE/f'Insert_{name}_Valve_Relief.step' if name in ['BL','BR'] else SOURCE/f'Insert_{name}.step'
    rigid[name]=cq.importers.importStep(str(path)).val()
# Restore only the two obsolete stopper finger notches. Maintain the original
# 0.30 mm section seam and original capsule opening at Z55-100.
for side in [1,-1]:
    sx=-side*150
    capsule=rr(62.97,43.27,21.625,sx,0,55,45)
    # Overlap the old cut by .25 mm inside existing rigid material to avoid
    # coincident cylindrical faces in the union. Exterior result is identical.
    notch=cq.Solid.makeCylinder(8.25,45.1,cq.Vector(sx-side*62.97/2,0,54.9))
    fill=notch
    for name in (['BL','TL'] if side>0 else ['BR','TR']):
        sy=-1 if name.startswith('B') else 1
        clip=box(-230,-165 if sy<0 else .15,54.9,460,164.85,45.1)
        patch=fill.intersect(clip)
        print('Restoring notch',name,flush=True)
        rigid[name]=rigid[name].fuse(patch,tol=1e-4)
        print('Fused',name,flush=True)
        rigid[name]=rigid[name].cut(capsule,tol=1e-4)
        print('Re-cut capsule',name,flush=True)
        # Keep valid split faces; OCC face unification stalls on this STEP.
        print('Notch restored',name,flush=True)
        assert rigid[name].isValid() and len(rigid[name].Solids())==1
print('Imported V4 and removed only the stopper finger reliefs',flush=True)
# Remove the two unused Voltra finger scallops with overlapping restoration
# stock, then re-cut the exact R15/R2 device opening and larger pin channels.
channel_tools=[]
channel_locations=[]
for side in [1,-1]:
    cx=side*(-452.025/2+24+329/2); yc=side*81
    wp=cq.Workplane('XY').box(333,108.22,100,centered=(True,True,False)).translate((cx,yc,0))
    handle='|Z and >X' if side>0 else '|Z and <X'
    screen='|Z and <X' if side>0 else '|Z and >X'
    opening=wp.edges(handle).fillet(15).edges(screen).fillet(2).val()
    owner='TL' if side>0 else 'BR'
    finger=cq.Solid.makeCylinder(10.25,100,cq.Vector(side*-65,side*133.11,0))
    rigid[owner]=rigid[owner].fuse(finger,tol=1e-4).cut(opening,tol=1e-4)
    assert rigid[owner].isValid() and len(rigid[owner].Solids())==1
    print('Voltra finger relief removed',owner,flush=True)
    px=side*(-452.025/2+24+291.04-100.79)
    for py in [yc-108.22/2,yc+108.22/2]:
        direction=-1 if py<yc else 1
        straight=box(px-4,py-.1 if direction>0 else py-3,-.1,8,3.1,100.2)
        # Entrance tapers from 10 x 4 to 8 x 3 over the top 6 mm.
        flare=(cq.Workplane('XY').workplane(offset=94)
               .center(px,py+direction*1.45).rect(8,3.1)
               .workplane(offset=6).center(0,direction*.5).rect(10,4.1)
               .loft(combine=True).val())
        tool=straight.fuse(flare)
        channel_tools.append(tool)
        channel_locations.append((px,py,direction))
        for name,p in list(rigid.items()):
            if p.intersect(straight).Volume()>1e-6:
                rigid[name]=p.cut(tool,tol=1e-4)
    print('Pin channels widened',side,flush=True)

seats=[];soft={}
for label,side in [('Upper',1),('Lower',-1)]:
    # Flat wall segments avoid the finger scallop, pin channels and narrow
    # walls next to stopper cradles. Opposite row is rotated 180 degrees.
    specs=[(-177.5,135.11,60,2.5), (2.5,135.11,60,2.5),
           (-117.5,24.39,60,2.5),(7.5,24.39,60,2.5),
           (-206.5125,56,2.5,50)]
    for i,(x,y,l,w) in enumerate(specs,1):
        seat=box(x,y,10,l,w,90)
        if side<0:seat=seat.rotate((0,0,0),(0,0,1),180)
        # Seat is wholly in original rigid material; the contacting surface
        # remains exactly on the established opening boundary.
        owner=next(n for n,p in rigid.items() if p.intersect(seat).Volume()>seat.Volume()*.99)
        pad=seat
        # Back-side relief channels: 1.2 mm contact skin, 1.3 mm flex space.
        # Keep 5 mm end rails, with approximately 2 mm support ribs.
        if i<5:
            back=y+(1.2 if i<=2 else 0)
            for dx in range(4,int(l)-4,8):
                groove=box(x+dx,back,15,4,1.3,80)
                if side<0:groove=groove.rotate((0,0,0),(0,0,1),180)
                pad=pad.cut(groove)
        else:
            for dy in [5,15,25,35]:
                groove=box(x,y+dy,15,1.3,6,80)
                if side<0:groove=groove.rotate((0,0,0),(0,0,1),180)
                pad=pad.cut(groove)
        assert pad.isValid() and len(pad.Solids())==1
        seats.append(seat)
        soft[f'{label}_Voltra_pad_{i}']=pad
        print('Pad',label,i,'owner',owner,flush=True)

for label,side in [('Upper',1),('Lower',-1)]:
    # Charger: sleeve recessed 1.5 mm outward into the rigid wall. A removable
    # floor mat sits ON the old floor, covering rather than deleting its logo.
    cx,cy=side*177.5,side*61.5
    outer=rr(90,68,5.5,cx,cy,30,70)
    inside=rr(87,65,4,cx,cy,30,71)
    ring=outer.cut(inside)
    mat=rr(87,65,4,cx,cy,30,2)
    soft[f'{label}_charger_TPU_cup']=ring.fuse(mat).clean()
    seats.append(ring)
    # Stopper: include existing capsule profile and finger access scallop.
    sx=-side*150
    inner=rr(62.97,43.27,21.625,sx,0,55,45)
    face=next(f for f in inner.Faces() if f.normalAt().z<-.99)
    wire=face.outerWire().translate((0,0,-55))
    outer=(cq.Workplane('XY').add(wire).toPending().offset2D(1.5)
           .extrude(45).val().translate((0,0,55)))
    ring=outer.cut(inner).clean()
    # Mat is the exact existing footprint, not an estimated accessory outline.
    mat=cq.Solid.extrudeLinear(wire,[],cq.Vector(0,0,2)).translate((0,0,55))
    soft[f'{label}_stopper_TPU_cup']=ring.fuse(mat).clean()
    seats.append(ring)
    print('Accessory cups built',label,flush=True)

for name,p in list(rigid.items()):
    # Avoid expensive irrelevant booleans against engraved floor artwork.
    for seat in seats:
        a,b=p.BoundingBox(),seat.BoundingBox()
        if min(a.xmax,b.xmax)>max(a.xmin,b.xmin)+1e-6 and min(a.ymax,b.ymax)>max(a.ymin,b.ymin)+1e-6:
            p=p.cut(seat)
    # Preserve valid split faces rather than unifying the imported surfaces.
    assert p.isValid() and len(p.Solids())==1,(name,'rigid topology')
    rigid[name]=p
    print('Rigid seats cut',name,flush=True)
for name,p in soft.items():
    assert p.isValid() and len(p.Solids())==1,name

assembly=cq.Assembly(name='TPU_CONTACT_CONCEPT_REVIEW_ONLY')
for name,p in rigid.items():assembly.add(p,name='Rigid_'+name,color=cq.Color(.48,.56,.60))
for name,p in soft.items():assembly.add(p,name=name,color=cq.Color(1.,.49,.10))
assembly.save(str(OUT/'TPU_Concept_No_Finger_Reliefs_Wider_Pin_Channels_REVIEW_ONLY.step'))

for name,p in rigid.items():
    p.exportBrep(str(OUT/('Rigid_'+name+'.brep')))
for name,p in soft.items():
    p.exportBrep(str(OUT/(name+'.brep')))

# Cache actual CAD tessellations for orthographic engineering renders.
arrays={}
for family,shapes in [('rigid',rigid),('TPU',soft)]:
    for name,p in shapes.items():
        verts,faces=p.tessellate(.08,.12)
        arrays[family+'__'+name]=np.array([v.toTuple() for v in verts])[np.array(faces)]
np.savez_compressed(OUT/'cad_triangles.npz',**arrays)

# Real cross-section coupon shows 2.5 mm seat, contact skin and back relief.
wall=box(-6,0,0,6,30,45).cut(box(-2.5,2,5,2.5,26,40))
pad=box(-2.5,2,5,2.5,26,40)
for y in [5,13,21]:pad=pad.cut(box(-2.5,y,10,1.3,4,35))
detail=cq.Assembly(name='Pad_seat_section_concept')
detail.add(wall,name='Rigid_wall',color=cq.Color(.48,.56,.60))
detail.add(pad,name='TPU_pad',color=cq.Color(1.,.49,.10))
detail.save(str(OUT/'Pad_Seat_Detail_REVIEW_ONLY.step'))
detail_arrays={}
for name,p in [('rigid',wall),('TPU',pad)]:
    # Cut away half of coupon to expose the back-side flex cavity.
    p=p.intersect(box(-10,0,0,20,7,60))
    v,f=p.tessellate(.03,.1)
    detail_arrays[name]=np.array([v.toTuple() for v in v])[np.array(f)]
np.savez_compressed(OUT/'detail_triangles.npz',**detail_arrays)
section_arrays={}
clip=box(-226,-100,15,97,38.5,87)
for name,p in [('rigid',rigid['BL']),('TPU',soft['Lower_charger_TPU_cup'])]:
    p=p.intersect(clip)
    v,f=p.tessellate(.05,.12)
    section_arrays[name]=np.array([p.toTuple() for p in v])[np.array(f)]
np.savez_compressed(OUT/'charger_section_triangles.npz',**section_arrays)
report={'stage':'CAD CONCEPT ONLY; not printable release',
 'rigid_parts_valid_single_solid':list(rigid),
 'TPU_parts_valid_single_solid':list(soft),
 'device_pads_per_Voltra':5,'long_side_pad_width_mm':60,'previous_long_side_pad_width_mm':25,'device_pad_seat_mm':2.5,
 'contact_skin_mm':1.2,'back_relief_depth_mm':1.3,
 'device_opening_reduction_mm':0,
 'charger_stopper_side_liner_mm':1.5,'accessory_floor_mat_mm':2,
 'charger_floor_top_z_mm':32,'stopper_floor_top_z_mm':57,
 'charger_larger_bundle_nominal_top_clearance_mm':1.14,
 'carabiner_slots':'No TPU; original rigid slots retained',
 'Voltra_finger_reliefs':'Both removed', 'pin_channels_mm':{'old_width':5.2,'width':8,'old_depth':2,'depth':3,'top_entrance_width':10,'top_entrance_depth':4,'lead_in_height':6,'station_unchanged':True},
 'stopper_cradle_mm':[62.97,43.27], 'stopper_finger_reliefs':'Removed from rigid parts and TPU liners; no shortening',
 'logos':'Existing charger floor logos covered by removable TPU mats',
 'pending':['Retention/clip design and tolerances','Remaining wall/web and joint checks',
 'TPU stiffness coupon','Physical accessory packing and lid clearance',
 'Final printable sectioning and mesh validation'],
 'drop_protection':'Not tested or rated'}
(OUT/'concept_notes.json').write_text(json.dumps(report,indent=2))
print('Saved actual CAD concept and render geometry',flush=True)
