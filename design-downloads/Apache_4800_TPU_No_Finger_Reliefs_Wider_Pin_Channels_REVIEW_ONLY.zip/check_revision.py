from pathlib import Path
import os,json
os.environ.setdefault('XDG_CACHE_HOME','/tmp/voltra-tpu-cache')
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'review'
old=np.load(ROOT.parent/'tpu-concept-no-stopper-notch/review/cad_triangles.npz')
new=np.load(OUT/'cad_triangles.npz')
unchanged=[]
for name in old.files:
    if name.startswith('TPU'):
        assert np.array_equal(old[name],new[name]),name
        unchanged.append(name)
rigid={n:cq.Shape.importBrep(str(OUT/f'Rigid_{n}.brep')) for n in ['BL','BR','TL','TR']}
for n,p in rigid.items():assert p.isValid() and len(p.Solids())==1,n
def box(x,y,z,l,w,h):return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))
pin_checks=[]
for side in [1,-1]:
    owner='TL' if side>0 else 'BR'
    for z in [5,50,95]:
        assert rigid[owner].isInside(cq.Vector(side*-65,side*139,z),1e-5)
    px=side*(-452.025/2+24+291.04-100.79);yc=side*81
    for py in [yc-54.11,yc+54.11]:
        d=-1 if py<yc else 1
        local=cq.Compound.makeCompound([p.intersect(box(px-7,py-6,-1,14,12,102)) for p in rigid.values()])
        for dx in [-1.5,0,1.5]:
            for z in [5,20,50,90,97]:
                # Conservative pin starts at cavity-wall datum, without
                # credit for the device's existing wall clearance.
                pin=cq.Solid.makeCylinder(2.06,1.36,cq.Vector(px+dx,py,z),cq.Vector(0,d,0))
                v=local.intersect(pin).Volume()
                assert v<1e-5,(side,py,dx,z,v)
        pin_checks.append({'center_x_mm':px,'wall_y_mm':py,'pin_diameter_mm':4.12,
            'pin_projection_mm':1.36,'tested_lateral_offsets_mm':[-1.5,0,1.5],
            'tested_pin_center_heights_mm':[5,20,50,90,97],'no_interference_at_samples':True})

# Actual CAD cutaway around one production pin channel.
px=-11.7625;py=135.11
clip=box(px-12,py-1,75,24,9,25)
section=rigid['TL'].intersect(clip)
pin=cq.Solid.makeCylinder(2.06,6.36,cq.Vector(px,py-5,88),cq.Vector(0,1,0))
arrays={}
for name,p in [('rigid',section),('PIN_reference_only',pin)]:
    v,f=p.tessellate(.02,.07)
    arrays[name]=np.array([a.toTuple() for a in v])[np.array(f)]
np.savez_compressed(OUT/'pin_detail_triangles.npz',**arrays)
report={'stage':'Review concept; physical fit and load behavior untested',
 'unchanged_TPU_components_exact_tessellation_match':unchanged,
 'rigid_valid_single_solids':list(rigid),'Voltra_finger_relief_fill_probe_checks':'Passed',
 'pin_channel_width_before_mm':5.2,'pin_channel_width_after_mm':8,
 'pin_channel_depth_before_mm':2,'pin_channel_depth_after_mm':3,
 'entrance_width_depth_mm':[10,4],'entrance_taper_height_mm':6,
 'pin_nominal_total_lateral_clearance_mm':3.88,
 'pin_nominal_end_clearance_from_wall_datum_mm':1.64,'pin_checks':pin_checks,
 'note':'Pin model uses prior measured 4.12 diameter and 1.36 projection; recheck if fitted sleeve changes projection.'}
(OUT/'revision_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
