VOLTRA TPU CONCEPT — NO DEVICE FINGER SCALLOPS / WIDER PIN CHANNELS

Both unused Voltra finger scallops are closed with continuous pocket walls.
R15 handle-end corners, R2 screen-end corners, established 333 x 108.22 mm
device opening datums and pin-channel longitudinal stations are retained.

All four pin channels (both long walls of both device pockets) change:
  Straight width: 5.20 -> 8.00 mm, open through the entire 100 mm height.
  Depth from cavity wall: 2.00 -> 3.00 mm.
  Top entrance: 10.00 mm wide x 4.00 mm deep.
  Taper: entrance narrows to the straight channel over Z100 to Z94.
The prior 4.12 mm pin diameter gives 3.88 mm total nominal lateral clearance
(1.94 mm per side). Its prior 1.36 mm projection leaves 1.64 mm nominal tip
clearance, conservatively measured from the cavity-wall datum. An actual
fitted sleeve or changed pin may alter these values and needs checking.

The pin is intended to pass freely, not provide a vertical support or slide
rail. The device should seat on the retained bottom foam. Do not force an
insertion that still catches; check fitted pin projection/alignment first.

UNCHANGED
60 mm side pads, end pads, both charger liners and floor mats, closed-ended
62.97 x 43.27 mm stopper liners, bare carabiner slots, case footprint and
previous air-valve relief. Orange is TPU, gray is rigid. The gold cylinder
in the channel close-up is a dimensional reference pin, not a hardware export.

REVIEW ONLY
STEP assembly and PNG views are actual CAD. Four valid single rigid solids
and fourteen valid single TPU solids are included. Software checks sample
pin insertion at several heights and +/-1.5 mm lateral offsets. They do not
establish physical force, printed finish, sleeve fit or a load rating.
The TPU system is not yet a printable release: pad retention, first-contact
offset, local wall/joint strength and printer tolerances remain to finalize.
No print-ready STLs are supplied. Existing foam carries the devices.
Accessory mats still cover charger logos and raise floors 2 mm. Existing
larger charger/cable packing has only 1.14 mm nominal top clearance.
