from pathlib import Path
root=Path(__file__).resolve().parent
s=(root/'render_concept.py').read_text().split("im=Image.new('RGB',(2200,1600)")[0]
s=s.replace("col=(1.,.52,.12) if name.startswith('TPU') else (.56,.63,.67)","col=(.95,.70,.22) if name.startswith('PIN') else ((1.,.52,.12) if name.startswith('TPU') else (.56,.63,.67))")
exec(compile(s,str(root/'render_concept.py'),'exec'))
im=Image.new('RGB',(1600,1420),'#f9f9f9')
pic,_=render('pin_detail_triangles.npz',[.4,-1,.6],1600,1030)
im.paste(pic,(0,180));d=ImageDraw.Draw(im)
text(d,'Wider pin channel — actual CAD cutaway',800,30,40)
text(d,'8 mm wide × 3 mm deep; entrance flares to 10 × 4 mm',800,100,29)
text(d,'Flare tapers into the straight channel over the upper 6 mm.',800,1235,28)
text(d,'Gold: reference Ø4.12 mm pin, modeled with 1.36 mm projection.',800,1290,27)
text(d,'Reference pin shown for clearance; physical insertion and fitted sleeve still need checking.',800,1345,24)
im.save(OUT/'Pin_Channel_CAD_Detail.png')
print('Rendered actual pin channel section')
