HISENSE EN2A27 — CLEAN CAD REBUILD V4 / FIRST FIT PRINT

V4 applies the confirmed rail/tooth measurements:
-2.16 mm COMBINED rail-and-tooth width, not2.16 mm extra projection.
-16.07 mm from the rounded-end rail shoulder to the tooth tip station.
The current modeled rail starts at X=-27.00; tooth tip station X=-10.93.
The modeled rail width remains0.85 mm (scan/photo estimated), so tooth
projection beyond its outer face is1.31 mm. Both teeth project OUTWARD.
The triangular plan length remains an estimated2.5 mm, and rail height
remains an estimated1.0 mm. Rail tops stay smooth, with no top bulges.

BODY WIDTH VERSUS OVERALL TOOTH WIDTH
Body width stays39.02 mm. With existing rail positions and the confirmed
2.16 mm combined section, overall width across both tooth tips is41.02 mm.
No rail/body shifting or scaling was introduced to hide this difference.
Check actual remote opening clearance before forcing a fit. The39.02 mm
measurement is interpreted as body width, excluding these local projections.

Main body, end tabs and catch generation geometry remain unchanged.
V1/V2/V3 rail revisions are superseded by this measured V4 revision.

This replaces the earlier patched scan candidate. The new model is clean
CAD using supplied caliper measurements and photographs, with scan-guided
surface curvature. It is not merely a conversion or smoothed scan.

CALIPER MEASUREMENTS
Body length excluding tabs:76.02 mm.
Body width:39.02 mm.
Nominal shell thickness:2.20 mm.
Overall length including reconstructed tabs:79.02 mm.
Overall width including side retaining teeth:41.02 mm.
The side rails, two insert tabs, and rounded-end catch are reconstructed
from scan/photo evidence; their dimensions were NOT independently measured.
See validation.json for those estimated feature dimensions. Scan markers,
embossed text, and scan roughness are omitted. The outside is smooth.

FIT STATUS
This is a first fit print, not a confirmed working replacement. Main body
size follows calipers. Tab engagement, side-rail clearance, battery clearance,
and catch/release function require a physical fit check. The catch frame
approximates visible geometry; the original release flexure is not verified.
Do not force a binding cover. It is not appropriate to call the attachment
features an exact reproduction solely from these perspective photographs.

PRINTING
Import STL in millimeters,100% scale. Do not auto-scale it.
The STL is oriented broad face horizontal, inner features upward, bottom
at Z0. The curved exterior does not sit flat over its entire area:inspect
and enable supports beneath raised curved portions and tab overhangs as
needed. This is NOT a verified support-free design or pre-sliced project.
PETG is a reasonable starting material for functional clips. Use your known
PETG printer profile; a0.16 mm layer and3-4 walls are reasonable starting
settings for a0.4 mm nozzle. Check thin tab slot toolpaths. PLA can be used
for a dimensional trial but is more brittle at small engagement features.
Printer-specific toolpaths, bridging and support removal are untested.

CHECKS
Valid single CAD solid. STL:one watertight connected body, consistent winding,
positive volume, no detected self-intersecting faces. Nine main-shell
thickness probes confirm2.20 mm. These are geometric checks, not physical fit.

FILES
Hisense_EN2A27_Rebuilt_V4.stl:print geometry.
Hisense_EN2A27_Rebuilt_V4.step:editable CAD reference.
Hisense_EN2A27_Rebuilt_V4_CAD.png:four CAD views.
validation.json:dimensions, estimated features, mesh/thickness checks.

ADDITIONAL V4 FILES
Hisense_EN2A27_V4_Rail_Closeup.png:outward triangle and measured section.
rail_change_validation.json:continuous rail, smooth top and projection checks.
