"""Four-part first full-height fit trial, based on physically tested perimeter/openings."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/jig-mpl')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/jig-cache')
import json
import math
import shutil
import numpy as np
import cadquery as cq

ROOT = Path('/workspace/designs/Apache_4800_Voltra_Insert')
OUT = Path('/workspace/designs/output/Apache_4800_Full_Insert_V1')
OUT.mkdir(parents=True, exist_ok=True)
L, W, R, H = 452.025, 320.2625, 20., 100.
SEAM = .30

def box(x,y,z,l,w,h):
    return cq.Solid.makeBox(l,w,h,cq.Vector(x,y,z))

def rr(l,w,r,x=0,y=0,h=H,z=0):
    return (cq.Workplane('XY').box(l,w,h,centered=(True,True,False))
            .edges('|Z').fillet(r).val().translate((x,y,z)))

def disk(r,x,y,h,z=0):
    return cq.Solid.makeCylinder(r,h,cq.Vector(x,y,z))

def extrude_profile(shape, z, h):
    faces=[f for f in shape.Faces() if abs(f.Center().z)<1e-7 and f.normalAt().z<-.99]
    assert len(faces)==1
    f=faces[0]
    return cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),cq.Vector(0,0,h)).translate((0,0,z))

# Reuse the reviewed pocket definitions, without executing preview exports or plots.
preview_source=(ROOT/'build_layout_preview_v3.py').read_text()
prefix=preview_source[:preview_source.index('validation =')]
namespace={'__name__':'preview_profiles'}
exec(prefix,namespace)
review_pockets=namespace['pockets']
depths={'device':100., 'stopper':45., 'carabiner':14., 'charger':70.}
pockets={}
for name,p in review_pockets.items():
    category=name.split()[-1]
    dep=depths[category]
    # Device openings go through the base. Other pockets have raised floors.
    pockets[name]=extrude_profile(p,H-dep,dep+.2)

# The pin's longitudinal station is known. Matching small channels on both long
# walls accommodate either installed cover orientation, without guessing the side.
for name,side in [('Red',1),('Green',-1)]:
    yc=side*81
    px=side*(-L/2+24+291.04-100.79)
    for py in [yc-108.22/2,yc+108.22/2]:
        pin=box(px-2.6,py-2 if py<yc else py-.01,0,5.2,2.01,H+.2)
        pockets[name+' device']=pockets[name+' device'].fuse(pin).clean()

full=rr(L,W,R)
for name,p in pockets.items():
    full=full.cut(p)
full=full.clean()
assert full.isValid() and len(full.Solids())==1
print('Full-height pockets built',flush=True)

def cable_groove(side):
    # Same cubic as the reviewed plan. Build a constant-width polygon around it.
    control=np.array([[-45,26.89],[-48,9],[-78,0],[-120,0]],float)*side
    t=np.linspace(0,1,101)[:,None]
    p=((1-t)**3*control[0]+3*(1-t)**2*t*control[1]
       +3*(1-t)*t*t*control[2]+t**3*control[3])
    d=(3*(1-t)**2*(control[1]-control[0])+6*(1-t)*t*(control[2]-control[1])
       +3*t*t*(control[3]-control[2]))
    normal=np.stack([-d[:,1],d[:,0]],axis=1)
    normal/=np.linalg.norm(normal,axis=1)[:,None]
    poly=np.vstack([p+3*normal,(p-3*normal)[::-1]])
    shape=(cq.Workplane('XY').polyline([tuple(v) for v in poly]).close()
           .extrude(6.2).val().translate((0,0,94)))
    for x,y in [p[0],p[-1]]:
        shape=shape.fuse(disk(3,x,y,6.2,94))
    return shape.clean()

grooves=[cable_groove(1),cable_groove(-1)]
for g in grooves:
    full=full.cut(g)
full=full.clean()
assert full.isValid() and len(full.Solids())==1

# Use the same in-plane key profile and clearances as the successful perimeter
# gauge. Female tracks are open along Z; two shorter male pads limit friction.
KEY_POINTS=[(-1,-1.25),(1.3,-1.25),(4.3,-2.1),(4.3,2.1),(1.3,1.25),(-1,1.25)]
def key_wire(axis,cx,cy,scale=1):
    pts=[(-1+(u+1)*scale,v) for u,v in KEY_POINTS]
    if axis=='x':pts=[(cx+u,cy+v) for u,v in pts]
    else:pts=[(cx+v,cy+u) for u,v in pts]
    return cq.Workplane('XY').polyline(pts).close()

def male_key(axis,cx,cy):
    # Lower 20 mm pad sits on the bed. Upper pad has a ~45 degree lead-in ramp.
    low=key_wire(axis,cx,cy).extrude(20).val()
    a=key_wire(axis,cx,cy,.04).val().translate((0,0,71))
    b=key_wire(axis,cx,cy).val().translate((0,0,77))
    ramp=cq.Solid.makeLoft([a,b],ruled=True)
    # A shrinking loft can move the wide tail into the socket's narrow neck.
    # Clip it to the full key silhouette so every ramp section clears the track.
    ramp=ramp.intersect(key_wire(axis,cx,cy).extrude(H).val())
    upper=key_wire(axis,cx,cy).extrude(23).val().translate((0,0,77))
    return low.fuse(ramp,upper).clean()

def female_key(axis,cx,cy):
    return key_wire(axis,cx,cy).offset2D(.20).extrude(H+2).val().translate((0,0,-1))

parts={}
for name,sx,sy in [('BL',-1,-1),('BR',1,-1),('TL',-1,1),('TR',1,1)]:
    x=-L/2 if sx<0 else SEAM/2
    y=-W/2 if sy<0 else SEAM/2
    parts[name]=full.intersect(box(x,y,0,L/2-SEAM/2,W/2-SEAM/2,H))

joints=[]
for cy,left,right in [(-W/2+4,'BL','BR'),(W/2-4,'TL','TR')]:
    parts[left]=parts[left].fuse(male_key('x',0,cy))
    parts[right]=parts[right].cut(female_key('x',0,cy))
    joints.append({'axis':'x','male':left,'female':right,'center_xy_mm':[0,cy]})
for cx,bottom,top in [(-L/2+4,'BL','TL'),(L/2-4,'BR','TR')]:
    parts[bottom]=parts[bottom].fuse(male_key('y',cx,0))
    parts[top]=parts[top].cut(female_key('y',cx,0))
    joints.append({'axis':'y','male':bottom,'female':top,'center_xy_mm':[cx,0]})

report={'stage':'FIRST FULL-HEIGHT FIT TRIAL; not physically validated',
        'height_mm':H,'outside_mm':[L,W],'outer_corner_radius_mm':R,
        'part_count':4,'seam_gap_mm':SEAM,
        'construction':'Solid CAD volumes; use sparse slicer infill, not100percent solid printing',
        'pocket_depths_mm':depths,
        'device_open_bottom':True,'device_opening_mm':[333,108.22],
        'stopper_opening_envelope_mm':[62.97,43.27],
        'carabiner_opening_envelope_mm':[77.78,41.81],
        'charger_opening_mm':[87,65],'charger_floor_z_mm':30,
        'cable_groove_mm':{'width':6,'depth':6,'status':'Provisional route; physical cable bend and retraction behavior untested'},
        'pin_relief':{'cover_handle_end_to_center_mm':100.79,'width_mm':5.2,'depth_mm':2,
                      'walls':'Both long walls of each device pocket; full height, for either cover-pin orientation'},
        'joints':joints,'joint_details':{'socket_offset_mm':.20,'male_lower_pad_z_mm':[0,20],
                                       'male_upper_ramp_z_mm':[71,77],'male_upper_pad_z_mm':[77,100],
                                       'socket_open_z_mm':[-1,101]},
        'physical_fit_confirmed':['Thin V2 perimeter at cushion level','108.22mm device band'],
        'physical_fit_untested':['100mm case taper and lid closure','Accessory pockets and floors',
                                'Long vertical key tracks','Cable routes and larger cable packing'],
        'parts':{},'assembly_overlap_checks':[],'vertical_assembly_checks':[]}

for name,p in parts.items():
    # Recessed top labels are away from equipment and keys.
    x=-140 if name.endswith('L') else 140
    y=147 if name.startswith('T') else -147
    mark=cq.Workplane('XY').text(name,6,.5,combine=False).val().translate((x,y,99.5))
    p=p.cut(mark).clean()
    assert p.isValid() and len(p.Solids())==1,(name,'invalid or disconnected')
    assert p.cut(rr(L,W,R)).Volume()<1e-5,(name,'protrudes past case envelope')
    parts[name]=p
    cq.exporters.export(p,str(OUT/f'Insert_{name}.step'))
    b=p.BoundingBox()
    q=p.translate((-b.xmin,-b.ymin,-b.zmin))
    assert b.xlen+10<=256 and b.ylen+10<=256 and abs(b.zlen-H)<1e-6
    q.exportStl(str(OUT/f'PRINT_Insert_{name}.stl'),tolerance=.025,
                angularTolerance=.07,relative=False)
    report['parts'][name]={'valid_single_solid':True,'footprint_mm':[b.xlen,b.ylen],
                           'with_5mm_brim_mm':[b.xlen+10,b.ylen+10],
                           'height_mm':b.zlen,'solid_cad_volume_cm3':p.Volume()/1000,
                           'print_orientation':'Flat unmarked bottom on bed; recessed label faces up'}
    print('Exported '+name,flush=True)

for i,a in enumerate(parts):
    for b in list(parts)[i+1:]:
        vol=parts[a].intersect(parts[b]).Volume()
        assert vol<1e-5,(a,b,vol)
        report['assembly_overlap_checks'].append({'parts':[a,b],'intersection_mm3':vol})

# Simulate lowering BR, then TL, then TR onto BL. Motion is along open socket
# tracks. Sampled checks complement the prismatic socket geometry inspection.
placed=['BL']
for name in ['BR','TL','TR']:
    for dz in [1,5,12,20,40,60,71,77,90,100.2]:
        moving=parts[name].translate((0,0,dz))
        for other in placed:
            v=moving.intersect(parts[other]).Volume()
            assert v<1e-5,(name,other,dz,v)
    report['vertical_assembly_checks'].append({'part':name,'placed_parts':placed.copy(),
              'sampled_z_offsets_mm':[1,5,12,20,40,60,71,77,90,100.2],'no_interference':True})
    placed.append(name)

# Verify ideal complete device envelopes can pass through the whole height.
for side in [1,-1]:
    cx=side*(-L/2+24+329/2)
    ideal=box(cx-329/2,side*81-107.72/2,0,329,107.72,H)
    for name,p in parts.items():
        assert p.intersect(ideal).Volume()<1e-5,(name,'device envelope interference')

assembly=cq.Assembly(name='Apache_4800_Full_Insert_V1')
colors={'BL':(.35,.48,.55),'BR':(.53,.63,.66),'TL':(.49,.60,.63),'TR':(.34,.47,.54)}
for name,p in parts.items():
    assembly.add(p,name=name,color=cq.Color(*colors[name]))
cq.exporters.export(cq.Compound.makeCompound(list(parts.values())),str(OUT/'Assembly.step'))

# Optional full-height track coupons use the exact production key and socket.
# Broad feet aid adhesion; these are separate tests, not extra insert components.
coupons={
    'Male':box(-10,-6,0,10-SEAM/2,12,H).fuse(box(-18,-10,0,18-SEAM/2,20,2),male_key('x',0,0)),
    'Female':box(SEAM/2,-6,0,10-SEAM/2,12,H).fuse(box(SEAM/2,-10,0,18-SEAM/2,20,2)).cut(female_key('x',0,0))
}
for label,cp in coupons.items():
    cp=cp.clean()
    assert cp.isValid() and len(cp.Solids())==1
    cb=cp.BoundingBox()
    cq.exporters.export(cp,str(OUT/f'OPTIONAL_Joint_Test_{label}.step'))
    cp.translate((-cb.xmin,-cb.ymin,0)).exportStl(str(OUT/f'OPTIONAL_Joint_Test_{label}.stl'),
                    tolerance=.025,angularTolerance=.07,relative=False)
    coupons[label]=cp
assert coupons['Male'].intersect(coupons['Female']).Volume()<1e-5
report['optional_joint_coupons']={'count':2,'height_mm':H,'purpose':'Test actual100mm track and two-tier key before large prints'}
report['ideal_device_envelope_clearance_checked']=True
report['total_solid_CAD_volume_cm3']=sum(x['solid_cad_volume_cm3'] for x in report['parts'].values())
(OUT/'CAD_validation.json').write_text(json.dumps(report,indent=2))
shutil.copy(__file__,OUT/'build_full_insert_v1.py')
shutil.copy(ROOT/'build_layout_preview_v3.py',OUT/'build_layout_preview_v3.py')
shutil.copy(ROOT/'design_brief.json',OUT/'design_brief.json')

# Software depth-buffer render of actual exported STL surfaces.
import runpy
runpy.run_path(str(ROOT/'render_full_insert.py'),run_name='__main__')
print(json.dumps({'output':str(OUT),'part_count':len(parts),'all_CAD_checks_passed':True},indent=2),flush=True)
