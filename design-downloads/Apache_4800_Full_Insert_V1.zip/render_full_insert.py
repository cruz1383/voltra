"""CPU depth-buffer engineering render of the actual exported STL triangles."""
from pathlib import Path
import os,struct
os.environ.setdefault('MPLCONFIGDIR','/tmp/jig-mpl')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/jig-cache')
import numpy as np
import cadquery as cq
from PIL import Image,ImageDraw,ImageFont
from matplotlib.font_manager import findfont
OUT=Path('/workspace/designs/output/Apache_4800_Full_Insert_V1')
colors={'BL':(.35,.48,.55),'BR':(.53,.63,.66),'TL':(.49,.60,.63),'TR':(.34,.47,.54)}
triangles=[];base_colors=[]
dtype=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')])
for name,col in colors.items():
 b=cq.importers.importStep(str(OUT/f'Insert_{name}.step')).val().BoundingBox()
 data=(OUT/f'PRINT_Insert_{name}.stl').read_bytes();n=struct.unpack_from('<I',data,80)[0]
 a=np.frombuffer(data,dtype=dtype,offset=84,count=n)['points'].astype(float)
 a+=np.array([b.xmin,b.ymin,0])
 triangles.append(a);base_colors.extend([col]*len(a))
a=np.concatenate(triangles);base_colors=np.array(base_colors)
normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);normal/=np.maximum(np.linalg.norm(normal,axis=1),1e-12)[:,None]
view=np.array([.40,-.55,1.25]);view/=np.linalg.norm(view)
right=np.cross([0,0,1],view);right/=np.linalg.norm(right)
up=np.cross(view,right)
light=np.array([-.25,-.4,1]);light/=np.linalg.norm(light)
shade=.5+.5*np.maximum(normal@light,0)
color=np.clip(base_colors*shade[:,None]*255,0,255).astype(np.uint8)
projected=np.stack([a@right,a@up,a@view],axis=-1)
lo=projected[:,:,:2].reshape(-1,2).min(axis=0);hi=projected[:,:,:2].reshape(-1,2).max(axis=0)
scale=min(1700/(hi[0]-lo[0]),1000/(hi[1]-lo[1]))
projected[:,:,0]=(projected[:,:,0]-(lo[0]+hi[0])/2)*scale+1000
projected[:,:,1]=720-(projected[:,:,1]-(lo[1]+hi[1])/2)*scale
width,height=2000,1450
canvas=np.full((height,width,3),255,np.uint8)
zbuffer=np.full((height,width),-np.inf)
for i,t in enumerate(projected):
 if normal[i]@view<=0:continue
 x0=max(0,int(np.floor(t[:,0].min())));x1=min(width-1,int(np.ceil(t[:,0].max())))
 y0=max(0,int(np.floor(t[:,1].min())));y1=min(height-1,int(np.ceil(t[:,1].max())))
 if x1<x0 or y1<y0:continue
 xs=np.arange(x0,x1+1)[None,:]+.5;ys=np.arange(y0,y1+1)[:,None]+.5
 denom=(t[1,1]-t[2,1])*(t[0,0]-t[2,0])+(t[2,0]-t[1,0])*(t[0,1]-t[2,1])
 if abs(denom)<1e-12:continue
 w0=((t[1,1]-t[2,1])*(xs-t[2,0])+(t[2,0]-t[1,0])*(ys-t[2,1]))/denom
 w1=((t[2,1]-t[0,1])*(xs-t[2,0])+(t[0,0]-t[2,0])*(ys-t[2,1]))/denom
 w2=1-w0-w1
 depth=w0*t[0,2]+w1*t[1,2]+w2*t[2,2]
 local=zbuffer[y0:y1+1,x0:x1+1]
 mask=(w0>=-1e-7)&(w1>=-1e-7)&(w2>=-1e-7)&(depth>local)
 local[mask]=depth[mask]
 canvas[y0:y1+1,x0:x1+1][mask]=color[i]
im=Image.fromarray(canvas);draw=ImageDraw.Draw(im)
def text(msg,y,size,bold=False):
 f=ImageFont.truetype(findfont('DejaVu Sans' if not bold else 'DejaVu Sans:weight=bold'),size)
 draw.text((width/2,y),msg,font=f,fill='#293e49',anchor='mt',align='center')
text('Apache 4800 - first full-height PETG insert',55,43,True)
text('Actual exported geometry | Four sections shown in different colors for assembly clarity',125,27)
text('Open-bottom Voltra pockets | Charger/cable compartments | Stopper cradles | Carabiner slots',1310,27)
text('100 mm tall. Keep bottom cushion and lid foam. Full-height fit and joints need a physical trial.',1360,26)
im.save(OUT/'Full_Insert_Assembly_Preview.png')
im.save(OUT/'Full_Insert_Assembly_Preview.pdf',resolution=160)
print('Rendered actual exported triangles with a CPU depth buffer')
